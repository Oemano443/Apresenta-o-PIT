//import Colaborador from './Modelo/Colaborador.js';
//import Rifas from './Modelo/Rifas.js';

import express from 'express';
import cors from 'cors';
import rotaColaborador from './Rotas/rotaColaborador.js';
import rotaRifa from './Rotas/rotaRifa.js';
import rotaAnimal from './Rotas/rotaAnimal.js';
import rotaRacas from './Rotas/rotaRacas.js';
import rotaTipoDespesa from './Rotas/rotaTipoDespesa.js';
import rotaItensDoacao from './Rotas/rotaItensDoacao.js';
import rotaCadastro from './Rotas/rotaCadastro.js';
import rotaAdocao from './Rotas/rotaAdocao.js';
import rotaDespesa from './Rotas/rotaDespesas.js';
import rotaDoacao from './Rotas/rotaDoacao.js';

const porta = 5000;
const host = 'localhost'

const appExpress = express();
appExpress.use(cors());


appExpress.use(express.urlencoded({extended:false}));


appExpress.use(express.json());


// definição de endpoints que encaminharão para as rotas
appExpress.use('/colaboradores', rotaColaborador)
appExpress.use('/rifa', rotaRifa);
appExpress.use('/animais',rotaAnimal);
appExpress.use('/racas', rotaRacas)
appExpress.use('/tiposdespesas',rotaTipoDespesa)
appExpress.use('/itensdoacao',rotaItensDoacao)
appExpress.use('/cadastro', rotaCadastro)
appExpress.use('/adocoes', rotaAdocao)
appExpress.use('/despesas', rotaDespesa)
appExpress.use('/doacoes',rotaDoacao)


appExpress.listen(porta, host ,function(){
    console.log(`Em execução: http://${host}:${porta}`)
})










/*
const user = new Cadastros(
    0,
    'xxx',
    'yyy',
    'xxxx'

);

/*
// Método de gravação
user.gravar().then(function(){
  console.log('Gravado no Banco de Dados')
})*/
/*
user.autenticacao().then(()=>{
    console.log()
})


/*
// Método para consultar informações
item.consultar('yyy').then(function(listaitem){
    for(const item of listaitem){
    console.log(item.toJSON());
}});





/*
/*
const objetoColaborador= new Colaborador(
    1,
    '777',
    'Voluntário',
    'Francisco',
    '19/11/1988',
    11111111,
    'fran@gmail.com',
    '00000-000',
    'Jardim Soledade',
    99,
    'Não possui',
    'Indisponível',
    'Tarabai',
    'SP'
    );
*/


/*
// Método de gravação
objetoColaborador.gravar().then(function(){
  console.log('Gravado no Banco de Dados')
});
*/



/*
// Método para alterar informações 
objetoColaborador.nome = 'Ricardo'
objetoColaborador.cidade = 'Epitácio'


objetoColaborador.alterar().then(function(){
    console.log('Informações alteradas no banco de dados !!!')
}); 
*/



/*
// Método para consultar informações
objetoColaborador.consulta('Ricardo').then(function(ListaColaboradores){
    for(const colaborador of ListaColaboradores){
    console.log(colaborador.toJSON());
}});
*/



/*
// Método para apagar registros 
objetoColaborador.apagarColaborador().then(function(){
    console.log('Deletado no Banco de Dados com sucesso !!!')
});
*/






