import DoacaoBD from "../Persistencia/DoacaoBD.js"

export default class Doacao{
    #codDoacao
    #data
    #codDoador
    #nomeDoador
    #codItem
    #descItem
    #qtd
    #observacoes

    constructor(codDoacao,data,codDoador={},nomeDoador,codItem={},descItem,qtd,observacoes){
        this.#codDoacao = codDoacao
        this.#data = data
        this.#codDoador = codDoador
        this.#nomeDoador = nomeDoador
        this.#codItem = codItem
        this.#descItem = descItem
        this.#qtd = qtd
        this.#observacoes = observacoes
    }

    get codDoacao(){
        return this.#codDoacao
    }

    get data(){
        return this.#data
    }

    set data(novaData){
        if(novaData.length > 9){
           return this.#data = novaData
        } else {
            console.log("Data inválida")
        }   
    }

    get codDoador(){
        return this.#codDoador
    }

    set codDoador(novoCodigo){
        if(novoCodigo > 0){
        return this.#codDoador = novoCodigo
    }
    }

    get nomeDoador(){
        return this.#nomeDoador
    }
    
    set nomeDoador(novoNome){
        if(novoNome.length > 1){
            return this.#nomeDoador = novoNome
        } else {
            console.log("Nome de doador inválido")
        }
    }

    get codItem(){
        return this.#codItem
    }

    set codItem(novoCodigo){
        if(novoCodigo.length > 0 ){
            return this.#codItem = novoCodigo
        }
    }

    get descItem(){
        return this.#descItem
    }

    set descItem(novoNome){
        if(novoNome.length > 0){
            return this.#descItem = novoNome
        } else {
            console.log("Descrição inválida")
        }
    }

    get qtd(){
        return this.#qtd
    }

    set qtd(novoQtd){
        if(novoQtd > 0){
        return this.#qtd = novoQtd
    }
    }

    get observacoes(){
        return this.#observacoes
    }

    set observacoes(novaObservacao){
        return this.#observacoes = novaObservacao
    }

    toJSON(){
        return{
            "codDoacao": this.#codDoacao,
            "data": this.#data,
            "codDoador": this.#codDoador,
            "nomeDoador": this.#nomeDoador,
            "codItem": this.#codItem,
            "descItem": this.#descItem,
            "qtd":this.#qtd,
            "observacoes": this.#observacoes
        }
    }

// Métodos para interação com o banco de dados
    async gravacao(){
        const doacaoBD = new DoacaoBD()
        this.#codDoacao = await doacaoBD.gravar(this)
       
    }


    async alterar(){
        const doacaoBD = new DoacaoBD()
        await doacaoBD.alterar(this)
    }

    async excluir(){
        const doacaoBD = new DoacaoBD()
        await doacaoBD.excluir(this)
    }


    async consultar(nome){
        const doacaoBD = new DoacaoBD()
        const ListaDoacoes = await doacaoBD.consultar(nome)
        return ListaDoacoes
    }

}