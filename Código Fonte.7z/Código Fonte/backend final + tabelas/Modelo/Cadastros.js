import CadastrosBD from "../Persistencia/CadastrosBD.js";

export default class Cadastros {
    #codigo;
    #usuario;
    #senha;
    #nivel;

    constructor(codigo, usuario, senha, nivel) {
        this.#codigo = codigo;
        this.#usuario = usuario;
        this.#senha = senha;
        this.#nivel = nivel;
    }

    // Métodos de acesso (get) e modificação (set)

    // Código
    get codigo() {
        return this.#codigo;
    }

    set codigo(novoCodigo) {
        if (novoCodigo === "" || typeof novoCodigo !== "number") {
            console.log("Formato de dado inválido");
        } else {
            this.#codigo = novoCodigo;
        }
    }

    // Usuário
    get usuario() {
        return this.#usuario;
    }

    set usuario(novoUsuario) {
        if (novoUsuario === "") {
            console.log("Dado não preenchido");
        } else {
            this.#usuario = novoUsuario;
        }
    }

    // Senha
    get senha() {
        return this.#senha;
    }

    set senha(novaSenha) {
        if (novaSenha === "") {
            console.log("Dado não preenchido");
        } else {
            this.#senha = novaSenha; // Corrigido para atribuir novoTipo ao atributo #senha
        }
    }

    // Nível
    get nivel() {
        return this.#nivel;
    }

    set nivel(novoNivel) {
        if (novoNivel === "") {
            console.log("Dado não preenchido");
        } else {
            this.#nivel = novoNivel; // Corrigido para atribuir novoNivel ao atributo #nivel
        }
    }

    // JSON
    toJSON() {
        return {
            'codigo': this.#codigo,
            'usuario': this.#usuario,
            'senha': this.#senha,
            'nivel': this.#nivel,
        };
    }

    async gravar() {
        const cadastroBD = new CadastrosBD();
        this.codigo = await cadastroBD.adicionar(this);
    }

    async atualizar() {
        const cadastroBD = new CadastrosBD();
        await cadastroBD.alterar(this);
    }

    async apagar() {
        const cadastroBD = new CadastrosBD();
        await cadastroBD.deletar(this);
    }

    async consulta(usuario) {
        const cadastroBD = new CadastrosBD();
        const listaCadastros = await cadastroBD.consultar(usuario);
        return listaCadastros;
    }

    async consultarUsuario(usuario) {
        const cadastroBD = new CadastrosBD();
        const listaCadastros = await cadastroBD.consultarUsuario(usuario);
        return listaCadastros;
    }

    async autenticacao() {
        const cadastroBD = new CadastrosBD();
        await cadastroBD.autenticar(this)
        
        
    }

}