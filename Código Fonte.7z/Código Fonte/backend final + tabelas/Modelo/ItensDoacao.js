import ItensDoacaoBD from "../Persistencia/ItensDoacaoBD.js"

export default class ItensDoacao{

    #codigo
    #descricao
    #tipo

constructor(codigo,descricao,tipo){
    this.#codigo = codigo
    this.#descricao = descricao
    this.#tipo = tipo
}


    get codigo(){
        return this.#codigo
    }

    get descricao(){
        return this.#descricao
    }

    set descricao(novaDesc){
        this.#descricao = novaDesc
    }

    get tipo(){
        return this.#tipo
    }

    set tipo(novoTipo){
        this.#tipo = novoTipo
    }

    toJSON(){
        return{
            "codigo": this.#codigo,
            "descricao": this.#descricao,
            "tipo": this.#tipo
        }
    }

    async gravar(){
        const itemBD = new ItensDoacaoBD();
        this.#codigo = await itemBD.gravar(this)
    }

    async editar(){
        const itemBD = new ItensDoacaoBD();
        await itemBD.editar(this)
    }

    async excluir(){
        const itemBD = new ItensDoacaoBD();
        await itemBD.excluir(this)
    }

    async consultar(descricao){
        const itemBD = new ItensDoacaoBD();
        const ListaItens = await itemBD.consultar(descricao)
        return ListaItens
    }
}

