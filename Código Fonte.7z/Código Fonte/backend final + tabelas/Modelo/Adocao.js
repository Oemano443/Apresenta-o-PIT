import AdocaoBD from "../Persistencia/AdocaoBD.js"

export default class Adocao{
    #codigo
    #data
    #codAdotante
    #nomeAdotante
    #codAnimal
    #nomeAnimal
    #observacoes

    constructor(codigo,data,codAdotante={},nomeAdotante,codAnimal={},nomeAnimal,observacoes){
        this.#codigo = codigo
        this.#data = data
        this.#codAdotante = codAdotante
        this.#nomeAdotante = nomeAdotante
        this.#codAnimal = codAnimal
        this.#nomeAnimal = nomeAnimal
        this.#observacoes = observacoes
    }

    get codigo(){
        return this.#codigo
    }

    get data(){
        return this.#data
    }

    set data(novaData){
        if(novaData.length > 9){
           return this.#data = novaData
        } else {
            console.log("Data inválida")
        }   
    }

    get codAdotante(){
        return this.#codAdotante
    }

    set codAdotante(novoCodigo){
        if(novoCodigo > 0){
        return this.#codAdotante = novoCodigo
    }
    }

    get nomeAdotante(){
        return this.#nomeAdotante
    }
    
    set nomeAdotante(novoNome){
        if(novoNome.length > 1){
            return this.#nomeAdotante = novoNome
        } else {
            console.log("Nome de adotante inválido")
        }
    }

    get codAnimal(){
        return this.#codAnimal
    }

    set codAnimal(novoCodigo){
        if(novoCodigo.length > 0 ){
            return this.#codAnimal = novoCodigo
        }
    }

    get nomeAnimal(){
        return this.#nomeAnimal
    }

    set nomeAnimal(novoNome){
        if(novoNome.length > 0){
            return this.#nomeAnimal = novoNome
        } else {
            console.log("Nome de animal inválido")
        }
    }

    get observacoes(){
        return this.#observacoes
    }

    set observacoes(novaObservacao){
        return this.#observacoes = novaObservacao
    }

    toJSON(){
        return{
            "codigo": this.#codigo,
            "data": this.#data,
            "codAdotante": this.#codAdotante,
            "nomeAdotante": this.#nomeAdotante,
            "codAnimal": this.#codAnimal,
            "nomeAnimal": this.#nomeAnimal,
            "observacoes": this.#observacoes
        }
    }

// Métodos para interação com o banco de dados
    async gravacao(){
        const adocaoBD = new AdocaoBD()
        this.#codigo = await adocaoBD.gravar(this)
       
    }


    async alterar(){
        const adocaoBD = new AdocaoBD()
        await adocaoBD.alterar(this)
    }

    async excluir(){
        const adocaoBD = new AdocaoBD()
        await adocaoBD.excluir(this)
    }


    async consultar(nome){
        const adocaoBD = new AdocaoBD()
        const ListaAdocoes = await adocaoBD.consutar(nome)
        return ListaAdocoes
    }






 


}