import TiposDespesasBD from "../Persistencia/TipoDespesasBD.js";

export default class TiposDespesas{

    #codigo
    #descricao
    #classificacao

    constructor(codigo,descricao,classificacao){
        this.#codigo = codigo;
        this.#descricao = descricao;
        this.#classificacao = classificacao;
    }


    get codigo(){
        return this.#codigo
    }

    /*
    set codigo(novoCodigo){
        this.#codigo = novoCodigo
    }*/


    get descricao(){
        return this.#descricao
    }

    set descricao(novaDescricao){
        if(novaDescricao.length > 0){
             this.#descricao = novaDescricao
        }
    }


    get classificacao(){
        return this.#classificacao
    }

    set classificacao(novaClassificacao){
        if(novaClassificacao.length > 5){
             this.#classificacao = novaClassificacao
        }
    }


    toJSON(){
        return{
            'codigo':  this.#codigo,
            'descricao':  this.#descricao,
            'classificacao':  this.#classificacao
    }}


    async gravacao(){
       const TipoDespesasBD = new TiposDespesasBD() // para utilizar o método da classe de persistência é importante instânciá-la primeiro
       this.#codigo = await TipoDespesasBD.gravar(this)
    }

    async edicao(){
        const TipoDespesasBD = new TiposDespesasBD()
        await TipoDespesasBD.editar(this); // o this faz referência ao próprio objeto que foi instânciado pela classe TipoDespesa, ou seja, o this faz apenas a referência ao objeto específico que foi criado 
    }

    async apagar(){
        const TipoDespesasBD = new TiposDespesasBD()
        await TipoDespesasBD.excluir(this);
    }

    async consultar(descricao){
        const TipoDespesasBD = new TiposDespesasBD()
        const ListaDespesas = await TipoDespesasBD.consultar(descricao)
        return ListaDespesas;
    }

}