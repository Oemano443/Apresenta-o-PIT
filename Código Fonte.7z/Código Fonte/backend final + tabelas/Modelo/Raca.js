import RacaBD from "../Persistencia/RacaBD.js";

export default class Racas{

    #codigo;
    #descricao;

constructor(codigo,descricao){

    this.#codigo = codigo;
    this.#descricao = descricao;

}

    get codigo(){ // consulta
        return this.#codigo
    }

    get descricao(){ // consulta
        return this.#descricao
    }


    set descricao(novadesc){ // modificar
         this.#descricao = novadesc
    }

    toJSON(){
        return{
            'codigo': this.#codigo,
            'descricao': this.#descricao
        }
    }

// Métodos para banco de dados

    async gravar(){
        const racaBD = new RacaBD();
        this.#codigo = await racaBD.gravar(this);
    }

    async alterar(){
        const racaBD = new RacaBD();
        await racaBD.atualizar(this)
    }

    async consultar(descricao){
        const racaBD = new RacaBD();
        const listaRacas = await racaBD.consultar(descricao)
        return listaRacas;
    }

    async apagar(){
        const racaBD = new RacaBD();
        await racaBD.deletar(this)
    }
    

}