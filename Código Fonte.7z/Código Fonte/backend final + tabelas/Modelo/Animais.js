import AnimaisBD from "../Persistencia/AnimaisBD.js";

export default class Animais{
    #codigo_animal;
    #nome_animal;
    #raca_animal;
    #porte_animal;
    #cor_animal;
    #idade_animal;
    #temperamento_animal;
    #dataentrada_animal;
    #localizacao_animal;
    #vacinacao_animal;
    #necessidades_animal;
    #disponibilidade_animal;
    #localencontrado_animal;
    #dataadocacao_animal;

    constructor(codigo_animal,nome_animal,raca_animal,porte_animal,cor_animal,idade_animal,temperamento_animal,
                dataentrada_animal,localizacao_animal,vacinacao_animal,necessidades_animal,disponibilidade_animal,
                localencontrado_animal,dataadocao_animal){
                    this.#codigo_animal = codigo_animal;
                    this.#nome_animal = nome_animal;
                    this.#raca_animal = raca_animal;
                    this.#porte_animal = porte_animal;
                    this.#cor_animal = cor_animal;
                    this.#idade_animal = idade_animal;
                    this.#temperamento_animal = temperamento_animal;
                    this.#dataentrada_animal = dataentrada_animal;
                    this.#localizacao_animal = localizacao_animal;
                    this.#vacinacao_animal = vacinacao_animal;
                    this.#necessidades_animal = necessidades_animal;
                    this.#disponibilidade_animal = disponibilidade_animal;
                    this.#localencontrado_animal = localencontrado_animal;
                    this.#dataadocacao_animal = dataadocao_animal;
                }

    get codigo_animal(){
        return this.#codigo_animal;
    }

    set codigo_animal(novoCodigo_animal){
        this.#codigo_animal = novoCodigo_animal;
    }

    get nome_animal(){
        return this.#nome_animal;
    }

    set nome_animal(novoNome_animal){
        if (novoNome_animal != "")
            this.#nome_animal = novoNome_animal;
    }

    get raca_animal(){
        return this.#raca_animal;
    }

    set raca_animal(novoRaca_animal){
        this.#raca_animal = novoRaca_animal;
    }

    get porte_animal(){
        return this.#porte_animal;
    }

    set porte_animal(novoPorte_animal){
        this.#porte_animal = novoPorte_animal;
    }

    get cor_animal(){
        return this.#cor_animal;
    }

    set cor_animal(novoCor_animal){
        this.#cor_animal = novoCor_animal;
    }

    get idade_animal(){
        return this.#idade_animal;
    }

    set idade_animal(novoIdade_animal){
        this.#idade_animal = novoIdade_animal;
    }

    get temperamento_animal(){
        return this.#temperamento_animal;
    }

    set temperamento_animal(novoTemperamento_animal){
        this.#temperamento_animal = novoTemperamento_animal;
    }

    get dataentrada_animal(){
        return this.#dataentrada_animal;
    }

    set dataentrada_animal(novoDataentrada_animal){
        this.#dataentrada_animal = novoDataentrada_animal;
    }

    get localizacao_animal(){
        return this.#localizacao_animal;
    }

    set localizacao_animal(novoLocalizacao_animal){
        this.#localizacao_animal = novoLocalizacao_animal;
    }

    get vacinacao_animal(){
        return this.#vacinacao_animal;
    }

    set vacinacao_animal(novoVacinacao_animal){
        this.#vacinacao_animal = novoVacinacao_animal;
    }

    get necessidades_animal(){
        return this.#necessidades_animal;
    }

    set necessidades_animal(novoNecessidades_animal){
        this.#necessidades_animal = novoNecessidades_animal;
    }

    get disponibilidade_animal(){
        return this.#disponibilidade_animal;
    }

    set disponibilidade_animal(novoDisponibilidade_animal){
        this.#disponibilidade_animal = novoDisponibilidade_animal;
    }

    get localencontrado_animal(){
        return this.#localencontrado_animal;
    }

    set localencontrado_animal(novoLocalencontrado_animal){
        this.#localencontrado_animal = novoLocalencontrado_animal;
    }

    get dataadocao_animal(){
        return this.#dataadocacao_animal;
    }

    set dataadocao_animal(novoDataadocao_animal){
        this.#dataadocacao_animal = novoDataadocao_animal;
    }

    toJSON(){
        return{
            "codigo_animal": this.#codigo_animal,
            "nome_animal": this.#nome_animal,
            "raca_animal": this.#raca_animal,
            "porte_animal": this.#porte_animal,
            "cor_animal": this.#cor_animal,
            "idade_animal": this.#idade_animal,
            "temperamento_animal": this.#temperamento_animal,
            "dataentrada_animal": this.#dataentrada_animal,
            "localizacao_animal": this.#localizacao_animal,
            "vacinacao_animal": this.#vacinacao_animal,
            "necessidades_animal": this.#necessidades_animal,
            "disponibilidade_animal": this.#disponibilidade_animal,
            "localencontrado_animal": this.#localencontrado_animal,
            "dataadocao_animal": this.#dataadocacao_animal
        }
    }

    async gravar(){
        const animaisBD = new AnimaisBD();
        await animaisBD.incluir(this);
    }

    async atualizar(){
        const animaisBD = new AnimaisBD();
        await animaisBD.alterar(this);
    }

    async remover(){
        const animaisBD = new AnimaisBD();
        await animaisBD.excluir(this);
    }

    async consultar(termo){
        const animaisBD = new AnimaisBD();
        const animais = await animaisBD.consultar(termo);
        return animais;
    }

    async consultarCodigo(codigo){
        const animaisBD = new AnimaisBD();
        const animais = await animaisBD.consultarCodigo(codigo);
        return animais;
    }


}

