import DespesasBD from "../Persistencia/DespesasBD.js"

export default class Despesas{
     #codigo
     #dataLancamento
     #Codcategoria_despesa
     #dataVencimento
     #dataPagamento
     #formaPagamento
     #valor
     #vinculaAnimal
     #codigo_animal
     #observacoes
     

     constructor(codigo,dataLancamento,Codcategoria_despesa,dataVencimento,dataPagamento,formaPagamento,valor,vinculaAnimal,codigo_animal,observacoes){
        this.#codigo = codigo
        this.#dataLancamento = dataLancamento
        this.#Codcategoria_despesa = Codcategoria_despesa
        this.#dataVencimento = dataVencimento
        this.#dataPagamento = dataPagamento
        this.#formaPagamento = formaPagamento
        this.#valor = valor 
        this.#vinculaAnimal = vinculaAnimal
        this.#codigo_animal = codigo_animal
        this.#observacoes = observacoes
        
     }

     get codigo(){
        return this.#codigo
     }

     set codigo(novoCodigo){
        this.#codigo = novoCodigo
     }

     get dataLancamento(){
        return this.#dataLancamento
     }

     set dataLancamento(novaData){
        this.#dataLancamento = novaData
     }

     get Codcategoria_despesa(){
        return this.#Codcategoria_despesa
     }

     set Codcategoria_despesa(novaCategoria){
        this.#Codcategoria_despesa = novaCategoria
     }
      
     get dataVencimento(){
       return this.#dataVencimento
     }

     set dataVencimento(novaData){
         this.#dataVencimento = novaData
     }

     get dataPagamento(){
        return this.#dataPagamento
     }

     set dataPagamento(novaData){
        this.#dataPagamento = novaData
     }

     get formaPagamento(){
        return this.#formaPagamento
     }

     set formaPagamento(novoPagamento){
        this.#formaPagamento = novoPagamento
     }

     get valor(){
        return this.#valor
     }

     set valor(novoValor){
        this.#valor = novoValor
     }

    get codigo_animal(){
       return this.#codigo_animal
    } 

    set codigo_animal(novoAnimal){
        this.#codigo_animal = novoAnimal
    }

     get vinculaAnimal(){
        return this.#vinculaAnimal
     }

     get observacoes(){
      return this.#observacoes
   }

   set observacoes(novaOBS){
      this.#observacoes = novaOBS
   }

    toJSON(){
        return{                    
            "codigo" : this.#codigo,             
            "dataLancamento" :  this.#dataLancamento,
            "Codcategoria_despesa" : this.#Codcategoria_despesa, // tipo de despesas
            "dataVencimento" : this.#dataVencimento,
            "dataPagamento" :  this.#dataPagamento,
            "formaPagamento" : this.#formaPagamento,
            "valor" : this.#valor, 
            "vinculaAnimal" :  this.#vinculaAnimal,
            "codigo_animal" : this.#codigo_animal,
            "observacoes"   : this.#observacoes

        }
    }

    async gravar(){
        const despesasBD = new DespesasBD();
        await despesasBD.incluir(this)
    }

    async alterar(){
        const despesasBD = new DespesasBD();
        await despesasBD.alterar(this)
    }

    async excluir(){
        const despesasBD = new DespesasBD();
        await despesasBD.deletar(this)
    }

    async consultar(formaPagamento){
        const despesasBD = new DespesasBD();
        const ListaDespesas = await despesasBD.consultar(formaPagamento)
        return ListaDespesas
    }

    }