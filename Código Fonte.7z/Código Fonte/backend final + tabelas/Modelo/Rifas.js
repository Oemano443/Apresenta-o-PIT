import RifasBD from "../Persistencia/RifasBD.js";

export default class Rifas {
    #codigo;
    #descricao;
    #tipo;
    #premiacao;
    #dataInic;
    #dataSort;

    constructor(codigo, descricao, tipo, premiacao, dataInic, dataSort) {
        this.#codigo = codigo;
        this.#descricao = descricao;
        this.#tipo = tipo;
        this.#premiacao = premiacao;
        this.#dataInic = dataInic;
        this.#dataSort = dataSort;
    }

    // Métodos de acesso (get) e modificação (set)

    // Código
    get codigo() {
        return this.#codigo;
    }

    set codigo(novoCodigo) {
        if (novoCodigo === "" || typeof novoCodigo !== "number") {
            console.log("Formato de dado inválido");
        } else {
            this.#codigo = novoCodigo;
        }
    }

    // Descrição
    get descricao() {
        return this.#descricao;
    }

    set descricao(novaDescricao) {
        if (novaDescricao === "") {
            console.log("Dado não preenchido");
        } else {
            this.#descricao = novaDescricao;
        }
    }

    // Tipo
    get tipo() {
        return this.#tipo;
    }

    set tipo(novoTipo) {
        if (novoTipo === "") {
            console.log("Dado não preenchido");
        } else {
            this.#tipo = novoTipo; // Corrigido para atribuir novoTipo ao atributo #tipo
        }
    }

    // Premiação
    get premiacao() {
        return this.#premiacao;
    }

    set premiacao(novaPremiacao) {
        if (novaPremiacao === "") {
            console.log("Dado não preenchido");
        } else {
            this.#premiacao = novaPremiacao; // Corrigido para atribuir novaPremiacao ao atributo #premiacao
        }
    }

    // Data de Inicio
    get dataInic() {
        return this.#dataInic;
    }

    set dataInic(novaDataInic) {
        if (novaDataInic === "" || novaDataInic.length > 10) {
            console.log("Formato de data inválido");
        } else {
            this.#dataInic = novaDataInic;
        }
    }

    // Data do Sorteio
    get dataSort() {
        return this.#dataSort;
    }

    set dataSort(novaDataSort) {
        if (novaDataSort === "" || novaDataSort.length > 10) {
            console.log("Formato de data inválido");
        } else {
            this.#dataSort = novaDataSort;
        }
    }

    // JSON
    toJSON() {
        return {
            'codigo': this.#codigo,
            'descricao': this.#descricao,
            'tipo': this.#tipo,
            'premiacao': this.#premiacao,
            'dataInic': this.#dataInic,
            'dataSort': this.#dataSort
        };
    }

    async gravar() {
        const rifaBD = new RifasBD();
        this.codigo = await rifaBD.adicionar(this);
    }

    async atualizar() {
        const rifaBD = new RifasBD();
        await rifaBD.alterar(this);
    }

    async apagar() {
        const rifaBD = new RifasBD();
        await rifaBD.deletar(this);
    }

    async consulta(premiacao) {
        const rifaBD = new RifasBD();
        const listaRifa = await rifaBD.consultar(premiacao);
        return listaRifa;
    }



    async consultarPremiacao(premiacao) {
        const rifaBD = new RifasBD();
        const listaRifa = await rifaBD.consultar(premiacao);
        return listaRifa;
    }
}
