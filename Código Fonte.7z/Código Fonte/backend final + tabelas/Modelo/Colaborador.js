import ColaboradorBD from "../Persistencia/ColaboradorBD.js";


export default class Colaborador{

    #codColaborador;
    #cpf;
    #categoria;
    #nome;
    #dataNasc;
    #telefone;
    #email;
    #cep;
    #logradouro;
    #numero;
    #complemento;
    #bairro;
    #cidade;
    #uf;

    constructor(codColaborador,cpf,categoria,nome,dataNasc,telefone,email,cep,logradouro,numero,complemento,bairro,cidade,uf){
        this.#codColaborador = codColaborador;
        this.#cpf = cpf;
        this.#categoria = categoria;
        this.#nome = nome;
        this.#dataNasc = dataNasc;
        this.#telefone = telefone;
        this.#email = email;
        this.#cep = cep;
        this.#logradouro = logradouro;
        this.#numero = numero;
        this.#complemento = complemento;
        this.#bairro = bairro;
        this.#cidade = cidade;
        this.#uf = uf;
    }

    get codColaborador(){  // consultar código
        return this.#codColaborador;
    }

    set codColaborador(novoCod){  // modificar
        return this.#codColaborador = novoCod;
    }


    get cpf(){  // consultar cpf
        return this.#cpf;
    }

    //
    get categoria(){  
        return this.#categoria;
    }

    set categoria(novaCategoria){
        this.#categoria = novaCategoria;
    }
     
    //
    get nome(){  
        return this.#nome;
    }

    set nome(novoNome){
        this.#nome = novoNome;
    }

    //
    get dataNasc(){  
        return this.#dataNasc;
    }

    set dataNasc(novaData){
        this.#dataNasc = novaData;
    }
    
    //
    get telefone(){  
        return this.#telefone;
    }

    set telefone(novoNumero){
        this.#telefone = novoNumero;
    }

    //
    get email(){  
        return this.#email;
    }

    set email(novoEmail){
        this.#email = novoEmail;
    }

    //
    get cep(){  
        return this.#cep;
    }

    set cep(novoCEP){
        this.#cep = novoCEP;
    }

    //
    get logradouro(){  
        return this.#logradouro;
    }

    set logradouro(novoEndereco){
        this.#logradouro = novoEndereco;
    }

    //
    get numero(){  
        return this.#numero;
    }

    set numero(novoNumero){
        this.#numero = novoNumero;
    }

    //
    get complemento(){  
        return this.#complemento;
    }

    set complemento(novoComplemento){
        this.#complemento = novoComplemento;
    }

    //
    get bairro(){  
        return this.#bairro;
    }

    set bairro(novoBairro){
        this.#bairro = novoBairro;
    }

    //
    get cidade(){  
        return this.#cidade;
    }

    set cidade(novaCidade){
        this.#cidade = novaCidade;
    }

    //
    get uf(){  
        return this.#uf;
    }

    set uf(novaUF){
        this.#uf = novaUF;
    }


    // Objeto ToJSON
    toJSON(){
        return{

        'codColaborador' : this.#codColaborador,
        'cpf'    : this.#cpf,
        'categoria' :this.#categoria,
        'nome'   : this.#nome,
        'dataNasc': this.#dataNasc,
        'telefone': this.#telefone,
        'email': this.#email,
        'cep' : this.#cep,
        'logradouro' : this.#logradouro,
        'numero' : this.#numero,
        'complemento': this.#complemento,
        'bairro' : this.#bairro,
        'cidade' : this.#cidade,
        'uf' : this.#uf
        
     }}


     // Métodos para interação com o banco de dados

     async gravar(){
        const colaboradorBD = new ColaboradorBD();
       // await colaboradorBD.gravar(this);
        this.codColaborador = await colaboradorBD.gravar(this);
    }

    async alterar(){
        const colaboradorBD = new ColaboradorBD();
        await colaboradorBD.alteracao(this);
    }

    async consulta(nome){
        const colaboradorBD = new ColaboradorBD();
        const ListaColaboradores = await colaboradorBD.consultar(nome)
        return ListaColaboradores;
    }

    async apagarColaborador(){
        const colaboradorBD = new ColaboradorBD();
        await colaboradorBD.excluir(this);
    }

    async consultarColaborador(cpf){
        const colaboradorBD = new ColaboradorBD();
        const ListaColaboradores= await colaboradorBD.consultaCpf(cpf)
        return ListaColaboradores;
    }

    async consultarCodigo(codigo){
        const colaboradorBD = new ColaboradorBD();
        const ListaColaboradores = await colaboradorBD.consultaCodigo(codigo);
      //  console.log("Modelo: ",JSON.stringify(ListaColaboradores))
        return ListaColaboradores;
        
    }


};