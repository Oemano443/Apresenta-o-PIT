import Rifas from "../Modelo/Rifas.js";

export default class RifaControl {
    static contadorCodigo = 1;

    gravar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "POST" && requisicao.is("application/json")) {
            const dados = requisicao.body;
            const descricao = dados.descricao;
            const tipo = dados.tipo;
            const premiacao = dados.premiacao;
            const dataInic = dados.dataInic;
            const dataSort = dados.dataSort;

            if (descricao && tipo && premiacao && dataInic && dataSort) {
                const rifa = new Rifas(RifaControl.contadorCodigo, descricao, tipo, premiacao, dataInic, dataSort);
                RifaControl.contadorCodigo++;

                rifa
                    .gravar()
                    .then(() => {
                        resposta.status(200).json({
                            status: true,
                            codigo: rifa.codigo,
                            mensagem: "Rifa gravada com sucesso !!!",
                        });
                    })
                    .catch((erro) => {
                        resposta.status(500).json({
                            status: false,
                            mensagem: erro.message,
                        });
                    });
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe os dados adequadamente.",
                });
            }
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido ou formato não permitido.",
            });
        }
    }

    atualizar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "PUT" && requisicao.is("application/json")) {
            const dados = requisicao.body;
            const codigo = dados.codigo;
            const descricao = dados.descricao;
            const tipo = dados.tipo;
            const premiacao = dados.premiacao;
            const dataInic = dados.dataInic;
            const dataSort = dados.dataSort;

            if (codigo && descricao && tipo && premiacao && dataInic && dataSort) {
                const rifa = new Rifas(codigo, descricao, tipo, premiacao, dataInic, dataSort);
                rifa
                    .atualizar()
                    .then(() => {
                        resposta.status(200).json({
                            status: true,
                            mensagem: "Rifa atualizada com sucesso !!!",
                        });
                    })
                    .catch((erro) => {
                        resposta.status(500).json({
                            status: false,
                            mensagem: erro.message,
                        });
                    });
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe os dados adequadamente.",
                });
            }
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido ou formato não permitido.",
            });
        }
    }

    excluir(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "DELETE" && requisicao.is("application/json")) {
            const dados = requisicao.body;
            const codigo = dados.codigo;
            const premiacao = dados.premiacao;

            if (premiacao) {
                const rifa = new Rifas(codigo, premiacao);
                rifa
                    .apagar()
                    .then(() => {
                        resposta.status(200).json({
                            status: true,
                            mensagem: "Rifa apagada com sucesso !!!",
                        });
                    })
                    .catch((erro) => {
                        resposta.status(500).json({
                            status: false,
                            mensagem: erro.message,
                        });
                    });
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Descrição não informada.",
                });
            }
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Formato ou método inválido.",
            });
        }
    }

    consultar(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "GET") {
            const rifa = new Rifas();
            rifa.consulta('')
                .then((listaRifa) => {
                    resposta.status(200).json(listaRifa);
                })
                .catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message,
                    });
                });
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido.",
            });
        }
    }

    consultarCodigo(requisicao, resposta) {
        resposta.type("application/json");
        const codigo = requisicao.params["codigo"];

        if (requisicao.method === "GET") {
            const rifa = new Rifas();
            rifa
                .consultarCodigo(codigo)
                .then((rifa) => {
                    resposta.status(200).json(rifa);
                })
                .catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message,
                    });
                });
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido.",
            });
        }
    }
}
