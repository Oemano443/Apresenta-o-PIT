import Colaborador from "../Modelo/Colaborador.js";

export default class ColaboradorCTRL{


gravar(requisicao,resposta){
    resposta.type('application/json'); // define o cabeçalho como "Content-Type-:application/json"
    if(requisicao.method === 'POST' && requisicao.is('application/json')){ // Verifica se a requisição http é do post e se o cabeçalho da requisição está em JSON.
        const dados = requisicao.body; // dados do corpo 
        const cpf = dados.cpf
        const categoria = dados.categoria
        const nome = dados.nome
        const dataNasc = dados.dataNasc
        const telefone = dados.telefone
        const email = dados.email
        const cep = dados.cep
        const logradouro = dados.logradouro 
        const numero = dados.numero
        const complemento = dados.complemento
        const bairro = dados.bairro
        const cidade = dados.cidade
        const uf = dados.uf


        // verificar se os dados foram preenchidos
        if(cpf && categoria && nome && dataNasc && telefone && email && cep && logradouro && numero && complemento && bairro && cidade && uf){
        
         const colaborador = new Colaborador(0,cpf,categoria,nome,dataNasc,telefone,email,cep,logradouro,numero,complemento,bairro,cidade,uf); // Instânciar objeto por meio dos dados obtidos
         colaborador.gravar().then(function(){
            resposta.status(200).json({
                status:true,
                codColaborador:colaborador.codColaborador,
                mensagem:'Colaborador gravado com sucesso !!!'
            });
         }).catch(function(erro){ // O erro no servidor ...
            resposta.status(500).json({
                status:false,
                mensagem: erro.message
            })
         });

        } else{
            resposta.status(400).json({
                status:false,
                mensagem: 'Verifique se os dados foram preenchidos.'
             });
        }
    

    } else { // caso não seja json e nem POST
     resposta.status(400).json({
        status:false,
        mensagem: 'Método inválido, verifique o formato do dado.'
     })};

} 



editar(requisicao,resposta){ // editar dados
    resposta.type('application/json');
    if(requisicao.method === 'PUT' && requisicao.is('application/json')){ 
        const dados = requisicao.body; // dados do corpo
        const codColaborador = dados.codColaborador; 
        const cpf = dados.cpf;
        const categoria = dados.categoria;
        const nome = dados.nome;
        const dataNasc = dados.dataNasc;
        const telefone = dados.telefone;
        const email = dados.email;
        const cep = dados.cep;
        const logradouro = dados.logradouro ;
        const numero = dados.numero;
        const complemento = dados.complemento;
        const bairro = dados.bairro;
        const cidade = dados.cidade;
        const uf = dados.uf;
        
        if(codColaborador && cpf && categoria && nome && dataNasc && telefone && email && cep && logradouro && numero && complemento && bairro && cidade && uf){
        
        const colaborador = new Colaborador(codColaborador,cpf,categoria,nome,dataNasc,telefone,email,cep,logradouro,numero,complemento,bairro,cidade,uf);
         colaborador.alterar().then(function(){
            resposta.status(200).json({
                status:true,
                mensagem:'Dados alterados com sucesso !!!'
            });
         }).catch(function(erro){ 
            resposta.status(500).json({
                status:false,
                mensagem: erro.message
            })
         });

        } else{
            resposta.status(400).json({
                status:false,
                mensagem: 'Verifique se os dados foram preenchidos.'
             })
        }
    

    } else { 
     resposta.status(400).json({
        status:false,
        mensagem: 'Método inválido, verifique o formato do dado.'
     })};
    }


    excluir(requisicao,resposta){ // exclusão de dados
        if(requisicao.method === 'DELETE'){ 
            const dados = requisicao.body; // dados do corpo
            const codColaborador = dados.codigo; // para excluir será necessário apenas a chave primária 
            const cpf = dados.cpf;
            
            
            if(cpf || codColaborador){
            
             const colaborador = new Colaborador(codColaborador,cpf); 
             colaborador.apagarColaborador().then(function(){
                resposta.status(200).json({
                    status:true,
                    mensagem:'Dados apagados com sucesso !!!'
                });
             }).catch(function(erro){ 
                resposta.status(500).json({
                    status:false,
                    mensagem: erro.message
                })
             });

            } else{
                resposta.status(400).json({
                    status:false,
                    mensagem: 'Verifique se o CPF de registro do colaborador está correto.'
                 })
            }
        

        } else { 
         resposta.status(400).json({
            status:false,
            mensagem: 'Método inválido, verifique o formato do dado.'
         })};

    }   


    consultar(requisicao,resposta){ // consulta de dados
        resposta.type('application/json');
        if(requisicao.method === 'GET'){ 
            
             const colaborador = new Colaborador();
             colaborador.consulta('').then(function(ListaColaboradores){
                resposta.status(200).json(ListaColaboradores);

             }).catch(function(erro){ 
                resposta.status(500).json({
                    status:false,
                    mensagem: erro.message
                })
             });

            
        } else { 
         resposta.status(400).json({
            status:false,
            mensagem: 'Método inválido'
         })};
    
    }

    consultaCpf(requisicao,resposta){
        resposta.type('application/json');

        const cpf = requisicao.params['cpf'];

        if(requisicao.method === 'GET'){ 
            
             const colaborador = new Colaborador();
             colaborador.consultarColaborador(cpf).then(function(Colaboradores){
                resposta.status(200).json(Colaboradores);

             }).catch(function(erro){ 
                resposta.status(500).json({
                    status:false,
                    mensagem: erro.message
                })
             });

            
        } else { 
         resposta.status(400).json({
            status:false,
            mensagem: 'Método inválido'
         })};
    
    }
}