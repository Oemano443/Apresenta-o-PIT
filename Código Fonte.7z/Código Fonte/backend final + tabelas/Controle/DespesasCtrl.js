import Despesas from "../Modelo/Despesas.js";
import TiposDespesas from "../Modelo/TiposDespesas.js";


export default class DespesasCtrl{

    gravar(requisicao,resposta){
        
        resposta.type('application/json');
        if(requisicao.method === 'POST' && requisicao.is('application/json')){
            const dados = requisicao.body; // dados do corpo 
            const codigo = dados.codigo
            const dataLancamento = dados.dataLancamento
            const Codcategoria_despesa = dados.Codcategoria_despesa
            const dataVencimento = dados.dataVencimento
            const dataPagamento = dados.dataPagamento
            const formaPagamento = dados.formaPagamento
            const valor = dados.valor
            const vinculaAnimal = dados.vinculaAnimal
            const codigo_animal = dados.codigo_animal
            const observacoes = dados.observacoes
    

            const despesas = new Despesas(0,dataLancamento,Codcategoria_despesa,dataVencimento,dataPagamento,formaPagamento,valor,vinculaAnimal,codigo_animal,observacoes)
            despesas.gravar().then(()=>{
                resposta.json({
                status: true,
                mensagem: 'Despesa registrada com sucesso !!!'
                }) 
            }).catch((error)=>{
                resposta.json({
                 status: true,
                 mensagem: "ERRO :" + error.message
                })
         })
        }else{ 
                resposta.json({
                    status: false,
                    mensagem: 'Método não permitido !!!'
                   })
            }


        }
        
    /*
        editar(requisicao,resposta){
        
            resposta.type('application/json');
            if(requisicao.method === 'PUT' && requisicao.is('application/json')){
                const dados = requisicao.body; // dados do corpo 
                const codigo = dados.codigo
                const dataLancamento = dados.dataLancamento
                const Codcategoria_despesa = dados.Codcategoria_despesa
                const dataVencimento = dados.dataVencimento
                const dataPagamento = dados.dataPagamento
                const formaPagamento = dados.formaPagamento
                const valor = dados.valor
                const vinculaAnimal = dados.vinculaAnimal
                const codigo_animal = dados.codigo_animal
                const observacoes = dados.observacoes
                
                console.log("Corpo da requisição: ",dados)
                if(codigo && dataLancamento && Codcategoria_despesa && dataVencimento && dataPagamento && formaPagamento && valor && vinculaAnimal && codigo_animal && observacoes){
                   
                    const despesa = new Despesas(codigo,dataLancamento,Codcategoria_despesa,dataVencimento,dataPagamento,formaPagamento,valor,vinculaAnimal,codigo_animal,observacoes)
                    console.log("Classe:",JSON.stringify(despesa))
                    despesa.alterar().then(()=>{
                        resposta.json({
                            status: true,
                            mensagem: 'Despesa atualizada com sucesso !!!'
                            })
                    }).catch((error)=>{
                        resposta.json({
                         status: true,
                         mensagem: "ERRO :" + error.message
                        })
                 })
                }

            }else{ 
                resposta.json({
                    status: false,
                    mensagem: 'Método não permitido !!!'
                   })
            }
        
        }

*/

editar(requisicao,resposta){
        
    resposta.type('application/json');
    if(requisicao.method === 'PUT' && requisicao.is('application/json')){
        const dados = requisicao.body; // dados do corpo 
        const codigo = dados.codigo
        const dataLancamento = dados.dataLancamento
        const Codcategoria_despesa = dados.Codcategoria_despesa
        const dataVencimento = dados.dataVencimento
        const dataPagamento = dados.dataPagamento
        const formaPagamento = dados.formaPagamento
        const valor = dados.valor
        const vinculaAnimal = dados.vinculaAnimal
        const codigo_animal = dados.codigo_animal
        const observacoes = dados.observacoes
        
        const despesa = new Despesas(codigo,dataLancamento,Codcategoria_despesa,dataVencimento,dataPagamento,formaPagamento,valor,vinculaAnimal,codigo_animal,observacoes)
            
            despesa.alterar().then(()=>{
                resposta.json({
                    status: true,
                    mensagem: 'Despesa atualizada com sucesso !!!'
                    })
            }).catch((error)=>{
                resposta.json({
                 status: true,
                 mensagem: "ERRO :" + error.message
                })
         })
        

    }else{ 
        resposta.json({
            status: false,
            mensagem: 'Método não permitido !!!'
           })
    }

}


excluir(requisicao,resposta){
    resposta.type("application/json");
    if (requisicao.method === "DELETE" && requisicao.is('application/json')){
        const dados = requisicao.body;
        const codigo = dados.codigo;
        if (codigo){
            const despesa = new Despesas(codigo);
            despesa.excluir().then(()=>{
                resposta.status(200).json({
                    status:true,
                    mensagem:"Despesa excluída com sucesso!"
                });
            }).catch((erro)=>{
                resposta.status(500).json({
                    status:false,
                    mensagem:erro.message
                })
            })
        }
        else{
            resposta.status(400).json({
                status:false,
                mensagem:"Por favor, informe o código da despesa para efetuar a exclusão !!!"
            });
        }
    }
    else{
        resposta.status(400).json({
            status:false,
            mensagem:"Método não permitido"
        });
    }
}





        consultar(requisicao,resposta){
            resposta.type('application/json')
            if(requisicao.method === 'GET'){
                const despesa = new Despesas()
                despesa.consultar("").then((despesas)=>{
                    resposta.json(despesas)
                }).catch((error)=>{
                    resposta.status(500).json({
                        status: false,
                        mensagem: error.message
                    })
                })

            } else { 
                resposta.status(400).json({
                   status:false,
                   mensagem: 'Método inválido'
                })};
        
        }




    }


