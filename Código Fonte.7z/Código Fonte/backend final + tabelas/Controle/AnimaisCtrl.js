import Animais from '../Modelo/Animais.js';

export default class animaisCtrl{

    //gravar
    gravar(requisicao,resposta){
        resposta.type("application/json");
        if (requisicao.method === "POST" && requisicao.is('application/json')){
            const dados = requisicao.body;
            const codigo_animal = dados.codigo_animal;
            const nome_animal = dados.nome_animal;
            const raca_animal = dados.raca_animal;
            const porte_animal = dados.porte_animal;
            const cor_animal = dados.cor_animal;
            const idade_animal = dados.idade_animal;
            const temperamento_animal = dados.temperamento_animal;
            const dataentrada_animal = dados.dataentrada_animal;
            const localizacao_animal = dados.localizacao_animal;
            const vacinacao_animal = dados.vacinacao_animal;
            const necessidades_animal = dados.necessidades_animal;
            const disponibilidade_animal = dados.disponibilidade_animal;
            const localencontrado_animal = dados.localencontrado_animal;
            const dataadocao_animal = dados.dataadocao_animal;
            if (nome_animal && raca_animal && porte_animal && cor_animal && idade_animal &&
                temperamento_animal && dataentrada_animal && localizacao_animal && vacinacao_animal &&
                necessidades_animal && disponibilidade_animal && localencontrado_animal){
                    const animal = new Animais(codigo_animal, nome_animal,raca_animal,porte_animal,cor_animal,idade_animal,
                                               temperamento_animal,dataentrada_animal,localizacao_animal,vacinacao_animal,
                                               necessidades_animal,disponibilidade_animal,localencontrado_animal,
                                               dataadocao_animal);
                    animal.gravar().then(()=>{
                        resposta.status(200).json({
                            status:true,
                            mensagem:"Animal gravado com sucesso!"
                        });
                    }).catch((erro)=>{
                        resposta.status(500).json({
                            status:false,
                            mensagem:erro.message
                        })
                    });
                }
                else{
                    resposta.status(400).json({
                        status:false,
                        mensagem:"Informe adequadamente todos os dados do Animal conforme documentação da API 123"
                    });
                }
        }
    }

    atualizar(requisicao,resposta){
        resposta.type("application/json");
        if (requisicao.method === "PUT" && requisicao.is('application/json')){
            const dados = requisicao.body;
            const codigo_animal = dados.codigo_animal;
            const nome_animal = dados.nome_animal;
            const raca_animal = dados.raca_animal;
            const porte_animal = dados.porte_animal;
            const cor_animal = dados.cor_animal;
            const idade_animal = dados.idade_animal;
            const temperamento_animal = dados.temperamento_animal;
            const dataentrada_animal = dados.dataentrada_animal;
            const localizacao_animal = dados.localizacao_animal;
            const vacinacao_animal = dados.vacinacao_animal;
            const necessidades_animal = dados.necessidades_animal;
            const disponibilidade_animal = dados.disponibilidade_animal;
            const localencontrado_animal = dados.localencontrado_animal;
            const dataadocao_animal = dados.dataadocao_animal;
            if (codigo_animal && nome_animal && raca_animal && porte_animal && cor_animal && idade_animal && 
                temperamento_animal && dataentrada_animal && localizacao_animal && vacinacao_animal && 
                necessidades_animal && disponibilidade_animal && localencontrado_animal){
                    const animal = new Animais(codigo_animal,nome_animal,raca_animal,porte_animal,cor_animal,
                                               idade_animal, temperamento_animal,dataentrada_animal,
                                               localizacao_animal,vacinacao_animal, necessidades_animal,
                                               disponibilidade_animal,localencontrado_animal, dataadocao_animal);
                    animal.atualizar().then(()=>{
                        resposta.status(200).json({
                            status:true,
                            mensagem:"Animal atualizado com sucesso!"
                        });
                    }).catch((erro)=>{
                        resposta.status(500).json({
                            status:false,
                            mensagem:erro.message
                        })
                    });
                }
                else{
                    resposta.status(400).json({
                        status:false,
                        mensagem:"Informe adequadamente todos os dados do Animal conforme documentação da API 456"
                    });
                }
        }        
    }

    excluir(requisicao,resposta){
        resposta.type("application/json");
        if (requisicao.method === "DELETE" && requisicao.is('application/json')){
            const dados = requisicao.body;
            const codigo = dados.codigo_animal;
            if (codigo){
                const animal = new Animais(codigo);
                animal.remover().then(()=>{
                    resposta.status(200).json({
                        status:true,
                        mensagem:"Animal excluído com sucesso!"
                    });
                }).catch((erro)=>{
                    resposta.status(500).json({
                        status:false,
                        mensagem:erro.message
                    })
                })
            }
            else{
                resposta.status(400).json({
                    status:false,
                    mensagem:"Informe o Código do Animal conforme documentação da API"
                });
            }
        }
        else{
            resposta.status(400).json({
                status:false,
                mensagem:"Método não permitido"
            });
        }
    }

    consultar(requisicao,resposta){
        resposta.type("application/json");
        if (requisicao.method === "GET"){
            const animal = new Animais();
            animal.consultar('').then((animais)=>{
                resposta.status(200).json(animais);
            }).catch((erro)=> {
                resposta.status(500).json({
                    status:false,
                    mensagem:erro.message
                })
            });
        }
        else{
            resposta.status(400).json({
                status:false,
                mensagem:"Método não permitido"
            });
        }
    }


}