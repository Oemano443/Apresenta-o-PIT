import Colaborador from "../Modelo/Colaborador.js";
import ItensDoacao from "../Modelo/ItensDoacao.js";
import Doacao from "../Modelo/Doacao.js"

export default class DoacaoCtrl{

    /*gravar(requisicao,resposta){
        resposta.type('application/json'); // define o cabeçalho como "Content-Type-:application/json"
        if(requisicao.method === 'POST' && requisicao.is('application/json')){ // Verifica se a requisição http é do post e se o cabeçalho da requisição está em JSON.     
            const dados = requisicao.body; // dados do corpo 
            //const codDoacao = dados.codDoacao
            const data = dados.data
            const codDoador = dados.codDoador
            const nomeDoador = dados.nomeDoador
            const codItem = dados.codItem
            const descItem = dados.descItem
            const qtd = dados.qtd
            const observacoes = dados.observacoes    
          //  console.log('dados: |',JSON.stringify(dados))
    
            // verificar se os dados foram preenchidos
            if(data && codDoador && nomeDoador && codItem && descItem && qtd && observacoes){
                
                const verificar = []
                const item = new ItensDoacao(0)
                const colaborador = new Colaborador(0)
            

         const v1 =  colaborador.consultarCodigo(codDoador).then((doador)=>{
                    if(doador){
                       return doador  
                     } 
                    }).catch((erro)=>{ // O erro no servidor ... colaborador
                        resposta.status(500).json({
                            status:false,
                            mensagem: erro.message
                        })
                     })
                    

        const v2 =  item.consultarCodigo(codItem).then((itens)=>{
                        if(itens){
                              return itens
                        }
                    }).catch((erro)=>{ // O erro no servidor ... // animais
                                    resposta.status(500).json({
                                        status:false,
                                        mensagem: erro.message
                                    })
                                 })
                                
                    verificar.push(v1,v2)    // adiciona funções de consulta das classes para verificar na promisse abaixo        
                    Promise.all(verificar).then((resultados)=>{ // resolve as promisses dos métodos das classes colaboradores e animais
                        const resultado1 = resultados[0]
                        const resultado2 = resultados[1]

                        if(resultado1 && resultado2){ // --

                        const doacaoObjt = new Doacao(data,resultado1,nomeDoador,resultado2,descItem,qtd,observacoes)        
                        doacaoObjt.gravar().then(()=>{
                          
                          resposta.status(200).json({
                             status:true,
                             //codDoacao : doacaoObjt.codDoacao,
                             mensagem:'Doação realizada com sucesso !!!'
                            })
                            
                     }).catch(function(erro){ // O erro no servidor ... // adocao
                         resposta.status(500).json({
                             status:false,
                             mensagem: erro.message
                         })
                      })
                    } // ---

                    }).catch((error)=>{
                        console.log(error)
                    })
                 } else {
                    resposta.status(400).json({
                        status:false,
                        mensagem: 'Verifique se os dados foram preenchidos.'
                     });

                 }



        } else {
            resposta.status(400).json({
                status:false,
                mensagem: 'Método inválido, verifique o formato do dado.'
             })
        }
        
        }*/

    
    gravar(requisicao,resposta){
        resposta.type("application/json");
        if (requisicao.method === "POST" && requisicao.is('application.json')){
            const dados = requisicao.body;
            const codDoacao = dados.codDoacao;
            const data = dados.data;
            const codDoador = dados.codDoador;
            const nomeDoador = dados.nomeDoador;
            const codItem = dados.codItem;
            const descItem = dados.descItem;
            const qtd = dados.qtd;
            const observacoes = dados.observacoes;
            if (data && codDoador && nomeDoador && codItem && descItem && qtd && observacoes){
                const doacaoObjt = new Doacao(codDoacao,data, codDoador, nomeDoador, codItem, descItem, qtd, observacoes);
                doacaoObjt.gravacao().then(()=>{
                    resposta.status(200).json({
                        status:true,
                        mensagem: "Doação registrada com sucesso!"
                    });
                }).catch((erro)=>{
                    resposta.status(500).json({
                        status:false,
                        mensagem: erro.message
                    })
                });
            }
            else{
                resposta.status(400).json({
                    status:false,
                    mensagem:"Informe adequadamente todos os dados!"
                });
            }
        }
    }



    /*editar(requisicao,resposta){
        resposta.type('application/json'); // define o cabeçalho como "Content-Type-:application/json"
        if(requisicao.method === 'PUT' && requisicao.is('application/json')){ // Verifica se a requisição http é do post e se o cabeçalho da requisição está em JSON.     
            const dados = requisicao.body; // dados do corpo 
            const codDoacao = dados.codDoacao
            const data = dados.data
            const codDoador = dados.codDoador
            const nomeDoador = dados.nomeDoador
            const codItem = dados.codItem
            const descItem = dados.descItem
            const qtd = dados.qtd
            const observacoes = dados.observacoes    
          //  console.log('dados: |',JSON.stringify(dados))
    
            // verificar se os dados foram preenchidos
            if(data && codDoador && nomeDoador && codItem && descItem && qtd && observacoes){
                
                const verificar = []
                const item = new ItensDoacao(0)
                const colaborador = new Colaborador(0)
            

         const v1 =  colaborador.consultarCodigo(codDoador).then((doador)=>{
                    if(doador){
                       return doador  
                     } 
                    }).catch((erro)=>{ // O erro no servidor ... colaborador
                        resposta.status(500).json({
                            status:false,
                            mensagem: erro.message
                        })
                     })
                    

        const v2 =  item.consultarCodigo(codItem).then((itens)=>{
                        if(itens){
                              return itens
                        }
                    }).catch((erro)=>{ // O erro no servidor ... // animais
                                    resposta.status(500).json({
                                        status:false,
                                        mensagem: erro.message
                                    })
                                 })
                                
                    verificar.push(v1,v2)    // adiciona funções de consulta das classes para verificar na promisse abaixo        
                    Promise.all(verificar).then((resultados)=>{ // resolve as promisses dos métodos das classes colaboradores e animais
                        const resultado1 = resultados[0]
                        const resultado2 = resultados[1]
                        
                        if(resultado1 && resultado2){ // --

                        const doacaoObjt = new Doacao(codDoacao,data,resultado1,nomeDoador,resultado2,descItem,qtd,observacoes)        
                        doacaoObjt.alterar().then(()=>{
                          
                          resposta.status(200).json({
                             status:true,
                             mensagem:'Dados de doação atualizados com sucesso !!!'
                            })
                            
                     }).catch(function(erro){ // O erro no servidor ... // adocao
                         resposta.status(500).json({
                             status:false,
                             mensagem: erro.message
                         })
                      })
                    } // ---

                    }).catch((error)=>{
                        console.log(error)
                    })
                 } else {
                    resposta.status(400).json({
                        status:false,
                        mensagem: 'Verifique se os dados foram preenchidos.'
                     });

                 }



        } else {
            resposta.status(400).json({
                status:false,
                mensagem: 'Método inválido, verifique o formato do dado.'
             })
        }
        
        }*/

        editar(requisicao,resposta){
            resposta.type("application/json");
            if (requisicao.method === "PUT" && requisicao.is('application.json')){
                const dados = requisicao.body;
                const codDoacao = dados.codDoacao;
                const data = dados.data;
                const codDoador = dados.codDoador;
                const nomeDoador = dados.nomeDoador;
                const codItem = dados.codItem;
                const descItem = dados.descItem;
                const qtd = dados.qtd;
                const observacoes = dados.observacoes;
                if (data && codDoador && nomeDoador && codItem && descItem && qtd && observacoes){
                    const doacaoObjt = new Doacao(codDoacao,data, codDoador, nomeDoador, codItem, descItem, qtd, observacoes);
                    doacaoObjt.alterar().then(()=>{
                        resposta.status(200).json({
                            status:true,
                            mensagem: "Doação atualizada com sucesso!"
                        });
                    }).catch((erro)=>{
                        resposta.status(500).json({
                            status:false,
                            mensagem: erro.message
                        })
                    });
                }
                else{
                    resposta.status(400).json({
                        status:false,
                        mensagem:"Informe adequadamente todos os dados!"
                    });
                }
            }
        }
    



        excluir(requisicao,resposta){
            resposta.type("application/json")
            if(requisicao.method === 'DELETE'){
                const dados = requisicao.body
                const codDoacao = dados.codDoacao
            
            if(codDoacao){
                const doacaoObjt = new Doacao(codDoacao)
                doacaoObjt.excluir().then(()=>{
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Dados excluídos com sucesso !!!"
                    })
                }).catch((error)=>{
                    resposta.status(500).json({
                        status: false,
                        mensagem: error.message
                    })
                })
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Verifique se os dados foram preenchidos"
                })
            }


            } else{
                resposta.status(400).json({
                    status: false,
                    mensagem: "Método inválido !!!"
                })
            }
        }


        consultar(requisicao,resposta){
            resposta.type("application/json")
            if(requisicao.method === "GET"){
                const doacaoObjt = new Doacao();
                doacaoObjt.consultar("").then((doacoes)=>{
                    resposta.status(200).json(doacoes)
                }).catch((error)=>{
                    resposta.status(500).json({
                        status: false,
                        mensagem: error.message
                    })
                })
            } else { 
                resposta.status(400).json({
                   status:false,
                   mensagem: 'Método inválido'
                })};
        }


    } // classe
            
            
          




             


        
