import Colaborador from "../Modelo/Colaborador.js";
import Animais from "../Modelo/Animais.js";
import Adocao from "../Modelo/Adocao.js";

export default class AdocaoCtrl{

    gravar(requisicao,resposta){
        resposta.type('application/json'); // define o cabeçalho como "Content-Type-:application/json"
        if(requisicao.method === 'POST' && requisicao.is('application/json')){ // Verifica se a requisição http é do post e se o cabeçalho da requisição está em JSON.     
            const dados = requisicao.body; // dados do corpo 
           // const codigo = dados.codigo
            const data = dados.data
            const codAdotante = dados.codAdotante
            const nomeAdotante = dados.nomeAdotante
            const codAnimal = dados.codAnimal
            const nomeAnimal = dados.nomeAnimal
            const observacoes = dados.observacoes    
          //  console.log('dados: |',JSON.stringify(dados))
    
            // verificar se os dados foram preenchidos
            if(data && codAdotante && nomeAdotante && codAnimal && nomeAnimal && observacoes){
                
                const verificar = []
                const animal = new Animais(0)
                const colaborador = new Colaborador(0)
            

         const v1 =  colaborador.consultarCodigo(codAdotante).then((adotante)=>{
                    if(adotante){
                       return adotante  
                     } 
                    }).catch((erro)=>{ // O erro no servidor ... colaborador
                        resposta.status(500).json({
                            status:false,
                            mensagem: erro.message
                        })
                     })
                    

        const v2 =  animal.consultarCodigo(codAnimal).then((animais)=>{
                        if(animais){
                              return animais
                        }
                    }).catch((erro)=>{ // O erro no servidor ... // animais
                                    resposta.status(500).json({
                                        status:false,
                                        mensagem: erro.message
                                    })
                                 })
                                
                    verificar.push(v1,v2)    // adiciona funções de consulta das classes para verificar na promisse abaixo        
                    Promise.all(verificar).then((resultados)=>{ // resolve as promisses dos métodos das classes colaboradores e animais
                        const resultado1 = resultados[0]
                        const resultado2 = resultados[1]

                        if(resultado1 && resultado2){ // --

                        const adocaoObjt = new Adocao(0,data,resultado1,nomeAdotante,resultado2,nomeAnimal,observacoes)        
                        adocaoObjt.gravacao().then(()=>{
                          
                          resposta.status(200).json({
                             status:true,
                             codigo : adocaoObjt.codigo,
                             mensagem:'Adoção realizada com sucesso !!!'
                            })
                            
                     }).catch(function(erro){ // O erro no servidor ... // adocao
                         resposta.status(500).json({
                             status:false,
                             mensagem: erro.message
                         })
                      })
                    } // ---

                    }).catch((error)=>{
                        console.log(error)
                    })
                 } else {
                    resposta.status(400).json({
                        status:false,
                        mensagem: 'Verifique se os dados foram preenchidos.'
                     });

                 }



        } else {
            resposta.status(400).json({
                status:false,
                mensagem: 'Método inválido, verifique o formato do dado.'
             })
        }
        
        }






    editar(requisicao,resposta){
        resposta.type('application/json'); // define o cabeçalho como "Content-Type-:application/json"
        if(requisicao.method === 'PUT' && requisicao.is('application/json')){ // Verifica se a requisição http é do post e se o cabeçalho da requisição está em JSON.     
            const dados = requisicao.body; // dados do corpo 
            const codigo = dados.codigo
            const data = dados.data
            const codAdotante = dados.codAdotante
            const nomeAdotante = dados.nomeAdotante
            const codAnimal = dados.codAnimal
            const nomeAnimal = dados.nomeAnimal
            const observacoes = dados.observacoes    
          //  console.log('dados: |',JSON.stringify(dados))
    
            // verificar se os dados foram preenchidos
            if(data && codAdotante && nomeAdotante && codAnimal && nomeAnimal && observacoes){
                
                const verificar = []
                const animal = new Animais(0)
                const colaborador = new Colaborador(0)
            

         const v1 =  colaborador.consultarCodigo(codAdotante).then((adotante)=>{
                    if(adotante){
                       return adotante  
                     } 
                    }).catch((erro)=>{ // O erro no servidor ... colaborador
                        resposta.status(500).json({
                            status:false,
                            mensagem: erro.message
                        })
                     })
                    

        const v2 =  animal.consultarCodigo(codAnimal).then((animais)=>{
                        if(animais){
                              return animais
                        }
                    }).catch((erro)=>{ // O erro no servidor ... // animais
                                    resposta.status(500).json({
                                        status:false,
                                        mensagem: erro.message
                                    })
                                 })
                                
                    verificar.push(v1,v2)    // adiciona funções de consulta das classes para verificar na promisse abaixo        
                    Promise.all(verificar).then((resultados)=>{ // resolve as promisses dos métodos das classes colaboradores e animais
                        const resultado1 = resultados[0]
                        const resultado2 = resultados[1]
                        
                        if(resultado1 && resultado2){ // --

                        const adocaoObjt = new Adocao(codigo,data,resultado1,nomeAdotante,resultado2,nomeAnimal,observacoes)        
                        adocaoObjt.alterar().then(()=>{
                          
                          resposta.status(200).json({
                             status:true,
                             mensagem:'Dados de adoção atualizados com sucesso !!!'
                            })
                            
                     }).catch(function(erro){ // O erro no servidor ... // adocao
                         resposta.status(500).json({
                             status:false,
                             mensagem: erro.message
                         })
                      })
                    } // ---

                    }).catch((error)=>{
                        console.log(error)
                    })
                 } else {
                    resposta.status(400).json({
                        status:false,
                        mensagem: 'Verifique se os dados foram preenchidos.'
                     });

                 }



        } else {
            resposta.status(400).json({
                status:false,
                mensagem: 'Método inválido, verifique o formato do dado.'
             })
        }
        
        }



        excluir(requisicao,resposta){
            resposta.type("application/json")
            if(requisicao.method === 'DELETE'){
                const dados = requisicao.body
                const codigo = dados.codigo
            
            if(codigo){
                const adocaoObjt = new Adocao(codigo)
                adocaoObjt.excluir().then(()=>{
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Dados excluídos com sucesso !!!"
                    })
                }).catch((error)=>{
                    resposta.status(500).json({
                        status: false,
                        mensagem: error.message
                    })
                })
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Verifique se os dados foram preenchidos"
                })
            }


            } else{
                resposta.status(400).json({
                    status: false,
                    mensagem: "Método inválido !!!"
                })
            }
        }


        consultar(requisicao,resposta){
            resposta.type("application/json")
            if(requisicao.method === "GET"){
                const adocaoObjt = new Adocao();
                adocaoObjt.consultar("").then((adocoes)=>{
                    resposta.status(200).json(adocoes)
                }).catch((error)=>{
                    resposta.status(500).json({
                        status: false,
                        mensagem: error.message
                    })
                })
            } else { 
                resposta.status(400).json({
                   status:false,
                   mensagem: 'Método inválido'
                })};
        }



























    } // classe
            
            
          




             


        
