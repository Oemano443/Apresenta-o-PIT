import TiposDespesas from "../Modelo/TiposDespesas.js"


export default class TipoDespesaCtrl{

    gravar(requisicao,resposta){
        resposta.type('application/json');
        if(requisicao.method === 'POST' && requisicao.is('application/json')){
            const dados = requisicao.body;
           // const codigo = dados.codigo;
            const descricao = dados.descricao;
            const classificacao = dados.classificacao;
      
        // verificar se tudo que está no corpo da requisição está preenchido
        if(descricao && classificacao){
            const tipoDespesa = new TiposDespesas(0,descricao,classificacao)
            tipoDespesa.gravacao().then(()=>{
                resposta.status(200).json({
                    status: true,
                    codigo: tipoDespesa.codigo,
                    mensagem: 'Despesa Gravada com sucesso !!!'
                });
            }).catch((error)=>{
                resposta.status(500).json({
                    status:false,
                    mensagem: error.message
                })
            })
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: 'Verifique se os dados foram preenchidos !!!'
            })
        }}}

    editar(requisicao,resposta){
            resposta.type('application/json')
            if(requisicao.method === 'PUT' && requisicao.is('application/json')){
                const dados = requisicao.body;
                const codigo = dados.codigo;
                const descricao = dados.descricao;
                const classificacao = dados.classificacao;

                if(codigo,descricao,classificacao){
                    const tipoDespesa = new TiposDespesas(codigo,descricao,classificacao)
                    tipoDespesa.edicao().then(()=>{
                        resposta.status(200).json({
                            status:true,
                            mensagem: "Dados alterados com sucesso !!!"
                        })
                    }).catch((error)=>{
                        resposta.status(500).json({
                            status: false,
                            mensagem: error.message
                        })
                    })

                } else {
                    resposta.status(400).json({
                        status: false,
                        mensagem: 'Por favor, verifique se os dados foram preenchidos corretamente !!!'
                    })};
            }}


    excluir(requisicao,resposta){
        resposta.type("application/json")
        if(requisicao.method === 'DELETE' && requisicao.is('application/json')){
            const dados = requisicao.body
            const codigo = dados.codigo;
            
            const tipoDespesa = new TiposDespesas(codigo)
            tipoDespesa.apagar().then(()=>{
                resposta.status(200).json({
                    status:true,
                    mensagem:'Dados apagados com sucesso !!!'
                })
        }).catch((error)=>{
            resposta.json({
                status: false,
                mensagem: error.message
            })
        })
    } else {
        resposta.status(400).json({
            status:false,
            mensagem: 'Código não encontrado.'
         })
    }}

    consulta(requisicao,resposta){
        resposta.type('application/json')
        if(requisicao.method === 'GET'){
            const tipoDespesa = new TiposDespesas()
            tipoDespesa.consultar('').then((listaDespesa)=>{
                resposta.status(200).json(listaDespesa)
        }).catch((error)=>{
            resposta.status(500).json({
                status:false,
                mensagem: error.message
            })
        })
            } else {
                resposta.status(400).json({
                    status:false,
                    mensagem: 'Método inválido !!!'
                 })
        }}
        
    }


