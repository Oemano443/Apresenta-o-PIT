import { json } from "express";
import Cadastros from "../Modelo/Cadastros.js";
import CadastrosBD from "../Persistencia/CadastrosBD.js";

export default class CadastrosControl {
    static contadorCodigo = 1;

    gravar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "POST" && requisicao.is("application/json")) {
            const dados = requisicao.body;
            const usuario = dados.usuario;
            const senha = dados.senha;
            const nivel = dados.nivel;

            if (usuario && senha && nivel) {
                const cadastro = new Cadastros(CadastrosControl.contadorCodigo, usuario, senha, nivel);
                CadastrosControl.contadorCodigo++;

                cadastro
                    .gravar()
                    .then(() => {
                        resposta.status(200).json({
                            status: true,
                            codigo: cadastro.codigo,
                            mensagem: "Usuário gravado com sucesso !!!",
                        });
                    })
                    .catch((erro) => {
                        resposta.status(500).json({
                            status: false,
                            mensagem: erro.message,
                        });
                    });
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe os dados adequadamente.",
                });
            }
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido ou formato não permitido.",
            });
        }
    }

    atualizar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "PUT" && requisicao.is("application/json")) {
            const dados = requisicao.body;
            const codigo = dados.codigo;
            const usuario = dados.usuario;
            const senha = dados.senha;
            const nivel = dados.nivel;

            if (codigo && usuario && senha && nivel) {
                const cadastro = new Cadastros(codigo, usuario, senha, nivel);
                cadastro
                    .atualizar()
                    .then(() => {
                        resposta.status(200).json({
                            status: true,
                            mensagem: "cadastro atualizado com sucesso !!!",
                        });
                    })
                    .catch((erro) => {
                        resposta.status(500).json({
                            status: false,
                            mensagem: erro.message,
                        });
                    });
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe os dados adequadamente.",
                });
            }
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido ou formato não permitido.",
            });
        }
    }

    excluir(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "DELETE" && requisicao.is("application/json")) {
            const dados = requisicao.body;
            const codigo = dados.codigo;
            const usuario = dados.usuario;

            if (usuario) {
                const cadastro = new Cadastros(codigo, usuario);
                cadastro
                    .apagar()
                    .then(() => {
                        resposta.status(200).json({
                            status: true,
                            mensagem: "cadastro apagado com sucesso !!!",
                        });
                    })
                    .catch((erro) => {
                        resposta.status(500).json({
                            status: false,
                            mensagem: erro.message,
                        });
                    });
            } else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Descrição não informada.",
                });
            }
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Formato ou método inválido.",
            });
        }
    }

    consultar(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "GET") {
            const cadastro = new Cadastros();
            cadastro.consulta('')
                .then((listaCadastros) => {
                    resposta.status(200).json(listaCadastros);
                })
                .catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message,
                    });
                });
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido.",
            });
        }
    }

    consultarCodigo(requisicao, resposta) {
        resposta.type("application/json");
        const codigo = requisicao.params["codigo"];

        if (requisicao.method === "GET") {
            const cadastro = new Cadastros();
            cadastro.consultarUsuario(codigo)
                .then((cadastro) => {
                    resposta.status(200).json(cadastro);
                })
                .catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message,
                    });
                });
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método inválido.",
            });
        }
    }


    autenticar(requisicao,resposta){
        resposta.type('application/json');
        if(requisicao.method === "POST" /*&& requisicao.is('application/json') */ ){
        const dados = requisicao.body;
        const usuario = dados.usuario;
        const senha = dados.senha
        
     
    if (usuario && senha) {
        const cadastroBD = new CadastrosBD()
        cadastroBD.autenticar(usuario,senha)
        .then((resp)=>{
            console.log(resp[0])
          // consulta do banco de dados
            if(resp[0] == [] || resp[0] === undefined){
                resposta.status(400).json({
                    status: false,
                    mensagem: 'Esse usuário não existe !!!'
                    })
                    return false
            } else {
                resposta.status(200).json(
                    {status:true,
                    mensagem: 'Usuário Encontrado !!!'})
                    return true
            }
            
            
             
        })        
        .catch((error)=>{
            resposta.status(500).json({
                status: false,
                mensagem: error.message
            });
        })
       
    } else {
        resposta.status(401).json({
            status: false,
            mensagem: 'Método inválido, verifique se os dados foram preenchidos corretamente !!!'
        })
        
    }
}}


}


