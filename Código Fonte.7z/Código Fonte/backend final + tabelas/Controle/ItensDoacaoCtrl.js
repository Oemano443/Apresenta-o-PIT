import ItensDoacao from "../Modelo/ItensDoacao.js";

export default class ItensDoacaoCtrl{

    gravar(requisicao,resposta){
        resposta.type('application/json')
        if(requisicao.method === 'POST' && requisicao.is('application/json')){
            const dados = requisicao.body
            const descricao = dados.descricao
            const tipo = dados.tipo
            if(descricao && tipo){
                const item = new ItensDoacao(0,descricao,tipo)
                item.gravar().then(()=>{
                    resposta.status(200).json({
                        status:true,
                        codigo: item.codigo,
                        mensagem: 'Item gravado com sucesso !!!'
                    })
                }).catch((error)=>{
                    resposta.status(500).json({
                        status:false,
                        mensagem: error.message
                    })
                })
            }else{
                resposta.status(400).json({
                    status: false,
                    mensagem: 'Por favor, verifique se os dados foram preenchidos !!!'
                })
            }
        }}



    editar(requisicao,resposta){
            resposta.type('application/json')
            if(requisicao.method === 'PUT' && requisicao.is('application/json')){
                const dados = requisicao.body
                const codigo = dados.codigo
                const descricao = dados.descricao
                const tipo = dados.tipo
                if(codigo && descricao && tipo){
                    const item = new ItensDoacao(codigo,descricao,tipo);
                    item.editar().then(()=>{
                        resposta.status(200).json({
                            status:false,
                            mensagem: "Dados alterados com sucesso !!!"     
                        })
                    }).catch((error)=>{
                        resposta.status(500).json({
                            status: false,
                            mensagem: error.message
                        })
                    }) 

                    } else{
                        resposta.status(400).json({
                            status: false,
                            mensagem: 'Por favor, verifique se os dados foram preenchidos !!!'
                        })
                    }}
                }


    excluir(requisicao,resposta){
                    resposta.type('application/json')
                    if(requisicao.method === 'DELETE' && requisicao.is('application/json')){
                        const dados = requisicao.body
                        const codigo = dados.codigo

                        if(codigo){
                            const item = new ItensDoacao(codigo)
                            item.excluir().then(()=>{
                                resposta.status(200).json({
                                    status: true,
                                    mensagem: 'Item excluído com sucesso !!!'
                                })
                            }).catch((error)=>{
                                resposta.status(500).json({
                                    status: false,
                                    mensagem: error.message
                                })
                            })
                        } else{
                            resposta.status(400).json({
                                status: false,
                                mensagem: 'Por favor, verifique se os dados foram preenchidos !!!'
                            })
                        }
                    }}


    consultar(requisicao,resposta){
        resposta.type('application/json')
        if(requisicao.method === 'GET'){
            const item = new ItensDoacao();
            item.consultar('').then((listaItens)=>{
                resposta.status(200).json(listaItens)
            }).catch((error)=>{
                resposta.status(500).json({
                    status: false,
                    mensagem: error.message
                })
            })
        } else {
            resposta.status(400).json({
                status: false,
                mensagem: 'Método inválido !!!'
            })
        }
    }                


        }


