import Racas from "../Modelo/Raca.js";

export default class RacaCTRL{


    gravar(requisicao,resposta){
       resposta.type('application/json');
       if(requisicao.method === "POST" && requisicao.is('application/json')){
        const dados = requisicao.body  
        const descricao = dados.descricao

        if(descricao){
            const raca = new Racas(0,descricao)
            raca.gravar().then(()=>{
                resposta.status(200).json({
                    status:true,
                    codigo: raca.codigo,
                    mensagem: 'Raça registrada com sucesso !!!'
                });
            }).catch((erro)=>{
                resposta.status(500).json({
                    status:false,
                    mensagem: erro.message
                })
            })
        } else {
            resposta.status(400).json({
                status:false,
                mensagem: 'Verifique se os dados foram preenchidos.'
             });
        }
        
    }
}

editar(requisicao,resposta){
    resposta.type('application/json');
    if(requisicao.method === 'PUT' && requisicao.is('application/json')){
        const dados = requisicao.body  
        const codigo = dados.codigo
        const descricao = dados.descricao

        if(descricao){
            const raca = new Racas(codigo,descricao)
            
            raca.alterar().then(()=>{
                resposta.status(200).json({
                    status:true,
                    mensagem:'Dados alterados com sucesso !!!'
                });
             }).catch(function(erro){ 
                resposta.status(500).json({
                    status:false,
                    mensagem: erro.message
                })
             });
    
            } else{
                resposta.status(400).json({
                    status:false,
                    mensagem: 'Verifique se os dados foram preenchidos.'
                 })
            }
        
    
        } else { 
         resposta.status(400).json({
            status:false,
            mensagem: 'Método inválido, verifique o formato do dado.'
         })};

            
    }

    excluir(requisicao,resposta){ // exclusão de dados
        if(requisicao.method === 'DELETE' && requisicao.is('application/json')){ 
            const dados = requisicao.body; 
            const codigo = dados.codigo
            if(codigo){
                const raca = new Racas(codigo);
                raca.apagar().then(()=>{
                    resposta.status(200).json({
                        status:true,
                        mensagem:'Dados apagados com sucesso !!!'
                    });
                 }).catch(function(erro){ 
                    resposta.status(500).json({
                        status:false,
                        mensagem: erro.message
                    })
                 });
    
                } else{
                    resposta.status(400).json({
                        status:false,
                        mensagem: 'Verifique se oódigo está correto.'
                     })
                }
            
    
            } else { 
             resposta.status(400).json({
                status:false,
                mensagem: 'Método inválido, verifique o formato do dado.'
             })
                }
            }
    
    
        
    

        consultar(requisicao,resposta){
            resposta.type('application/json');
            if(requisicao.method === 'GET'){ 
                
                 const raca = new Racas();
                 raca.consultar('').then((listaRacas) => {
                    resposta.status(200).json(listaRacas);
    
                 }).catch((erro) => { 
                    resposta.status(500).json({
                        status:false,
                        mensagem: erro.message
                    })
                 });
    
                
            } else { 
             resposta.status(400).json({
                status:false,
                mensagem: 'Método inválido'
             })
            }
        
        }
    
    }
    
             
        
        
        
        
        
        










