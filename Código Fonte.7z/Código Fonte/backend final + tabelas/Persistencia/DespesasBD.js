import Despesas from "../Modelo/Despesas.js"
import conectar from "./conexao.js"
import Animais from "../Modelo/Animais.js"
import TiposDespesas from "../Modelo/TiposDespesas.js"

export default class DespesasBD{

    async incluir(despesa){
        if(despesa instanceof Despesas){
            const conexao = await conectar();
            const sql = 'INSERT INTO despesas ( dataLancamento, Codcategoria_despesa, dataVencimento, dataPagamento, formaPagamento, valor, vinculaAnimal, codigo_animal, observacoes) \
                VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)';
            const valores = [despesa.dataLancamento,despesa.Codcategoria_despesa,despesa.dataVencimento,despesa.dataPagamento,despesa.formaPagamento,despesa.valor,despesa.vinculaAnimal,despesa.codigo_animal,despesa.observacoes];
            const resultado = await conexao.query(sql, valores);
           // return resultado[0].insertId;
           despesa.codigo = resultado[0].insertId
            }}

    async alterar(despesa) {
        
        if (despesa instanceof Despesas) {
            const conexao = await conectar();

            const sql = 'UPDATE despesas SET dataLancamento = ?, Codcategoria_despesa = ?, dataVencimento = ?, dataPagamento = ?, formaPagamento = ?, valor = ?, vinculaAnimal = ?,codigo_animal = ?, observacoes = ? WHERE codigo=?';
            const valores = [despesa.dataLancamento,despesa.Codcategoria_despesa,despesa.dataVencimento,despesa.dataPagamento,despesa.formaPagamento,despesa.valor,despesa.vinculaAnimal,despesa.codigo_animal,despesa.observacoes,despesa.codigo];
            await conexao.query(sql, valores);
        }
    }

    async deletar(despesa) {
        if (despesa instanceof Despesas) {
            const conexao = await conectar();
            const sql = 'DELETE FROM despesas WHERE codigo=?';
            const valores = [despesa.codigo];
            await conexao.query(sql, valores);
        }
    }


    async consultar(termo) {
        const listaDespesas = [];
        const conexao = await conectar();
      //  const sql = 'SELECT * FROM despesas as d INNER JOIN tipodespesa as t ON d.Codcategoria_despesa = t.codigo WHERE d.codigo = d.codigo' ;
      const sql = 'SELECT * FROM despesas WHERE formaPagamento LIKE ?';
      const valores = ["%" + termo + "%"]
        const [rowsDespesas] = await conexao.query(sql,valores);
        for (const rowsDespesa of rowsDespesas) {
            
            const despesas = new Despesas(rowsDespesa['codigo'],rowsDespesa ['dataLancamento'], rowsDespesa['Codcategoria_despesa'], rowsDespesa['dataVencimento'], rowsDespesa['dataPagamento'], rowsDespesa['formaPagamento'], rowsDespesa['valor'], rowsDespesa['vinculaAnimal'], rowsDespesa['codigo_animal'], rowsDespesa['observacoes']);
        if(despesas.codigo_animal ===  null || despesas.codigo_animal == "" && despesas.observacoes === null || despesas.observacoes == ""){
                despesas.codigo_animal = 0
                despesas.observacoes = ""
                }
                listaDespesas.push(despesas)
        }
        return listaDespesas;
    }

}