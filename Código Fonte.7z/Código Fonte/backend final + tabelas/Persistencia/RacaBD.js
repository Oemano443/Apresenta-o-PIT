import conectar from "./conexao.js";
import Racas from "../Modelo/Raca.js";

export default class RacaBD{
 
    // Gravar
    async gravar(raca){
        if(raca instanceof Racas){

    const conexao = await conectar();
    const bd = 'INSERT INTO racas(descricao) \ VALUES(?)'

        const valores = [raca.descricao]
        const resultado = await conexao.query(bd,valores); 
        return await resultado[0].insertId;

        }
    }


    // Atualizar
    async atualizar(raca){
        if(raca instanceof Racas){

    const conexao = await conectar();
    
    const bd = "UPDATE racas SET descricao = ?  WHERE codigo = ?";
    //const bd = "UPDATE racas SET descricao = ? \ WHERE codigo = ?"

        const valores = [raca.descricao,raca.codigo]
        console.log(valores)
        await conexao.query(bd,valores);


        }
    }


    // Deletar
    async deletar(raca){
        if(raca instanceof Racas){

    const conexao = await conectar();
    const bd = "DELETE FROM racas \ WHERE codigo = ?";
        
        const valores = [raca.codigo]
        await conexao.query(bd,valores);

        }
    }

    // Consultar
    async consultar(descricao){
        const conexao = await conectar();
        const bd = "SELECT * FROM racas WHERE descricao LIKE ?"
        const valores = ['%'+ descricao +'%']
        const [rows] = await conexao.query(bd,valores)
        const listaRacas = []
        for(const row of rows ){
            const raca = new Racas(row['codigo'],row['descricao']);
            listaRacas.push(raca)
        }
        return listaRacas;
    }


}