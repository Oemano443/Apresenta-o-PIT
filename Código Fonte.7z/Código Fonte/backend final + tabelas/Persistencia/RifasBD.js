import Rifas from "../Modelo/Rifas.js";
import conectar from "./conexao.js";

export default class RifasBD {
    async adicionar(rifa) {
        if (rifa instanceof Rifas) {
            const conexao = await conectar();
            const sql = 'INSERT INTO rifa (descricao, tipo, premiacao, dataInic, dataSort) \
                VALUES (?, ?, ?, ?, ?)';
            const valores = [rifa.descricao, rifa.tipo, rifa.premiacao, rifa.dataInic, rifa.dataSort];
            const resultado = await conexao.query(sql, valores);
            return resultado[0].insertId;
        }
    }

    async alterar(rifa) {
        if (rifa instanceof Rifas) {
            const conexao = await conectar();
            const sql = 'UPDATE rifa SET descricao=?, tipo=?, premiacao=? WHERE codigo=?';
            const valores = [rifa.descricao, rifa.tipo, rifa.premiacao, rifa.codigo];
            await conexao.query(sql, valores);
        }
    }

    async deletar(rifa) {
        if (rifa instanceof Rifas) {
            const conexao = await conectar();
            const sql = 'DELETE FROM rifa WHERE codigo=?';
            const valores = [rifa.codigo];
            await conexao.query(sql, valores);
        }
    }

    async consultar(premiacao) {
        const conexao = await conectar();
        const sql = 'SELECT * FROM rifa WHERE premiacao LIKE ?';
        const valores = ['%' + premiacao + '%'];
        const [rows] = await conexao.query(sql, valores);
        const listaRifa = [];
        for (const row of rows) {
            const rifa = new Rifas(row['codigo'], row['descricao'], row['tipo'], row['premiacao'], row['dataInic'], row['dataSort']);
            listaRifa.push(rifa);
        }
        return listaRifa;
    }

    async consultarPremiacao(premiacao) {
        const conexao = await conectar();
        const sql = 'SELECT * FROM rifa WHERE premiacao = ?';
        const valores = [premiacao];
        const [rows] = await conexao.query(sql, valores);
        const listaRifa = [];
        for (const row of rows) {
            const rifa = new Rifas(row['codigo'], row['descricao'], row['tipo'], row['premiacao'], row['dataInic'], row['dataSort']);
            listaRifa.push(rifa);
        }
        return listaRifa;
    }
}
