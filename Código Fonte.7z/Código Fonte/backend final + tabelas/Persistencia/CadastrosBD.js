import Cadastros from "../Modelo/Cadastros.js";
import conectar from "./conexao.js";

export default class CadastrosBD {
    async adicionar(cadastro) {
        if (cadastro instanceof Cadastros) {
            const conexao = await conectar();
            const sql = 'INSERT INTO cadastro (usuario, senha, nivel) \
                VALUES (?, ?, ?)';
            const valores = [cadastro.usuario, cadastro.senha, cadastro.nivel];
            const resultado = await conexao.query(sql, valores);
            return resultado[0].insertId;
        }
    }

    async alterar(cadastro) {
        if (cadastro instanceof Cadastros) {
            const conexao = await conectar();
            const sql = 'UPDATE cadastro SET usuario=?, senha=?, nivel=? WHERE codigo=?';
            const valores = [cadastro.usuario, cadastro.senha, cadastro.nivel, cadastro.codigo];
            await conexao.query(sql, valores);
        }
    }

    async deletar(cadastro) {
        if (cadastro instanceof Cadastros) {
            const conexao = await conectar();
            const sql = 'DELETE FROM cadastro WHERE codigo=?';
            const valores = [cadastro.codigo];
            await conexao.query(sql, valores);
        }
    }

    async consultar(usuario) {
        const conexao = await conectar();
        const sql = 'SELECT * FROM cadastro WHERE usuario LIKE ?';
        const valores = ['%' + usuario + '%'];
        const [rows] = await conexao.query(sql, valores);
        const listaCadastros = [];
        for (const row of rows) {
            const cadastro = new Cadastros(row['codigo'], row['usuario'], row['senha'], row['nivel']);
            listaCadastros.push(cadastro);
        }
        return listaCadastros;
    }

    async consultarUsuario(usuario) {
        const conexao = await conectar();
        const sql = 'SELECT * FROM cadastro WHERE usuario = ?';
        const valores = [usuario];
        const [rows] = await conexao.query(sql, valores);
        const listaCadastros = [];
        for (const row of rows) {
            const cadastro = new Cadastros(row['codigo'], row['usuario'], row['senha'], row['nivel']);
            listaCadastros.push(cadastro);
        }
        return listaCadastros;
    }




    async autenticar(usuario,senha) {
        const conexao = await conectar();
        const sql = "SELECT * FROM cadastro WHERE usuario = ? AND senha = ?";
        //const valores = [cadastro.usuario, cadastro.senha];
        const result = await conexao.query(sql, [usuario,senha])
        return result[0]
    }
    

}
