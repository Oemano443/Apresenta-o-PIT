import Doacao from "../Modelo/Doacao.js";
import Colaborador from "../Modelo/Colaborador.js";
import ItensDoacao from "../Modelo/ItensDoacao.js";
import conectar from "./conexao.js";

export default class DoacaoBD{

   async gravar(doacao){
    
    if(doacao instanceof Doacao){
      const conexao = await conectar(); 
        const bd = 'INSERT INTO doacoes(data,codDoador,nomeDoador,codItem,descItem,qtd,observacoes) \ VALUES(?,?,?,?,?,?,?)'
       
       //const valores = [doacao.data,doacao.codDoador[0].codColaborador,doacao.nomeDoador,doacao.codItem[0].codigo,doacao.descItem,doacao.qtd,doacao.observacoes]
       const valores = [doacao.data, doacao.codDoador, doacao.nomeDoador, doacao.codItem, doacao.descItem, doacao.qtd, doacao.observacoes]
       const resultado = await conexao.query(bd,valores)
       return await resultado[0].insertId;

    }
   }



   async alterar(doacao){
    if(doacao instanceof Doacao){

    const conexao = await conectar();

    const bd = "UPDATE doacoes SET data = ?, codDoador = ?, nomeDoador = ?, codItem = ?, descItem = ?, qtd = ?, observacoes = ? \
    \ WHERE codDoacao = ?"; 
    

    const valores = [doacao.data,doacao.codDoador,doacao.nomeDoador,doacao.codItem,doacao.descItem,doacao.qtd,doacao.observacoes,doacao.codDoacao]
    await conexao.query(bd,valores); 
   }
}


// Exclusão de dados
async excluir(doacao){
    if(doacao instanceof Doacao){
        const conexao = await conectar(); 

        const bd = "DELETE FROM doacoes \
          WHERE codDoacao=?";  

        const valores = [doacao.codDoacao]; 

        await conexao.query(bd,valores);

    }}




    async consultar(nome){
        const conexao = await conectar();

        const bd = 'SELECT * FROM doacoes as do INNER JOIN colaborador as co ON do.codDoador = co.codColaborador WHERE nome LIKE ?';
        'SELECT * FROM doacoes as do INNER JOIN itensdoacao as it ON do.codItem = it.codigo WHERE descricao LIKE ?'
        const valores = ['%' + nome + '%']
        const [rows] = await conexao.query(bd,valores);
        const ListaDoacoes = [];
        for(const row of rows){
            const colaborador = new Colaborador(row['codColaborador'],row['cpf'],row['categoria'],row['nome'],row['dataNasc'],row['telefone'],row['email'],row['cep'],row['logradouro'],row['numero'],row['complemento'],row['bairro'],row['cidade'],row['uf'])
           
            const item = new ItensDoacao(row['codigo'], row['descricao'], row['tipo'])

            const doacao = new Doacao(row['codDoacao'], row['data'], row['codDoador'], row['nomeDoador'], row['codItem'], row['descItem'], row['qtd'], row['observacoes'])

            ListaDoacoes.push(doacao)
        }
        return ListaDoacoes;
    }

}