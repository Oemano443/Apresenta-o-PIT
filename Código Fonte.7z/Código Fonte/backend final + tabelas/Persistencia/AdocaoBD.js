import Adocao from "../Modelo/Adocao.js";
import Colaborador from "../Modelo/Colaborador.js";
import Animais from  "../Modelo/Colaborador.js";
import conectar from "./conexao.js";

export default class AdocaoBD{

   async gravar(adocao){
    
    if(adocao instanceof Adocao){
      const conexao = await conectar(); 
        const bd = 'INSERT INTO adocao(data,codAdotante,nomeAdotante,codAnimal,nomeAnimal,observacoes) \ VALUES(?,?,?,?,?,?)'
       // const valores = [adocao.codigo,adocao.data,adocao.codAdotante,adocao.nomeAdotante,adocao.codAnimal,adocao.nomeAnimal,adocao.observacoes]
       const valores = [adocao.data,adocao.codAdotante[0].codColaborador,adocao.nomeAdotante,adocao.codAnimal[0].codigo_animal,adocao.nomeAnimal,adocao.observacoes]
       const resultado = await conexao.query(bd,valores)
       return await resultado[0].insertId;

    }
   }



   async alterar(adocao){
    if(adocao instanceof Adocao){

    const conexao = await conectar();

    const bd = "UPDATE adocao SET data = ?, codAdotante = ?, nomeAdotante = ?, codAnimal = ?, nomeAnimal = ?, observacoes = ? \
    \ WHERE codigo = ?"; 
    

    const valores = [adocao.data,adocao.codAdotante[0].codColaborador,adocao.nomeAdotante,adocao.codAnimal[0].codigo_animal,adocao.nomeAnimal,adocao.observacoes,adocao.codigo]
    await conexao.query(bd,valores); 
   }
}


// Exclusão de dados
async excluir(adocao){
    if(adocao instanceof Adocao){
        const conexao = await conectar(); 

        const bd = "DELETE FROM adocao \
          WHERE codigo=?";  

        const valores = [adocao.codigo]; 

        await conexao.query(bd,valores);

    }}




    async consutar(nome){
        const conexao = await conectar();

        const bd = 'SELECT * FROM adocao as ad INNER JOIN colaborador as co ON ad.codAdotante = co.codColaborador WHERE nome LIKE ?';
        'SELECT * FROM adocao as ad INNER JOIN animais as an ON ad.codAnimal = an.codigo_animal WHERE nome_animal LIKE ?'
        const valores = ['%' + nome + '%']
        const [rows] = await conexao.query(bd,valores);
        const ListaAdocoes = [];
        for(const row of rows){
            const colaborador = new Colaborador(row['codColaborador'],row['cpf'],row['categoria'],row['nome'],row['dataNasc'],row['telefone'],row['email'],row['cep'],row['logradouro'],row['numero'],row['complemento'],row['bairro'],row['cidade'],row['uf'])
           
            const animal = new Animais(row['codigo_animal'], row['nome_animal'], row['raca_animal'],row['porte_animal'], row['cor_animal'], row['idade_animal'],
            row['temperamento_animal'], row['dataentrada_animal'], row['localizacao_animal'], row['vacinacao_animal'], row['necessidades_animal'],row['disponibilidade_animal'], row['localencontrado_animal'],row['dataadocao_animal'])

            const adocao = new Adocao(row["codigo"],row["data"],row["codAdotante"],row["nomeAdotante"],row["codAnimal"],row["nomeAnimal"],row["observacoes"],colaborador,animal)
            ListaAdocoes.push(adocao)
        }
        return ListaAdocoes;
    }

}