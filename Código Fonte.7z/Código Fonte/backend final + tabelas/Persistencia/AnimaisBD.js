import Animais from "../Modelo/Animais.js";
import conectar from "./conexao.js";

export default class AnimaisBD{

    async incluir(animais){
        if (animais instanceof Animais){
            const conexao = await conectar();
            const sql="INSERT INTO animais(codigo_animal, nome_animal,raca_animal,porte_animal,cor_animal,idade_animal, \
                                           temperamento_animal,dataentrada_animal,localizacao_animal,vacinacao_animal, \
                                           necessidades_animal,disponibilidade_animal,localencontrado_animal, \
                                           dataadocao_animal) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            const valores = [animais.codigo_animal, animais.nome_animal,animais.raca_animal,animais.porte_animal, 
                             animais.cor_animal,animais.idade_animal,animais.temperamento_animal, 
                             animais.dataentrada_animal,animais.localizacao_animal,animais.vacinacao_animal,
                             animais.necessidades_animal,animais.disponibilidade_animal,animais.localencontrado_animal,
                             animais.dataadocao_animal];
            await conexao.query(sql,valores);
            }
        }

    async alterar(animais){
        if (animais instanceof Animais){
            const conexao = await conectar();
            const sql="UPDATE animais SET nome_animal=?, raca_animal=?, porte_animal=?, cor_animal=?, idade_animal=?, \
                       temperamento_animal=?, dataentrada_animal=?, localizacao_animal=?, vacinacao_animal=?, \
                       necessidades_animal=?, disponibilidade_animal=?, localencontrado_animal=?, dataadocao_animal=? \
                       WHERE codigo_animal=?";
            const valores = [animais.nome_animal,animais.raca_animal,animais.porte_animal,animais.cor_animal,
                             animais.idade_animal,animais.temperamento_animal,animais.dataentrada_animal,
                             animais.localizacao_animal,animais.vacinacao_animal,animais.necessidades_animal,
                             animais.disponibilidade_animal,animais.localencontrado_animal,animais.dataadocao_animal,
                             animais.codigo_animal];
            await conexao.query(sql,valores);
        }
    }

    async excluir(animais){
        if (animais instanceof Animais){
            const conexao = await conectar();
            const sql="DELETE FROM animais WHERE codigo_animal=?"
            const valores = [animais.codigo_animal];
            await conexao.query(sql,valores);
        }
    }

    




    async consultar(termo){
        const conexao = await conectar();
        const sql="SELECT * FROM animais WHERE nome_animal LIKE ?"
        const valores = ['%' + termo + '%'];
        const [rows] = await conexao.query(sql,valores);
        const listaAnimais = [];
        for (const row of rows){
            const animais = new Animais(row['codigo_animal'], row['nome_animal'], row['raca_animal'], 
                                        row['porte_animal'], row['cor_animal'], row['idade_animal'],
                                        row['temperamento_animal'], row['dataentrada_animal'], 
                                        row['localizacao_animal'], row['vacinacao_animal'], row['necessidades_animal'],
                                        row['disponibilidade_animal'], row['localencontrado_animal'],
                                        row['dataadocao_animal']);
            listaAnimais.push(animais);
        }
        return listaAnimais;
    }

    async consultarCodigo(codigo){
        const conexao = await conectar();
        const sql = "SELECT * FROM animais WHERE codigo_animal = ?"
        const valores = [codigo];
        const [rows] = await conexao.query(sql,valores);
        const listaAnimais = [];
        for (const row of rows){
            const animais = new Animais(row['codigo_animal'], row['nome_animal'], row['raca_animal'], 
                                        row['porte_animal'], row['cor_animal'], row['idade_animal'],
                                        row['temperamento_animal'], row['dataentrada_animal'], 
                                        row['localizacao_animal'], row['vacinacao_animal'], row['necessidades_animal'],
                                        row['disponibilidade_animal'], row['localencontrado_animal'],
                                        row['dataadocao_animal']);
            listaAnimais.push(animais);
        }
        return listaAnimais;
    }

    


/*
    async consultar(termo){
        const conexao = await conectar();
        const sql="SELECT * FROM animais WHERE nome_animal LIKE ?"
        const valores = ['%' + termo + '%'];
        const [rows] = await conexao.query(sql,valores);
        const listaAnimais = [];
        for (const row of rows){
            const animais = new Animais(row['codigo_animal'], row['nome_animal'], row['raca_animal'], 
                                        row['porte_animal'], row['cor_animal'], row['idade_animal'],
                                        row['temperamento_animal'], row['dataentrada_animal'], 
                                        row['temperamento_animal'], row['vacinacao_animal'], row['necessidades_animal'],
                                        row['disponibilidade_animal'], row['localencontrado_animal'],
                                        row['dataadocao_animal']);
            listaAnimais.push(animais);
        }
        return listaAnimais;
    }
*/
    
}

