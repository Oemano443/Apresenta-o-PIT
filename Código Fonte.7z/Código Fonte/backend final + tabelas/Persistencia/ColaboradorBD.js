import conectar from "./conexao.js";
import Colaborador from "../Modelo/Colaborador.js";

export default class ColaboradorBD{

    // Gravar no banco de dados
    async gravar(colaborador){
        if(colaborador instanceof Colaborador){
            
        const conexao = await conectar(); 

        const bd = 'INSERT INTO colaborador(cpf,categoria,nome,dataNasc,telefone,email,cep,logradouro,numero,complemento,bairro,cidade,uf) \ VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)'

        const valores = [colaborador.cpf,colaborador.categoria,colaborador.nome,colaborador.dataNasc,colaborador.telefone,colaborador.email,colaborador.cep,colaborador.logradouro,colaborador.numero,colaborador.complemento,colaborador.bairro,colaborador.cidade,colaborador.uf]
        const resultado = await conexao.query(bd,valores); 
        return await resultado[0].insertId;

        }} // colaborador.codColaborador
        
    // Alterar dados
    async alteracao(colaborador){
        if(colaborador instanceof Colaborador){

        const conexao = await conectar();

        const bd = "UPDATE colaborador SET codColaborador = ?,categoria = ?,nome = ?,dataNasc = ?,telefone = ?,email = ?,cep = ?,logradouro = ?,numero = ?,complemento = ?,bairro = ?,cidade = ?,uf = ? \
        \ WHERE cpf = ?"; 

        const valores = [colaborador.codColaborador,colaborador.categoria,colaborador.nome,colaborador.dataNasc,colaborador.telefone,colaborador.email,colaborador.cep,colaborador.logradouro,colaborador.numero,colaborador.complemento,colaborador.bairro,colaborador.cidade,colaborador.uf,colaborador.cpf]

        await conexao.query(bd,valores);  

    }}

    // Exclusão de dados
    async excluir(colaborador){
        if(colaborador instanceof Colaborador){
            const conexao = await conectar(); 

            const bd = "DELETE FROM colaborador \
              WHERE cpf=?";  

            const valores = [colaborador.cpf]; 
    
            await conexao.query(bd,valores);

        }}


    // Consultar dados
    async consultar(nome){
        const conexao = await conectar();

        const bd = 'SELECT * FROM colaborador WHERE nome LIKE ?' 
        const valores = ['%' + nome + '%']
        const [rows] = await conexao.query(bd,valores);
        const ListaColaboradores = [];
        for(const row of rows){
            const colaborador = new Colaborador(row['codColaborador'],row['cpf'],row['categoria'],row['nome'],row['dataNasc'],row['telefone'],row['email'],row['cep'],row['logradouro'],row['numero'],row['complemento'],row['bairro'],row['cidade'],row['uf']);
            ListaColaboradores.push(colaborador);
        }
        return ListaColaboradores;
    }


    // Consulta por chave primária
    async consultaCpf(cpf){
        const conexao = await conectar();

        const bd = 'SELECT * FROM colaborador WHERE cpf = ?' 
        const valores = [cpf]
        const [rows] = await conexao.query(bd,valores);
        const ListaColaboradores = [];
        for(const row of rows){
            const colaborador = new Colaborador(row['codColaborador'],row['cpf'],row['categoria'],row['nome'],row['dataNasc'],row['telefone'],row['email'],row['cep'],row['logradouro'],row['numero'],row['complemento'],row['bairro'],row['cidade'],row['uf']);
            ListaColaboradores.push(colaborador);
        }
        return ListaColaboradores;
    }

 // Consulta por código
 async consultaCodigo(codigo){
    const conexao = await conectar();

    const bd = 'SELECT * FROM colaborador WHERE codColaborador = ?' 
    const valores = [codigo]
    const [rows] = await conexao.query(bd,valores);
   // global.poolConexoes.releaseConnection(conexao);
    const ListaColaboradores = [];
    for(const row of rows){
        const colaborador = new Colaborador(row['codColaborador'],row['cpf'],row['categoria'],row['nome'],row['dataNasc'],row['telefone'],row['email'],row['cep'],row['logradouro'],row['numero'],row['complemento'],row['bairro'],row['cidade'],row['uf']);
        ListaColaboradores.push(colaborador);
    }
    //console.log("Persistência: ",JSON.stringify(ListaColaboradores))
    return ListaColaboradores;
}





}