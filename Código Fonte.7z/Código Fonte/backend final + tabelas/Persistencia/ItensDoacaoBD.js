import conectar from "./conexao.js";
import ItensDoacao from "../Modelo/ItensDoacao.js";


export default class ItensDoacaoBD{


async gravar(item){
    if(item instanceof ItensDoacao){
        const conexao = await conectar();
        const bd = 'INSERT INTO itensdoacao(descricao,tipo) \ VALUES(?,?)'
        const valores = [item.descricao,item.tipo]
        const resultado = await conexao.query(bd,valores)
        return await resultado[0].insertId;

    }
}

async editar(item){
    if(item instanceof ItensDoacao){
        const conexao = await conectar();
        const bd = 'UPDATE itensdoacao SET descricao = ?, tipo = ? \
        \ WHERE codigo = ?';
        const valores = [item.descricao,item.tipo,item.codigo]
        await conexao.query(bd,valores)
    }
}

async excluir(item){
    if(item instanceof ItensDoacao){
        const conexao = await conectar();
        const bd = 'DELETE FROM itensdoacao \ WHERE codigo = ?'
        const valores = [item.codigo]
        await conexao.query(bd,valores)
    }
}

async consultar(descricao){
    const conexao = await conectar();
    const bd = 'SELECT * FROM itensdoacao WHERE descricao LIKE ?' 
    const valores = ['%' + descricao + '%']
    const [rows] = await conexao.query(bd,valores)
    const ListaItens = [];
    for(const row of rows){
        const item = new ItensDoacao(row['codigo'],row['descricao'],row['tipo']) // instânciando cada item e adicionar esses objetos na lista
        ListaItens.push(item)
    }
    return ListaItens
}


}