import conectar from "./conexao.js";
import TiposDespesas from "../Modelo/TiposDespesas.js";

export default class TiposDespesasBD{

   async gravar(despesa){
        if(despesa instanceof TiposDespesas){
            const conexao = await conectar();
            const bd = 'INSERT INTO tipodespesa(descricao,classificacao) \ VALUES(?,?)'

            const valores = [despesa.descricao,despesa.classificacao]
            const resultado = await conexao.query(bd,valores)
            return await resultado[0].insertId;
         }}

   async editar(despesa){
        if(despesa instanceof TiposDespesas){
         const conexao = await conectar();
         const bd = 'UPDATE tipodespesa SET descricao = ?, classificacao = ? \
         \ WHERE codigo = ?';
         const valores = [despesa.descricao,despesa.classificacao,despesa.codigo]
         await conexao.query(bd,valores)
        }
         }     

   async excluir(despesa){
      if(despesa instanceof TiposDespesas){
         const conexao = await conectar();
         const bd = 'DELETE FROM tipodespesa \ WHERE codigo = ?'
         const valores = [despesa.codigo]
         await conexao.query(bd,valores)
      }
   }


   async consultar(descricao){
      const conexao = await conectar();
      const bd = 'SELECT * FROM tipodespesa WHERE descricao LIKE ?' 
      const valores = ["%" + descricao + "%"] // importante lembrar que estamos fazendo o sql em partes porque será a função "query" que se encarregará de juntar tudo
      const [rows] = await conexao.query(bd,valores) // dentro da constânte rows que serão armazenados os resultados que serão retornados pelo banco de dados, nesse caso os objetos dos tipos de despesas
      const ListaDespesas = [];
      for(const row of rows){
         const tipoDespesa = new TiposDespesas(row['codigo'],row['descricao'],row["classificacao"]);
         ListaDespesas.push(tipoDespesa);
      }
      return ListaDespesas
   }

   
}
