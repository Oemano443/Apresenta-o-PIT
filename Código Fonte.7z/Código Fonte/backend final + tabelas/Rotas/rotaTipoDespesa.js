import { Router } from "express";
import TipoDespesaCtrl from "../Controle/TipoDespesaCtrl.js";

const rotaTipoDespesa = Router();
const tipoDespesaCtrl = new TipoDespesaCtrl();

rotaTipoDespesa
.post('/',tipoDespesaCtrl.gravar)
.put('/',tipoDespesaCtrl.editar)
.delete('/',tipoDespesaCtrl.excluir)
.get('/',tipoDespesaCtrl.consulta)

export default rotaTipoDespesa;