import { Router } from "express";
import animaisCTRL from "../Controle/AnimaisCtrl.js";

const rotaAnimal = new Router();
const AnimaisCtrl = new animaisCTRL();

rotaAnimal.get('/',AnimaisCtrl.consultar)
.post('/',AnimaisCtrl.gravar)
.put('/',AnimaisCtrl.atualizar)
.delete('/',AnimaisCtrl.excluir);

export default rotaAnimal;