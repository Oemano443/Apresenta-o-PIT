import { Router } from "express";
import AdocaoCtrl from "../Controle/AdocaoCtrl.js";

const rotaAdocao = new Router();
const adocaoCtrl = new AdocaoCtrl()

rotaAdocao.post('/',adocaoCtrl.gravar)
.put('/',adocaoCtrl.editar)
.delete('/',adocaoCtrl.excluir)
.get('/',adocaoCtrl.consultar)


export default rotaAdocao;

