import { Router } from "express";
import ColaboradorCTRL from "../Controle/colaboradorCTRL.js";

const rotaColaborador = new Router();
const ColaboradorControle = new ColaboradorCTRL();


rotaColaborador.post('/',ColaboradorControle.gravar)
.put('/',ColaboradorControle.editar)
.delete('/',ColaboradorControle.excluir)
.get('/',ColaboradorControle.consultar)
.get('/:cpf',ColaboradorControle.consultaCpf)


export default rotaColaborador;
