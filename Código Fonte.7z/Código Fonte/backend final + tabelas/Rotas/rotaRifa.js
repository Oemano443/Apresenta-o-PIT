import { Router } from "express";
import RifaControl from "../Controle/RifaControl.js";

const rotaRifa = Router();
const rifaCTRL = new RifaControl();

rotaRifa.post('/', rifaCTRL.gravar)
    .put('/', rifaCTRL.atualizar)
    .delete('/', rifaCTRL.excluir)
    .get('/', rifaCTRL.consultar)
    .get('/:codigo', rifaCTRL.consultarCodigo);

export default rotaRifa;
