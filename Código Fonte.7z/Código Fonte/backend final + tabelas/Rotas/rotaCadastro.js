import { Router } from "express";
import CadastrosControl from "../Controle/CadastrosControl.js";

const rotaCadastro = Router();
const cadastroCTRL = new CadastrosControl();

rotaCadastro.post('/', cadastroCTRL.gravar)
    .put('/', cadastroCTRL.atualizar)
    .delete('/', cadastroCTRL.excluir)
    .get('/', cadastroCTRL.consultar)
    .get('/:codigo', cadastroCTRL.consultarCodigo)
    .post('/autenticar',cadastroCTRL.autenticar)


export default rotaCadastro;
