import { Router } from "express";
import RacaCTRL from "../Controle/RacaCrtl.js";
const rotaRacas = new Router();
const controlarRacas = new RacaCTRL();

rotaRacas.post('/',controlarRacas.gravar)
.put('/',controlarRacas.editar)
.delete('/',controlarRacas.excluir)
.get('/',controlarRacas.consultar)



export default rotaRacas;