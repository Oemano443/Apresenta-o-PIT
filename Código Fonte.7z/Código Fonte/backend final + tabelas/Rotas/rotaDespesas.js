import { Router } from "express";
import DespesasCtrl from "../Controle/DespesasCtrl.js";

const rotaDespesa = Router()
const despesasCTRL = new DespesasCtrl()

rotaDespesa
.post('/',despesasCTRL.gravar)
.delete('/',despesasCTRL.excluir)
.put('/',despesasCTRL.editar)
.get('/',despesasCTRL.consultar)


export default rotaDespesa