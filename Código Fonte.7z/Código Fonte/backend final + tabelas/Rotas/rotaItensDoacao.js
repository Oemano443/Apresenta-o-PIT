import { Router } from "express";
import ItensDoacaoCtrl from "../Controle/ItensDoacaoCtrl.js";

const rotaItensDoacao = Router();
const itemCtrl = new ItensDoacaoCtrl();

rotaItensDoacao.post('/',itemCtrl.gravar)
.put('/',itemCtrl.editar)
.delete('/',itemCtrl.excluir)
.get('/',itemCtrl.consultar)

export default rotaItensDoacao;