import { Router } from "express";
import DoacaoCtrl from "../Controle/DoacaoCtrl.js";

const rotaDoacao = new Router();
const doacaoCtrl = new DoacaoCtrl()

rotaDoacao.post('/',doacaoCtrl.gravar)
.put('/',doacaoCtrl.editar)
.delete('/',doacaoCtrl.excluir)
.get('/',doacaoCtrl.consultar)


export default rotaDoacao;

