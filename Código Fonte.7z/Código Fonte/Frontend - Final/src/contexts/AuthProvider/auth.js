import React, {createContext, useState, useEffect} from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

export const AuthContext = createContext() // cria contexto


// componente provider para passar os valores aos childrens
function AuthProvider({children}){  // o provider provém as informações
    
    const [logado, setLogado] = useState(false)
    const [tokenTemp,setTokenTemp] = useState(null) 
  
    
// Função de login
const login = (token) => {
    setLogado(true);
    setTokenTemp(token);
    localStorage.setItem('accessToken', token);
  };

  // Função de logout
  const logout = (navigate) => {
    setLogado(false);
    setTokenTemp(null);
    localStorage.removeItem('accessToken');
    navigate('/')
    
  };

  
  // Verifica se há um token no localStorage ao carregar a página
  useEffect(() => {
    const storedToken = localStorage.getItem('accessToken');
    if (storedToken) {
      setLogado(true);
      setTokenTemp(storedToken);
    } else {
      setLogado(false);
    
    }
  }, [logado, setLogado]);

    
    return(
    <AuthContext.Provider value={{logado, setLogado, login, logout, tokenTemp}}>
        {children}
    </AuthContext.Provider>   
    )
}

export default AuthProvider;

 