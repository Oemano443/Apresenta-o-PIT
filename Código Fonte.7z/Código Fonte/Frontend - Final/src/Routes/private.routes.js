import {React,useEffect} from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import TelaCadastroColaboradores from "../componentes/Telas/TelaCadastroColaboradores";
import Tela404 from "../componentes/Telas/Tela404";
import TelaPrincipal from "../componentes/Telas/TelaMenu";

import { useContext } from "react";
import { AuthContext } from "../contexts/AuthProvider/auth";






import TelaCadastroAnimal from "../componentes/Telas/TelaCadastroAnimal";
import TelaCadastroRifas from "../componentes/Telas/TelaCadastroRifas";
import TelaCadastroRaca from "../componentes/Telas/TelaCadastroRaca";
import TelaTipoDespesas from "../componentes/Telas/TelaTipoDespesas";
import TelaCadastroIdoacao from "../componentes/Telas/TelaCadastroIdoacao";
import TelaCadastros from "../componentes/Telas/TelaCadastros";
import TelaCadastroAdocoes from "../componentes/Telas/TelaCadastroAdocoes";
import TelaCadastroDespesas from "../componentes/Telas/TelaCadastroDespesas";
import TelaCadastroDoacoes from "../componentes/Telas/TelaCadastroDoacoes";
import TelaSorteioRifas from '../componentes/Telas/TelaSorteioRifas'
import TelaAjudaAnimais from "../componentes/Telas/TelaAjudaAnimais";

//import TelaSorteioRifas from "./componentes/Telas/TelaSorteioRifas"
import TelaAjudaColaboradores from "../componentes/Telas/TelaAjudaColaboradores";
//import TelaAjudaTiposDespesas from "../componentes/Telas/TelaAjudaTiposDespesas";
import TelaAjudaDespesas from "../componentes/Telas/TelaAjudaDespesas";
import TelaAjudaAdocoes from "../componentes/Telas/TelaAjudaAdocoes";
import TelaAjudaTiposDespesas from "../componentes/Telas/TelaAjudaTiposDespesas"

import TelaAjudaItensDoacao from "../componentes/Telas/TelaAjudaItensDoacao";
import TelaAjudaCadastros from "../componentes/Telas/TelaAjudaCadastros";
import TelaAjudaRifas from "../componentes/Telas/TelaAjudaRifas";
import TelaAjudaRacas from "../componentes/Telas/TelaAjudaRacas";

import TelaAjudaSorteioRifas from '../componentes/Telas/TelaAjudaSorteioRifas';
import TelaAjudaDoacoes from "../componentes/Telas/TelaAjudaDoacoes";
//import AjudaRifas from "../src/Paginas/PaginaAjudaRifas";
/*
import AjudaCadastro from "../src/Paginas/PaginaAjudaCadastro";
import AjudaSorteioRifas from "../src/Paginas/PaginaAjudaSorteioRifas";
import TelaAjudaColaboradores from "./componentes/Telas/TelaAjudaColaboradores";
import TelaAjudaTiposDespesas from "./componentes/Telas/TelaAjudaTiposDespesas";
import TelaAjudaDespesas from "./componentes/Telas/TelaAjudaDespesas";
import TelaAjudaAdocoes from "./componentes/Telas/TelaAjudaAdocoes";
*/
const PrivateRoutes = ()=>{
  
  const {setLogado, logado} = useContext(AuthContext)
  const { tokenTemp } = useContext(AuthContext) // token original
 const token = localStorage.getItem('accessToken') // token consultado
  
 /*
  if(!logado){
    setLogado(false);
    return <Navigate to="/doacoes" />;
  }*/

/*
 useEffect(() => {
  if(token === tokenTemp){
    setLogado(true)
  } else {
    setLogado(false)
    return <Navigate to="/" />;
  }
},[token, logado, setLogado])
*/
  /*
  const {setLogado, logado} = useContext(AuthContext)
  const token = localStorage.getItem('accessToken')
  
  useEffect(() => {
    if (token && !logado) {
      setLogado(true);
    }
  }, [token, logado, setLogado]);

  if (!logado) {
    
    return <Navigate to="/" />;
  }
  */

    return(
      
        <Routes>
        <Route path="/menu" element={<TelaPrincipal/>} />
        <Route path="/colaboradores" element={<TelaCadastroColaboradores />} />
        <Route path="/adocoes" element={<TelaCadastroAdocoes/>} />
        <Route path="/colaboradores" element={<TelaCadastroColaboradores />} />
        <Route path="/animais" element={<TelaCadastroAnimal/>} />
        <Route path="/rifa" element={<TelaCadastroRifas/>} />
        <Route path="/raca" element={<TelaCadastroRaca/>} />
        <Route path="/tipodespesas" element={<TelaTipoDespesas/>} />
        <Route path="/itensdoacao" element={<TelaCadastroIdoacao/>} />
        <Route path="/cadastrousuarios" element={<TelaCadastros/>} />
        <Route path="/despesas" element={<TelaCadastroDespesas/>} />
        <Route path="/doacoes" element={<TelaCadastroDoacoes/>} />
        <Route path="/sorteiorifa" element={<TelaSorteioRifas/>} />
        
        <Route path="/ajudadoacoes" element={<TelaAjudaDoacoes/>} />
        <Route path="/ajudaanimais" element={<TelaAjudaAnimais/>} />
        <Route path="/ajudaracas" element={<TelaAjudaRacas/>} />
        <Route path="/ajudarifas" element={<TelaAjudaRifas/>} />
        <Route path="/ajuda2" element={<TelaAjudaItensDoacao/>} />
        <Route path="/ajuda3" element={<TelaAjudaCadastros/>} />
        <Route path="/ajudasorteiorifas" element={<TelaAjudaSorteioRifas/>} />
        <Route path="/ajudacolaboradores" element={<TelaAjudaColaboradores/>} />
        <Route path="/ajudatipodespesas" element={<TelaAjudaTiposDespesas/>} />
        <Route path="/ajudadespesas" element={<TelaAjudaDespesas/>} />
        <Route path="/ajudaadocoes" element={<TelaAjudaAdocoes/>} />
        <Route path="/" element={<TelaPrincipal/>} />
        <Route path="*" element={<Tela404/>} />

      </Routes>
     
     )
}

export default PrivateRoutes;