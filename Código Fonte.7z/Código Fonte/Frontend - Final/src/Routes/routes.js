/*
import TelaPrincipal from "./componentes/Telas/TelaMenu";
import Tela404 from "./componentes/Telas/Tela404";
import TelaCadastroColaboradores from "./componentes/Telas/TelaCadastroColaboradores";
import TelaCadastroAnimal from "./componentes/Telas/TelaCadastroAnimal";
import TelaCadastroRifas from "./componentes/Telas/TelaCadastroRifas";
import TelaCadastroRaca from "./componentes/Telas/TelaCadastroRaca";
import TelaTipoDespesas from "./componentes/Telas/TelaTipoDespesas";
import TelaCadastroIdoacao from "./componentes/Telas/TelaCadastroIdoacao";
import TelaCadastros from "./componentes/Telas/TelaCadastros";
import TelaCadastroAdocoes from "./componentes/Telas/TelaCadastroAdocoes";
import TelaCadastroDespesas from './componentes/Telas/TelaCadastroDespesas'
//import TelaSorteioRifas from "./componentes/Telas/TelaSorteioRifas"
import AjudaRifas from "../src/Paginas/PaginaAjudaRifas";
import AjudaItensDoacao from "../src/Paginas/PaginaAjudaItensDoacao"
import AjudaCadastro from "../src/Paginas/PaginaAjudaCadastro";
import AjudaSorteioRifas from "../src/Paginas/PaginaAjudaSorteioRifas"
import TelaAjudaColaboradores from "./componentes/Telas/TelaAjudaColaboradores";
import TelaAjudaTiposDespesas from "./componentes/Telas/TelaAjudaTiposDespesas";
import TelaAjudaDespesas from "./componentes/Telas/TelaAjudaDespesas";
import TelaAjudaAdocoes from "./componentes/Telas/TelaAjudaAdocoes";
import LoginPage from "./componentes/Telas/login";
import { BrowserRouter,Route,Routes} from "react-router-dom"; // rotas de acesso


function AppRoutes(){
    <div>
<BrowserRouter>
       <Routes>     
       <Route path="/login" element={<LoginPage/>} />
        <Route path="/adocoes" element={<TelaCadastroAdocoes/>} />
        <Route path="/colaboradores" element={<TelaCadastroColaboradores />} />
        <Route path="/animais" element={<TelaCadastroAnimal/>} />
        <Route path="/rifa" element={<TelaCadastroRifas/>} />
        <Route path="/raca" element={<TelaCadastroRaca/>} />
        <Route path="/tipodespesas" element={<TelaTipoDespesas/>} />
        <Route path="/itensdoacao" element={<TelaCadastroIdoacao/>} />
        <Route path="/cadastrousuarios" element={<TelaCadastros/>} />
        <Route path="/despesas" element={<TelaCadastroDespesas/>} />
        <Route path="/ajuda" element={<AjudaRifas/>} />
        <Route path="/ajuda2" element={<AjudaItensDoacao/>} />
        <Route path="/ajuda3" element={<AjudaCadastro/>} />
        <Route path="/ajuda4" element={<AjudaSorteioRifas/>} />
        <Route path="/ajudacolaboradores" element={<TelaAjudaColaboradores/>} />
        <Route path="/ajudatipodespesas" element={<TelaAjudaTiposDespesas/>} />
        <Route path="/ajudadespesas" element={<TelaAjudaDespesas/>} />
        <Route path="/ajudaadocoes" element={<TelaAjudaAdocoes/>} />
        <Route path="/" element={<TelaPrincipal/>} />
        <Route path="*" element={<Tela404/>} />
       </Routes>
     </BrowserRouter>
     </div>

}

*/
