import Menu from "../componentes/Menus/menu";
import { Container } from "react-bootstrap";

export default function Pagina404(propriedades){
    return(
        <div style={{width: '100%'}}>
          <Menu texto='Pet Adote'/>
        <br/>
          <Container>
        {propriedades.children} 
          </Container>
        </div>
    );
}
