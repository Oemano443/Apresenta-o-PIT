import Header from "../componentes/Headers/cabecalho"
import Menu from "../componentes/Menus/menu";
import { Container } from "react-bootstrap";

export default function PaginaDespesas(propriedades){
    return(
        <div style={{width: '100%'}}>
          <Menu texto='Pet Adote'/>
          <Header texto='Lançar Despesas Mensais' />
        <br/>
          <Container>
        {propriedades.children} 
          </Container>
        </div>
    );
}