import Header from "../componentes/Headers/cabecalho"
import Menu from "../componentes/Menus/menu";
import { Container } from "react-bootstrap";

export default function PaginaAjudaCadastro(propriedades) {
    return (
        <div style={{ width: '100%' }}>
            <Menu texto='Pet Adote' />
            <Header texto='Guia para Cadastro de Usuários' />
            <br />
            <Container>
                {propriedades.children}
            </Container>
        </div>
    );
}
