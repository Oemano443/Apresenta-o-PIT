import Header from "../componentes/Headers/cabecalho";
import Menu from "../componentes/Menus/menu";
import { Container } from "react-bootstrap";

export default function PaginaSorteioRifas(propriedades) {
    return (
        <div style={{ width: '100%' }}>
            <Menu texto='Pet Adote' />
            <Header texto='Sorteio de Rifas' />
            <br />
            <Container>
                {propriedades.children}
            </Container>
        </div>
    );
}
