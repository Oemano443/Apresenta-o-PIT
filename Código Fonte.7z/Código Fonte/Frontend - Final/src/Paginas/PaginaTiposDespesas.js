import Header from "../componentes/Headers/cabecalho"
import Menu from "../componentes/Menus/menu";
import { Container } from "react-bootstrap";

export default function PaginaTiposDespesas(propriedades){
    return(
        <div style={{width: '100%'}}>
          <Menu texto='Pet Adote'/>
          <Header texto='Cadastro Tipos de Despesas' />
        <br/>
          <Container>
        {propriedades.children} 
          </Container>
        </div>
    );
}
