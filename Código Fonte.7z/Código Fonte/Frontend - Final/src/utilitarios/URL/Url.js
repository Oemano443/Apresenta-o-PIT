export const urlBackend = 'http://localhost:5000'; // Colaboradores

export const urlAnimais = "http://localhost:5000";  // Animais

//export const urlBase = "http://localhost:3800"; // Rifas

export const urlBase = "http://localhost:5000"; // Rifas
export const urlRaca = 'http://localhost:5000'