import PaginaAjudaRifas from "../../Paginas/PaginaAjudaRifas";
import { Button, Form } from "react-bootstrap";
import {Table} from "react-bootstrap";
import { Link } from 'react-router-dom';
export default function TelaAjudaRifas(propriedades){
    return(
        <PaginaAjudaRifas>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/rifa">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                
                <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Componente</th>
                        <th>Informações</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        <td>Tabela</td>
                        <td>A Tabela apresenta registros de rifas cadastradas.</td>
                    </tr>
                    <tr>
                        <td>Botão - Edição</td>
                        <td>Possibilita a alteração das informações cadastradas para uma determinada rifa.</td>
                    </tr>
                    <tr>
                        <td>Botão - Exclusão</td>
                        <td>Possibilita a exclusão de uma determinada rifa cadastrada.</td>
                    </tr>

                </tbody>
            </Table>
            <br/>
            <Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Campo</th>
                        <th>Instruções de Preenchimento</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Código</td>
                        <td>Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
                    </tr>
                    <tr>
                        <td>Descrição</td>
                        <td>Nesse campo é informado a descrição da rifa sendo cadastrada.</td>
                    </tr>
                    <tr>
                        <td>Tipo</td>
                        <td>Nesse campo é selecionado o tipo de rifa sendo cadastrada.</td>
                    </tr>
                    <tr>
                        <td>Premiação</td>
                        <td>Nesse campo é informada a premiação da rifa sendo cadastrada.</td>
                    </tr>
                    
                </tbody>
            </Table>
            <br/>
            <Form.Label>Informações das funcionalidades dos Botões</Form.Label>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Botão</th>
                        <th>Função</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Cadastrar</td>
                        <td>Confirma o cadastramento da rifa.</td>
                    </tr>
                    <tr>
                        <td>Voltar</td>
                        <td>Retorna para a Tela que mostra as rifas já cadastradas.</td>
                    </tr>
                    <tr>
                        <td>Ajuda</td>
                        <td>Apresenta orientações de preenchimento e demais funções do Cadastro de Rifas.</td>
                    </tr>
                </tbody>
            </Table>

            </div>

        </PaginaAjudaRifas>
    );
}