import { useState, useEffect } from 'react';
import { Container, Alert } from 'react-bootstrap';
import { urlBackend } from '../../utilitarios/URL/Url';
import TabelaCadastroAdocoes from '../../tabelas/TabelaCadastroAdocoes';
import FormAdocao from '../Formularios/FormAdocao';
import PaginaAdocoes from '../../Paginas/PaginaAdocoes';

export default function TelaCadastroAdocoes(props) {

    const [adocoes, setAdocoes] = useState([]);
    const [exibirTabela, setExibirTabela] = useState(true);
    const [atualizando, setAtualizando] = useState(false);
    const [atualizarTabela, setAtualizarTabela] = useState(false);
    const [adocaoEdicao, setAdocaoEdicao] = useState({
        codigo: "",
        data: "",
        codAdotante: "",
        nomeAdotante:"",
        codAnimal: "",
        nomeAnimal: "",
        observacoes:"",
    })

    /*
     const [adocaoEdicao, setAdocaoEdicao] = useState({
        codigoAdocao: "",
        dataAdocao: "",
        adotante:"",
        animal: "",
        observacoes:"",
    })
    */



    function preparaAdocao(adocao) {
        setAtualizando(true);
        setAdocaoEdicao(adocao)
        setExibirTabela(false);

    }

    function excluirAdocao(adocao) {
        fetch(urlBackend + '/adocoes', {
            method: "DELETE",
            headers: { "Content-Type": 'application/json' },
            body: JSON.stringify(adocao)
        }).then((resposta) => {
            return resposta.json()
        }).then((retorno) => {
            setAtualizarTabela(true)
            window.alert('Dados apagados com sucesso !!! ')
            window.location.reload();
            if (retorno.resultado) {
                console.log('  ')

            } else if (retorno.resultado === false) {
                window.alert('Não foi possível apagar os dados da adoção !!!');
            }
        })
    }

    useEffect(() => {
        fetch(urlBackend + "/adocoes", {
            method: "GET"
        })
            .then((resposta) => {
                return resposta.json();

            }).then((dados) => {
                if (Array.isArray(dados)) {
                    setAdocoes([...dados]);
                }
            })
            .catch((erro) => {
                console.error("Erro ao buscar os dados do banco: " + erro);
            });
        setExibirTabela(true);
    }, []);

    return (
        <PaginaAdocoes>
            <Container className="border m-3">
                {
                    exibirTabela ?
                        <TabelaCadastroAdocoes listaAdocoes={adocoes} exibirTabela={setExibirTabela} setAdocoes={setAdocoes} editarAdocao={preparaAdocao} atualizarTabela={atualizarTabela} setAtualizarTabela={setAtualizarTabela} excluirAdocao={excluirAdocao} />
                        :
                        <FormAdocao listaAdocoes={adocoes} exibirTabela={setExibirTabela} setAdocoes={setAdocoes} modoEdicao={atualizando} adocao={adocaoEdicao} />
                }
            </Container>
        </PaginaAdocoes>
    );
}