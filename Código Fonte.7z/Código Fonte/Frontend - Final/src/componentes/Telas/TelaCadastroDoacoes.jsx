import { useState, useEffect } from 'react';
import { Container, Alert } from 'react-bootstrap';
import { urlBackend } from '../../utilitarios/URL/Url';
import TabelaCadastroDoacoes from '../../tabelas/TabelaCadastroDoacoes';
import FormDoacao from '../Formularios/FormDoacao';
import PaginaDoacoes from '../../Paginas/PaginaDoacoes';

export default function TelaCadastroDoacoes(props) {

    const [doacoes, setDoacoes] = useState([]);
    const [exibirTabela, setExibirTabela] = useState(true);
    const [atualizando, setAtualizando] = useState(false);
    const [atualizarTabela, setAtualizarTabela] = useState(false);
    const [doacaoEdicao, setDoacaoEdicao] = useState({
        codDoacao: "",
        data: "",
        codDoador: "",
        nomeDoador:"",
        codItem: "",
        descItem: "",
        qtd:"",
        observacoes:"",
    })

    /*
     const [adocaoEdicao, setAdocaoEdicao] = useState({
        codigoAdocao: "",
        dataAdocao: "",
        adotante:"",
        animal: "",
        observacoes:"",
    })
    */



    function preparaDoacao(doacao) {
        setAtualizando(true);
        setDoacaoEdicao(doacao)
        setExibirTabela(false);

    }

    function excluirDoacao(doacao) {
        fetch(urlBackend + '/doacoes', {
            method: "DELETE",
            headers: { "Content-Type": 'application/json' },
            body: JSON.stringify(doacao)
        }).then((resposta) => {
            return resposta.json()
        }).then((retorno) => {
            setAtualizarTabela(true)
            window.alert('Dados apagados com sucesso !!! ')
            window.location.reload();
            if (retorno.resultado) {
                console.log('  ')

            } else if (retorno.resultado === false) {
                window.alert('Não foi possível apagar os dados da doação !!!');
            }
        })
    }

    useEffect(() => {
        fetch(urlBackend + "/doacoes", {
            method: "GET"
        })
            .then((resposta) => {
                return resposta.json();

            }).then((dados) => {
                if (Array.isArray(dados)) {
                    setDoacoes([...dados]);
                }
            })
            .catch((erro) => {
                console.error("Erro ao buscar os dados do banco: " + erro);
            });
        setExibirTabela(true);
    }, []);

    return (
        <PaginaDoacoes>
            <Container className="border m-3">
                {
                    exibirTabela ?
                        <TabelaCadastroDoacoes listaDoacoes={doacoes} exibirTabela={setExibirTabela} setDoacoes={setDoacoes} editarDoacao={preparaDoacao} atualizarTabela={atualizarTabela} setAtualizarTabela={setAtualizarTabela} excluirDoacao={excluirDoacao} />
                        :
                        <FormDoacao listaDoacoes={doacoes} exibirTabela={setExibirTabela} setDoacoes={setDoacoes} modoEdicao={atualizando} doacao={doacaoEdicao} />
                }
            </Container>
        </PaginaDoacoes>
    );
}