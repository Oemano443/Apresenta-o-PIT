import PaginaItensDoacao from "../../Paginas/PaginaItensDoacao";
import { Button } from "react-bootstrap";
import { Link } from 'react-router-dom';
import {Table, Form} from "react-bootstrap"

export default function TelaAjudaItensDoacao(propriedades){
    return(
        <PaginaItensDoacao>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/itensdoacao">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                <Table striped bordered hover>
<thead>
    <tr>
        <th>Componente</th>
        <th>Informações</th>
    </tr>
</thead>
<tbody>
    
    <tr>
        <td>Tabela</td>
        <td>A Tabela apresenta registros dos itens para doações já cadastrados.</td>
    </tr>
    <tr>
        <td>Botão - Edição</td>
        <td>Possibilita a alteração das informações cadastradas para determinado item de doação.</td>
    </tr>
    <tr>
        <td>Botão - Exclusão</td>
        <td>Possibilita a exclusão de determinado item de doação cadastrado.</td>
    </tr>

</tbody>
</Table>
<br/>
<Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Campo</th>
        <th>Instruções de Preenchimento</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Código</td>
        <td>O Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
    </tr>
    <tr>
        <td>Descrição</td>
        <td>Nesse campo é inserida a descrição do item de doação.</td>
    </tr>
    <tr>
        <td>Tipo</td>
        <td>Nesse campo é selecionado o tipo item <b>(Demais)</b> ou dinheiro<b> (Valores)</b>.</td>
    </tr>
    
</tbody>

</Table>
<br/>
<Form.Label>Informações das funcionalidades dos Botões</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Botão</th>
        <th>Função</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Cadastrar</td>
        <td>Confirma o cadastramento do item de doação.</td>
    </tr>
    <tr>
        <td>Voltar</td>
        <td>Retorna para a Tela que mostra os itens de doação já cadastrados.</td>
    </tr>
    <tr>
        <td>Ajuda</td>
        <td>Apresenta orientações de preenchimento e demais funções do Cadastro para Itens de Doação.</td>
    </tr>
</tbody>
</Table>
                
</div>
    </PaginaItensDoacao>
    );
}



