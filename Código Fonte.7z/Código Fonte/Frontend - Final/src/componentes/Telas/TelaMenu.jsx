import Menu from '../Menus/menu';
import Header from '../Headers/cabecalho';
import Cards from '../Cards/Cards';
import adocaojpg from '../../imagens/adocao1.jpg'
import despesajpg from '../../imagens/despesa1.jpg'
import doacaojpg from '../../imagens/doacao.jpg'
import sorteiojpg from '../../imagens/sorteio.jpg'


import { Button } from 'react-bootstrap';





                                      
export default function TelaPrincipal(propriedades){
  

  

    return (

       <div style={{width: '100%'}}>
       <Menu texto='Pet Adote'/>
       <Header texto='Bem-vindo ao Pet Adote !!!'/>
        <div style={{alignItems: "center", textAlign: 'center', display: 'flex', marginLeft:'80px', marginTop: '50px'}}>
        <div style={{ margin: '0 10px'}}>
        <Cards titulo="Registro de Adoções" 
        texto="Registre suas Adoções Aqui"
        botao="Realizar Adoção"
        url={adocaojpg}
        rota="/adocoes"
        /> 
        </div>
        

        <div style={{ margin: '0 10px'}}>
        <Cards titulo="Lançar Despesas" 
        texto="Registre suas Despesas Aqui"
        botao="Lançar Despesas"
        url={despesajpg}
        rota="/despesas"
        />
        </div>


        <div style={{ margin: '0 10px'}}>
        <Cards titulo="Lançar Doações" 
        texto="Registre suas Doações Aqui"
        botao="Lançar Doações"
        url={doacaojpg}
        rota="/doacoes"
        />
        </div>


        <div style={{ margin: '0 10px'}}>
        <Cards titulo="Sorteio de Rifa" 
        texto="Sortear Rifa Aqui"
        botao="Sorteio de Rifa"
        url={sorteiojpg}
        rota="/sorteiorifa"
        />
        </div>


        </div>


       </div>
      );
}




