import PaginaAjudaSorteioRifas from "../../Paginas/PaginaAjudaSorteioRifas";
import { Button } from "react-bootstrap";
import { Link } from 'react-router-dom';
import {Table, Form} from "react-bootstrap"

export default function TelaAjudaRacas(propriedades){
    return(
        <PaginaAjudaSorteioRifas>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/sorteiorifa">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito da função de sorteio</h1><br/>
                <Table striped bordered hover>
<thead>
    <tr>
        <th>Componente</th>
        <th>Informações</th>
    </tr>
</thead>
<tbody>
    
    <tr>
        <td>Campo de seleção <b>"Selecione uma Rifa"</b></td>
        <td>Nesse campo é selecionada alguma rifa já cadastrada para sorteio.</td>
    </tr>
    <tr>
        <td>Botão <b>"Sortear Rifa"</b></td>
        <td>Sorteia um número aleatório e logo abaixo é mostrado o resultado do sorteio.</td>
    </tr>
    <tr>
        <td>Botão <b>"Editar Rifas"</b></td>
        <td>Encaminha o usuário para tabela onde estão as rifas cadastradas.</td>
    </tr>
    <tr>
        <td>Botão <b>"Excluir Rifas"</b></td>
        <td>Encaminha o usuário para tabela onde estão as rifas cadastradas.</td>
    </tr>
    

</tbody>
</Table>

                
</div>
    </PaginaAjudaSorteioRifas>
    );
}



