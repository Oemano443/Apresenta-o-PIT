import PaginaRifas from '../../Paginas/PaginaRifas';
import FormRifas from '../Formularios/FormRifas';
import { useState, useEffect } from 'react';
import TabelaCadastroRifas from '../../tabelas/TabelaCadastroRifas';
import { Container, Alert } from 'react-bootstrap';
import { urlBase } from '../../utilitarios/URL/Url';

export default function TelaCadastroRifas(props) {

    const [rifas, setRifas] = useState([]);
    const [exibirTabela, setExibirTabela] = useState(true);
    const [atualizando, setAtualizando] = useState(false);
    const [atualizarTabela, setAtualizarTabela] = useState(false);
    const [rifaEdicao, setRifaEdicao] = useState({
        codigo: "",
        descricao: "",
        tipo: "Impressa",
        premiacao: "",
        dataInic: "",
        dataSort: "",
    })

    function preparaRifa(rifa) {
        setAtualizando(true);
        setRifaEdicao(rifa)
        setExibirTabela(false);

    }

    function excluirRifa(rifa){
        fetch(urlBase + '/rifa',{
            method:"DELETE",
            headers:{"Content-Type":'application/json'},
            body: JSON.stringify(rifa)
        }).then((resposta)=>{
           return resposta.json()
        }).then((retorno)=>{
            setAtualizarTabela(true) 
            window.alert('Dados apagados com sucesso !!! ')
            window.location.reload();
            if(retorno.resultado){
                console.log('  ')
    
        } else if (retorno.resultado === false){
            window.alert('Não foi possível apagar os dados do colaborador !!!');
        } 
        })
    }









    useEffect(() => {
        fetch(urlBase + "/rifa", {
            method: "GET"
        })
            .then((resposta) => {
                return resposta.json();

            }).then((dados) => {
                if (Array.isArray(dados)) {
                    setRifas([...dados]);
                }
            })
            .catch((erro) => {
                console.error("Erro ao buscar os dados do banco: " + erro);
            });
        setExibirTabela(true);
    }, []);



    return (
        <PaginaRifas>
            <Container className="border m-3">
                {
                    exibirTabela ?
                        <TabelaCadastroRifas listaRifas={rifas} exibirTabela={setExibirTabela} setRifas={setRifas} editarRifa={preparaRifa} atualizarTabela={atualizarTabela} setAtualizarTabela={setAtualizarTabela} excluirRifa={excluirRifa} />
                        :
                        <FormRifas listaRifas={rifas} exibirTabela={setExibirTabela} setRifas={setRifas} modoEdicao={atualizando} rifa={rifaEdicao}/>
                }
            </Container>
        </PaginaRifas>
    );
}