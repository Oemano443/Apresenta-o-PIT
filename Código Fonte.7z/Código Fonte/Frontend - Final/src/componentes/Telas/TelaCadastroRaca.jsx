import PaginaRacas from "../../Paginas/PaginaRacas";
import FormRaca from "../Formularios/FormRaca";
import TabelaRaca from "../../tabelas/TabelaRaca";
import {useState, useEffect} from "react";
import {Alert} from "react-bootstrap";
import { urlRaca } from "../../utilitarios/URL/Url";

export default function TelaCadastroRaca(props){

    const[exibirTabela, setExibirtabela] = useState(true);
    const[raca,setRaca] = useState([]);
    const[listaRaca, setListaRaca] = useState([]);
    const[erro,setErro] = useState(null);
    const[processado,setProcessado]=useState(false);
    const[modoEdicao,setModoEdicao]=useState(false);
    const[racaEmEdicao,setRacaEmEdicao]=useState(
        {
            codigo: "",
            descricao:""
        }
    );

    function prepararParaEdicao(raca){
        setModoEdicao(true);
        setRacaEmEdicao(raca);
        setExibirtabela(false);
    }

    function buscarRaca(){
        fetch(urlRaca+"/racas",{
            method:"GET"
        }).then((resposta)=>{
            if (resposta.ok){
                return resposta.json();
            }
        }).then ((dados)=>{
            setProcessado(true);
            setExibirtabela(dados);
        },(error)=>{
            setProcessado(true);
            setErro(error);
        });
    }


    function apagarRaca(raca){
        fetch(urlRaca+"/racas",{
            method:"DELETE",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(raca)
        }).then ((resposta)=>{
           // return resposta.json() 
            alert("Raça excluída com sucesso!")
            window.location.reload();
        }).then((retorno)=>{
            if (retorno.resultado){
                window.alert('aaa')
                buscarRaca();
            }
            else{
                alert("Não foi possível excluir a Raça!");
            }
        });
    }

    useEffect(()=>{
        fetch(urlRaca+"/racas",{
            method:"GET"
        }).then((resposta)=>{
            return resposta.json();
        }).then ((dados)=>{
            if (Array.isArray(dados)){
                setRaca(dados);
            }
            else{
                //erro
            }
        })
    },[]);

    return (
        <PaginaRacas>
            {
                exibirTabela ?
                    <TabelaRaca listaRaca={raca}
                        setRaca={setRaca}
                        exibirTabela={setExibirtabela}
                        editarRaca={prepararParaEdicao}
                        excluirRaca={apagarRaca} />
                    :
                    <FormRaca listaRaca={raca}
                        setRaca={setRaca}
                        exibirTabela={setExibirtabela}
                        modoEdicao={modoEdicao}
                        setModoEdicao={setModoEdicao}
                        raca={racaEmEdicao}/>
            }
        </PaginaRacas>
    );

}