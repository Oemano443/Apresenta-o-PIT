import { useState } from "react"
import { useEffect } from "react"
import TabelaTipoDespesas from "../../tabelas/TabelaTipoDespesas"
import FormTiposDespesas from "../Formularios/FormTiposDespesas"
import PaginaTiposDespesas from "../../Paginas/PaginaTiposDespesas"
import { urlBackend } from "../../utilitarios/URL/Url"



export default function TelaTipoDespesas(propriedades){
    const [exibirTabela,setExibirTabela] = useState(true) ;
    const [despesas,setDespesas] = useState([]);
    const [atualizar,setAtualizar] = useState(false);
    const [despesaAtualizando,SetdespesaAtualizando] = useState({
        codigo: "",
        descricao: "",
        classificacao: "administrativa mensal"
})



function ApagarDespesa(despesa){
    fetch(urlBackend+'/tiposdespesas',{
        method:'DELETE',
        headers:{"Content-Type":'application/json'},
        body: JSON.stringify(despesa)
    }).then((resposta)=>{
        return resposta.json()
    }).then((retorno)=>{
        window.location.reload()
        window.alert('Dados apagados com sucesso !!! ')
        if(retorno.ok){
            exibirTabela(true)
        } else if(!retorno) {
            window.alert('Não foi possível apagar os dados referente a despesa !!!');
        }
    })
}




function EditarDespesa(despesa){
    setAtualizar(true);
    SetdespesaAtualizando(despesa);
    setExibirTabela(false);
}



// Recupera dados no banco de dados para colocar na tabela
useEffect(()=>{
    fetch(urlBackend + "/tiposdespesas", {
        method:'GET',
        
        headers: {
            'Content-Type': 'application/json'
        }
    }).then((resposta)=>{
        console.log(resposta)
        return resposta.json();

    }).then((dados)=>{
        console.log(dados)
        if(Array.isArray(dados)){
            
         setDespesas(dados)
                        
         
        } else {

        }
    })
         },[]);



    return(
        <PaginaTiposDespesas>
            {exibirTabela ? <TabelaTipoDespesas listaDespesas={despesas} setDespesas={setDespesas}  exibirTabela={setExibirTabela}  editarDespesa={EditarDespesa} apagarDepesa={ApagarDespesa} /> 
            : 
            <FormTiposDespesas listaDespesas={despesas} setDespesas={setDespesas}  exibirTabela={setExibirTabela} despesa={despesaAtualizando} modoEdicao={atualizar}/>    
        }

        </PaginaTiposDespesas>
    )
    


}