import React, { useState, useEffect } from 'react';
import PaginaCadastroUsuario from '../../Paginas/PaginaCadastroUsuarios.js';
import FormCadastros from '../Formularios/FormCadastros.jsx';
import TabelaCadastros from '../../tabelas/TabelaCadastros';
import { Container, Alert } from 'react-bootstrap';
import { urlBase } from '../../utilitarios/URL/Url.js';

export default function TelaCadastros(props) {

    const [cadastros, setCadastros] = useState([]);
    const [exibirTabela, setExibirTabela] = useState(true);
    const [atualizando, setAtualizando] = useState(false);
    const [atualizarTabela, setAtualizarTabela] = useState(false);
    const [cadastroEdicao, setCadastroEdicao] = useState({
        codigo: "",
        usuario: "",
        senha: "",
        nivel: "Básico",
    })

    function preparaCadastro(cadastro) {
        setAtualizando(true);
        setCadastroEdicao(cadastro)
        setExibirTabela(false);
    }

    function excluirCadastro(cadastro) {
        fetch(urlBase + '/cadastro', {
            method: "DELETE",
            headers: { "Content-Type": 'application/json' },
            body: JSON.stringify(cadastro)
        }).then((resposta) => {
            return resposta.json()
        }).then((retorno) => {
            setAtualizarTabela(true)
            window.alert('Dados apagados com sucesso !!! ')
            window.location.reload();
            if (retorno.resultado) {
                console.log('  ')
            } else if (retorno.resultado === false) {
                window.alert('Não foi possível apagar os dados do usuário !!!');
            }
        })
    }

    useEffect(() => {
        fetch(urlBase + "/cadastro", {
            method: "GET"
        })
            .then((resposta) => {
                return resposta.json();
            }).then((dados) => {
                if (Array.isArray(dados)) {
                    setCadastros([...dados]);
                }
            })
            .catch((erro) => {
                console.error("Erro ao buscar os dados do banco: " + erro);
            });
        setExibirTabela(true);
    }, []);

    return (
        <PaginaCadastroUsuario>
            <Container className="border m-3">
                {
                    exibirTabela ?
                        <TabelaCadastros listaCadastros={cadastros} exibirTabela={setExibirTabela} setCadastros={setCadastros} editarCadastro={preparaCadastro} atualizarTabela={atualizarTabela} setAtualizarTabela={setAtualizarTabela} excluirCadastro={excluirCadastro} />
                        :
                        <FormCadastros listaCadastros={cadastros} exibirTabela={setExibirTabela} setCadastros={setCadastros} modoEdicao={atualizando} cadastro={cadastroEdicao} />
                }
            </Container>
        </PaginaCadastroUsuario>
    );
}
