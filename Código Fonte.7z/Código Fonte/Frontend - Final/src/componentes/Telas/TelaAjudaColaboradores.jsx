import PaginaAjudaColaboradores from "../../Paginas/PaginaAjudaColaboradores"
import { Button } from "react-bootstrap";
import { Link } from 'react-router-dom';
import {Table, Form} from "react-bootstrap"

export default function TelaAjudaColaboradores(propriedades){
    return(
        <PaginaAjudaColaboradores>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/colaboradores">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                <Table striped bordered hover>
<thead>
    <tr>
        <th>Componente</th>
        <th>Informações</th>
    </tr>
</thead>
<tbody>
    
    <tr>
        <td>Tabela</td>
        <td>A Tabela apresenta registros de colaboradores cadastrados.</td>
    </tr>
    <tr>
        <td>Botão - Edição</td>
        <td>Possibilita a alteração das informações cadastradas para determinado colaborador.</td>
    </tr>
    <tr>
        <td>Botão - Exclusão</td>
        <td>Possibilita a exclusão de determinado colaborador cadastrado.</td>
    </tr>

</tbody>
</Table>
<br/>
<Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Campo</th>
        <th>Instruções de Preenchimento</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Código</td>
        <td>O Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
    </tr>
    <tr>
        <td>CPF</td>
        <td>Nesse campo é inserido o CPF do colaborador <b>(é necessário que seja um CPF válido para a efetivação do cadastro)</b> .</td>
    </tr>
    <tr>
        <td>Categoria do Colaborador</td>
        <td>Nesse campo é selecionada a categoria que deseja atribuir ao colaborador.</td>
    </tr>
    <tr>
        <td>Nome do Colaborador</td>
        <td>Nesse campo é inserido o nome do colaborador.</td>
    </tr>
    <tr>
        <td>Data de Nascimento</td>
        <td>Nesse campo é inserida a data de nascimento do colaborador.</td>
    </tr>
    <tr>
        <td>Telefone</td>
        <td>Nesse campo é inserido o número de telefone/celular do colaborador.</td>
    </tr>
    <tr> 
        <td>E-mail</td>
        <td>Nesse campo é inserido o e-mail do colaborador.</td>
    </tr>
    <tr>
        <td>CEP</td>
        <td>Nesse campo é inserido o CEP do colaborador.</td>
    </tr>
    <tr>
        <td>Logradouro</td>
        <td>Nesse campo é inserido o endereço do colaborador. <br/>(Exemplos: " Rua Tiradentes ", " Rua Ricardo Vieira ", " Avenida Washington Luiz".)</td>
    </tr>
    <tr>
        <td>Número</td>
        <td>Nesse campo é inserido o número de residência do colaborador.</td>
    </tr>
    <tr>
        <td>Complemento</td>
        <td>Nesse campo é inserido um complemento para o endereço colocado no campo de "Logradouro". <br/>(Exemplos: "bloco, apartamento, casa, sobrado, etc".)</td>
    </tr>
    <tr>
        <td>Bairro</td>
        <td>Nesse campo é inserido o bairro onde reside o colaborador.</td>
    </tr>
    <tr>
        <td>Cidade</td>
        <td>Nesse campo é inserida a cidade onde reside o colaborador.</td>
    </tr>
    <tr>
        <td>Estado (UF)</td>
        <td>Nesse campo é selecionado o estado atual onde o colaborador reside.</td>
    </tr>


</tbody>

</Table>
<br/>
<Form.Label>Informações das funcionalidades dos Botões</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Botão</th>
        <th>Função</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Cadastrar</td>
        <td>Confirma o cadastramento do colaborador.</td>
    </tr>
    <tr>
        <td>Voltar</td>
        <td>Retorna para a Tela que mostra os colaboradores já cadastrados.</td>
    </tr>
    <tr>
        <td>Ajuda</td>
        <td>Apresenta orientações de preenchimento e demais funções do cadastro para colaboradores.</td>
    </tr>
</tbody>
</Table>
                


            </div>

        </PaginaAjudaColaboradores>
    );
}



