import { Container } from "react-bootstrap";
import Pagina404 from "../../Paginas/Pagina404";
import Modal from 'react-bootstrap/Modal';


export default function Tela404(propriedades){
   

    return(

   <Pagina404>
    <Container>     
        
            <div
            
            className="modal show"
            style={{ display: 'block', position: 'initial' }}
            >
           
            <Modal.Dialog>
                <Modal.Header closeButton>
                <Modal.Title>404</Modal.Title>
                </Modal.Header>

                <Modal.Body>
                <p>Página não encontrada !!!</p>
                </Modal.Body>

            </Modal.Dialog>
            </div>
    </Container>
    </Pagina404>
    );
}