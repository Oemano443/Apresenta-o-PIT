import PaginaAjudaAdocoes from "../../Paginas/PaginaAjudaAdocoes";
import { Button, Form } from "react-bootstrap";
import {Table} from "react-bootstrap";
import { Link } from 'react-router-dom';


export default function TelaAjudaAdocoes(propriedades){
    return(
        <PaginaAjudaAdocoes>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/adocoes">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                
                <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Componente</th>
                        <th>Informações</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        <td>Tabela</td>
                        <td>A Tabela apresenta registros das adoções cadastradas.</td>
                    </tr>
                    <tr>
                        <td>Botão - Edição</td>
                        <td>Possibilita a alteração das informações cadastradas para determinada adoção.</td>
                    </tr>
                    <tr>
                        <td>Botão - Exclusão</td>
                        <td>Possibilita a exclusão de determinada adoção cadastrada.</td>
                    </tr>

                </tbody>
            </Table>
            <br/>
            <Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Campo</th>
                        <th>Instruções de Preenchimento</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Código</td>
                        <td>O Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
                    </tr>
                    <tr>
                        <td>Data da Adoção</td>
                        <td>Nesse campo é inserida a data em que a adoção foi realizada.</td>
                    </tr>
                    <tr>
                        <td>Código do Adotante</td>
                        <td>Nesse campo é mostrado o código do adotante selecionado.</td>
                    </tr>
                    <tr>
                        <td>Selecione um Adotante</td>
                        <td>Nesse campo é selecionado o adotante por meio de seu nome.</td>
                    </tr>
                    <tr>
                        <td>Código do Animal</td>
                        <td>Nesse campo é mostrado o código do animal selecionado.</td>
                    </tr>
                    <tr>
                        <td>Selecione um Animal</td>
                        <td>Nesse campo é selecionado o animal por meio de seu nome.</td>
                    </tr>
                    <tr>
                        <td>Observação</td>
                        <td>Nesse campo é inserida alguma observação a respeito da adoção.</td>
                    </tr>
            
                    
                </tbody>

          </Table>
            <br/>
            <Form.Label>Informações das funcionalidades dos Botões</Form.Label>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Botão</th>
                        <th>Função</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Cadastrar</td>
                        <td>Confirma o cadastramento da adoção.</td>
                    </tr>
                    <tr>
                        <td>Voltar</td>
                        <td>Retorna para a Tela que mostra as adoções já cadastradas.</td>
                    </tr>
                    <tr>
                        <td>Ajuda</td>
                        <td>Apresenta orientações de preenchimento e demais funções do Cadastro para as adoções.</td>
                    </tr>
                </tbody>
            </Table>

            </div>

            </PaginaAjudaAdocoes>
    );
}