import PaginaAjudaRacas from "../../Paginas/PaginaAjudaRacas";
import { Button } from "react-bootstrap";
import { Link } from 'react-router-dom';
import {Table, Form} from "react-bootstrap"

export default function TelaAjudaRacas(propriedades){
    return(
        <PaginaAjudaRacas>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/raca">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                <Table striped bordered hover>
<thead>
    <tr>
        <th>Componente</th>
        <th>Informações</th>
    </tr>
</thead>
<tbody>
    
    <tr>
        <td>Tabela</td>
        <td>A Tabela apresenta registros de raças cadastradas.</td>
    </tr>
    <tr>
        <td>Botão - Edição</td>
        <td>Possibilita a alteração das informações cadastradas para determinada raça.</td>
    </tr>
    <tr>
        <td>Botão - Exclusão</td>
        <td>Possibilita a exclusão de determinada raça cadastrada.</td>
    </tr>

</tbody>
</Table>
<br/>
<Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Campo</th>
        <th>Instruções de Preenchimento</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Código</td>
        <td>O Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
    </tr>
    <tr>
        <td>Raça</td>
        <td>Nesse campo é inserida a raça do animal.</td>
    </tr>
    
</tbody>

</Table>
<br/>
<Form.Label>Informações das funcionalidades dos Botões</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Botão</th>
        <th>Função</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Cadastrar</td>
        <td>Confirma o cadastramento da raça.</td>
    </tr>
    <tr>
        <td>Voltar</td>
        <td>Retorna para a Tela que mostra as raças já cadastradas.</td>
    </tr>
    <tr>
        <td>Ajuda</td>
        <td>Apresenta orientações de preenchimento e demais funções do Cadastro de Raças.</td>
    </tr>
</tbody>
</Table>
                
</div>
    </PaginaAjudaRacas>
    );
}



