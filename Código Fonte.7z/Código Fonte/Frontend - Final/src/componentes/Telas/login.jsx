import { useRef, useState, useContext } from "react";
import styles from './css-login/page.module.css'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

import { AuthContext } from "../../contexts/AuthProvider/auth";
//import { useNavigate } from 'react-router-dom';

import { useNavigate } from 'react-router-dom';





const LoginPage = () => {


  const navigate = useNavigate();

  const {setLogado, logado} = useContext(AuthContext)
  const { login } = useContext(AuthContext)
  

const [usuario,SetUsuario] = useState('');
const [senha,SetSenha] = useState('');

  const logar = async () => {
    try {
      const resposta = await fetch('http://localhost:5000/cadastro/autenticar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usuario, senha }),
      });

      if (!resposta.ok) {
        window.alert('Usuário/Senha não identificado !!!')
        throw new Error('Erro na autenticação');
      
      } else {
        // Gerar um token temporário aleatório
       const TokenTemporário = Math.random().toString(36).substring(7);
       console.log(TokenTemporário) 
      login(TokenTemporário);
      
    
    setLogado(true)
        navigate('/menu')
      }

      const dados = await resposta.json();
      console.log(dados);
      
    } catch (error) {
      console.error('Erro na requisição:', error.message);
      // Adicione a lógica necessária para lidar com erros, por exemplo, exibir uma mensagem de erro
    }
  };



//const navigate = useNavigate();



  return (
   <div id="login">
    <div className={styles.ajustDiv}>
    

    <Form className={styles.ajuste} onSubmit={(e)=>{
      e.preventDefault()
      logar()
    }}>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Usuário</Form.Label>
        <Form.Control value={usuario} onChange={(e)=>{
          SetUsuario(e.currentTarget.value)
        }} type="text" name="usuario" placeholder="Digite o nome de usuário ..." required/>
        
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Senha</Form.Label>
        <Form.Control  value={senha} onChange={(e)=>{
         SetSenha(e.currentTarget.value)
        }}  type="password" name="senha" placeholder="Digite a senha de login ..."  required/>
      </Form.Group>

      <Button variant="primary" type="submit">
        Entrar
      </Button>
    </Form>
    </div>


    </div>

  )
      }


export default LoginPage;