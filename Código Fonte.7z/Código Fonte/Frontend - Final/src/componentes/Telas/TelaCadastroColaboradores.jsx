import PaginaColaborador from "../../Paginas/PaginaColaboradores";
import FormColaboradores from "../Formularios/FormColaboradores";
import TabelaColaboradores from "../../tabelas/TabelaColaboradores";
import { useState, useEffect } from "react";
import { urlBackend } from "../../utilitarios/URL/Url";


export default function TelaCadastroColaboradores(propriedades){

    const [exibirTabela,setEstado] = useState(true); // exibição da tabela
    const [colaboradores, setColaboradores] = useState([]); // lista atual de colaboradores
    const [atualizar,setAtualizar] = useState(false); // atualizar dados (estado de edição)
    const [atualizarTabela,setAtualizarTabela] = useState(false); // atualizar tabela (exclusão de dados)
    const [colaboradorAtualizando,setColaboradorAtualizando] = useState(  // colaborador em edição (qual registro está sendo atualizado)
        { 
                codColaborador: '',
                cpf: '',
                categoria: 'Voluntário',
                nome: '',
                dataNasc: '',
                telefone: '',
                email: '',
                cep: '',
                logradouro: '',
                numero: '',
                complemento: '',
                bairro: '',
                cidade: '',
                uf: 'SP'
        }
);


function EditarColaborador(colaborador){ // preparar para edição
    setAtualizar(true);
    setColaboradorAtualizando(colaborador);
    setEstado(false);
    
};



function ApagarColaborador(colaborador){
    fetch(urlBackend + '/colaboradores',{
        method:"DELETE",
        headers:{"Content-Type":'application/json'},
        body: JSON.stringify(colaborador)
    }).then((resposta)=>{
       return resposta.json()
    }).then((retorno)=>{
        setAtualizarTabela(true) // atualiza para true a atualização da tabela (a partir da linha 9 do código da tabela)
        window.alert('Dados apagados com sucesso !!! ')
        if(retorno.resultado){
            setEstado(true)

    } else if (retorno.resultado === false){
        window.alert('Não foi possível apagar os dados do colaborador !!!');
    } 
    })
}

    useEffect(()=>{
        fetch(urlBackend + "/colaboradores", {
            method:'GET',
        }).then((resposta)=>{
            return resposta.json();

        }).then((dados)=>{
            if(Array.isArray(dados)){
             setColaboradores(dados)
                               
            } else {

            }
        })
             },[]);


    return(
        
        <PaginaColaborador>            
           {exibirTabela? <TabelaColaboradores listaColaboradores={colaboradores} exibirTabela={setEstado} setColaboradores={setColaboradores} editarColaborador={EditarColaborador} excluirColaborador={ApagarColaborador} atualizarTabela={atualizarTabela} setAtualizarTabela={setAtualizarTabela}/> 
           : 
           <FormColaboradores listaColaboradores={colaboradores} 
           exibirTabela={setEstado} setColaboradores={setColaboradores} 

           modoEdicao={atualizar} colaborador={colaboradorAtualizando}/>}
        </PaginaColaborador>
        
        
    );
};


