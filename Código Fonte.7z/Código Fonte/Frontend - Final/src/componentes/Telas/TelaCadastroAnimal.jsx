import PaginaAnimais from "../../Paginas/PaginaAnimais";
import FormAnimal from "../Formularios/FormAnimal";
import TabelaAnimal from "../../tabelas/TabelaAnimal";
import { useState, useEffect } from "react"; 
import { urlAnimais } from "../../utilitarios/URL/Url";

export default function TelaCadastroAnimal(props) {

    const [exibirTabela, setExibirTabela] = useState(true);
    const [animal, setAnimal] = useState([]);
    const [listaAnimal, setListaAnimal] = useState([]);
    const [erro, setErro] = useState(null);
    const [processado, setProcessado] = useState(false);
    const [modoEdicao, setModoEdicao] = useState(false);
    const [animalEmEdicao, setAnimalEmEdicao] = useState(
        {
            codigo_animal:"",
            nome_animal:"",
            raca_animal:"",
            porte_animal:"",
            cor_animal:"",
            idade_animal:"",
            temperamento_animal:"",
            dataentrada_animal:"",
            vacinacao_animal:"",
            localencontrado_animal:"",
            localizacao_animal:"",
            necessidades_animal:"",
            disponibilidade_animal:"",
            dataadocao_animal:""
        }    
    ); 

    function prepararParaEdicao(animal){
        setModoEdicao(true);
        setAnimalEmEdicao(animal);
        setExibirTabela(false);
    }

    function buscarAnimal(){
        //realizando GET na lista de Animais
        fetch(urlAnimais+"/animais",{
            method:"GET"
        }).then((resposta)=>{
            if (resposta.ok){
                return resposta.json();
            }
        }).then((dados)=>{
            setProcessado(true);
            setExibirTabela(dados);
        }, (error)=>{
            setProcessado(true);
            setErro(error);
        });
    }

    function apagarAnimal(animal){
        fetch(urlAnimais+"/animais",{
            method:"DELETE",
            headers:{
                'Content-type':'application/json'
            },
            body:JSON.stringify(animal)
        }).then((resposta)=>{
            //return resposta.json()
            alert("Animal excluído com sucesso")
            window.location.reload();
        }).then((retorno)=>{
            if (retorno.resultado){
                buscarAnimal();//exibe tabela?
            }
            else{
                alert("Não foi possível excluir o Animal 123!");
            }
        });
    }

     //carregar os dados dos animais a partir do backend
     //A busca de animais seja realizado no ciclo de vida do componente TelaCadastroAnimal
     //no momento de renderização (willMount)

    //useEffect com comportamento de willMount - passa uma lista vazia []
    //useEffect com comportamento de update, passa um parâmetro [animais]
    useEffect(()=>{
        fetch(urlAnimais+"/animais",{
           method:"GET"
        }).then((resposta)=>{
            return resposta.json();
        }).then((dados)=>{
            if (Array.isArray(dados)){
                setAnimal(dados);
            }
            else{
                //erro
            }
        })
     },[]); 

    return (
        <PaginaAnimais>
            
                {
                    //utilização do operador ternário 
                    exibirTabela ?
                        <TabelaAnimal listaAnimal={animal}
                            setAnimal={setAnimal}
                            exibirTabela={setExibirTabela} 
                            editarAnimal={prepararParaEdicao}
                            excluirAnimal={apagarAnimal}/>
                        :
                        <FormAnimal listaAnimal={animal}
                            setAnimal={setAnimal}
                            exibirTabela={setExibirTabela} 
                            modoEdicao={modoEdicao}
                            setModoEdicao={setModoEdicao}
                            animal={animalEmEdicao}/>
                }
            
        </PaginaAnimais>

    );
}

