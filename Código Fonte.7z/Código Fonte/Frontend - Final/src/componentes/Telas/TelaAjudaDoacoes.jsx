import PaginaAjudaDoacoes from "../../Paginas/PaginaAjudaDoacoes";
import { Button } from "react-bootstrap";
import { Link } from 'react-router-dom';
import {Table, Form} from "react-bootstrap"

export default function TelaAjudaDoacoes(propriedades){
    return(
        <PaginaAjudaDoacoes>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/doacoes">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                <Table striped bordered hover>
<thead>
    <tr>
        <th>Componente</th>
        <th>Informações</th>
    </tr>
</thead>
<tbody>
    
    <tr>
        <td>Tabela</td>
        <td>A Tabela apresenta registros de doações cadastradas.</td>
    </tr>
    <tr>
        <td>Botão - Edição</td>
        <td>Possibilita a alteração das informações cadastradas para determinada doação.</td>
    </tr>
    <tr>
        <td>Botão - Exclusão</td>
        <td>Possibilita a exclusão de determinada doação cadastrada.</td>
    </tr>

</tbody>
</Table>
<br/>
<Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Campo</th>
        <th>Instruções de Preenchimento</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Código</td>
        <td>O Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
    </tr>
    
    <tr>
        <td>Data da Doação</td>
        <td>Nesse campo é inserida a data da doação.</td>
    </tr>

    <tr>
        <td>Código do Doador</td>
        <td>Nesse campo é mostrado o código do doador selecionado.</td>
    </tr>
    <tr>
        <td>Selecione um Doador</td>
        <td>Nesse campo é selecionado um colaborador com a categoria de doador.</td>
    </tr>

    <tr>
        <td>Código do Tipo de Item</td>
        <td>Nesse campo é mostrado o código do tipo de item selecionado.</td>
    </tr>

    <tr>
        <td>Selecione um Tipo de Item</td>
        <td>Nesse campo é selecionado o tipo de item para doação.</td>
    </tr>

    <tr>
        <td>Quantidade/Valor</td>
        <td>Nesse campo é selecionada a quantidade do item ou valor específico registrado.</td>
    </tr>
    <tr>
        <td>Observação</td>
        <td>Nesse campo é inserido observações a respeito da doação.</td>
    </tr>
</tbody>

</Table>
<br/>
<Form.Label>Informações das funcionalidades dos Botões</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Botão</th>
        <th>Função</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Cadastrar</td>
        <td>Confirma o cadastramento da raça.</td>
    </tr>
    <tr>
        <td>Voltar</td>
        <td>Retorna para a Tela que mostra as raças já cadastradas.</td>
    </tr>
    <tr>
        <td>Ajuda</td>
        <td>Apresenta orientações de preenchimento e demais funções do Cadastro de Raças.</td>
    </tr>
</tbody>
</Table>
                
</div>
    </PaginaAjudaDoacoes>
    );
}



