import React, { useState, useEffect } from 'react';
import { Table, Button, Form, Row, Col } from 'react-bootstrap';
import { urlBase } from '../../utilitarios/URL/Url';
import PaginaSorteioRifas from '../../Paginas/PaginaSorteioRifas';
import { Link } from 'react-router-dom'; // Importe o Link do React Router
import { LinkContainer } from 'react-router-bootstrap';

export default function ResultadoSorteioRifa() {
    const [rifas, setRifas] = useState([]);
    const [selectedRifa, setSelectedRifa] = useState('');
    const [codigo, setCodigo] = useState('');
    const [sorteou, setSorteou] = useState(false);

    const [Numinicial,SetNumInicial] = useState('');
    const [Numfinal,SetNumFinal] = useState('');

    /*
    useEffect(() => {
        // Faça uma chamada à sua API para buscar a lista de rifas disponíveis
        fetch(urlBase + '/rifa') // Atualize para o endpoint correto da sua API
            .then((response) => response.json())
            .then((data) => {
                setRifas(data);
            })
            .catch((error) => {
                console.error('Erro ao buscar rifas:', error);
            });
    }, []);
*/

useEffect(() => {
    fetch(urlBase + '/rifa', {method: 'GET'})
        .then((response) => response.json())
        .then((data) => {
            // Certifique-se de que data é um array antes de definir rifas
            if (Array.isArray(data)) {
                console.log('a',data)
                setRifas(data);
            } else {
                console.error('A resposta da API não é um array:', data);
            }
        })
        .catch((error) => {
            console.error('Erro ao buscar rifas:', error);
        });
}, []);






/*
    const sortearRifa = () => {
        if (selectedRifa === '') {
            alert('Selecione uma rifa antes de sortear.');
            return;
        }

        // Filtrar as rifas que possuem a mesma descrição selecionada
        const rifasFiltradas = rifas.filter((rifa) => rifa.descricao === selectedRifa);

        if (rifasFiltradas.length === 0) {
            alert('Nenhuma rifa encontrada com a descrição selecionada.');
            return;
        }

        // Criar uma lista de números (códigos) a serem sorteados
        const numerosSorteio = rifasFiltradas.map((rifa) => rifa.codigo);

        // Sortear um número da lista de números
        const numeroSorteado = numerosSorteio[Math.floor(Math.random() * numerosSorteio.length)];
        

        setCodigo(numeroSorteado);
        setSorteou(true);
        
    };*/

    const sortearRifa = () => {
        if (selectedRifa === '') {
            alert('Selecione uma rifa antes de sortear.');
            return;
        }
    
        // Converta os valores para números
        const min = parseInt(Numinicial);
        const max = parseInt(Numfinal);
    
        if (isNaN(min) || isNaN(max)) {
            alert('Insira números válidos para a faixa de números.');
            return;
        }
    
        // Filtrar as rifas que possuem a mesma descrição selecionada
        const rifasFiltradas = rifas.filter((rifa) => rifa.descricao === selectedRifa);
    
        if (rifasFiltradas.length === 0) {
            alert('Nenhuma rifa encontrada com a descrição selecionada.');
            return;
        }
    
        // Criar uma lista de números (códigos) a serem sorteados
        const numerosSorteio = rifasFiltradas.map((rifa) => rifa.codigo);
    
        // Sortear um número da lista de números
        const numeroSorteado = Math.floor(Math.random() * (max - min + 1)) + min;
        console.log(numeroSorteado);
    
        setCodigo(numeroSorteado);
        setSorteou(true);
    };


    // Filtrar as descrições distintas
    const descricoesDistintas = [...new Set(rifas.map((rifa) => rifa.descricao))];

    return (
        <PaginaSorteioRifas>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/ajudasorteiorifas">
                    <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                </Link> 
            </div>
            <LinkContainer to='/menu'><Button id="btnVoltar" variant='dark' style={{  position: 'relative', marginBottom: '50px' }}>
                Voltar para Menu</Button></LinkContainer>


                <br/><br/>
                <h1>Selecione a faixa de números</h1>
                <Form.Group>
                    <Row>
                        <Col>
                        <Form.Label>Número Inicial</Form.Label>
                        <Form.Control 
                        placeholder='Número Inicial' 
                        value={Numinicial}
                        onChange={(e)=>{
                            SetNumInicial(e.currentTarget.value)
                        }}/>
                        </Col>
                        <br/>
                        <Col>
                        <Form.Label>Número Final</Form.Label>
                        <Form.Control 
                        placeholder='Número Final'
                        value={Numfinal}
                        onChange={(e)=>{
                            SetNumFinal(e.currentTarget.value)
                        }}
                        />
                        </Col>
                    </Row>
                    </Form.Group>
                    <br/><br/>
            <h2>Resultados dos Sorteios</h2>
            <Row>
                <Col md={6}>
                    <Form.Group>
                        <Form.Label>Selecione uma Rifa:</Form.Label>
                        <Form.Select value={selectedRifa} onChange={(e) => setSelectedRifa(e.target.value)}>
                            <option value="">Selecione uma rifa</option>
                            {descricoesDistintas.map((descricao, index) => (
                                <option key={index} value={descricao}>
                                    {descricao}
                                </option>
                            ))}
                        </Form.Select>
                    </Form.Group>
                   
                </Col>
                <Col md={6} className="d-flex align-items-end">
                    <Button variant="success" onClick={sortearRifa}>
                        Sortear Rifa
                    </Button>
                </Col>
            </Row>
            
            {sorteou && (

                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>Número do Vencedor</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{codigo}</td>
                            <td>
                                <Link to={`/rifa`} className="btn btn-primary">
                                    <Button variant='warning'>Modificar Rifas</Button>
                                </Link>{' '}
                                
                            </td>
                        </tr>
                    </tbody>
                </Table>

            )}
        </PaginaSorteioRifas>
    );
}
