import PaginaItensDoacao from "../../Paginas/PaginaItensDoacao";
import FormIdoacao from "../Formularios/FormIdoacao";
import TabelaIdoacao from "../../tabelas/TabelaIdoacao";
import {useState, useEffect} from "react";
import {Alert, Container} from "react-bootstrap";
import { urlBase } from "../../utilitarios/URL/Url";

export default function TelaCadastroIdoacao(props){

    const[exibirTabela, setExibirtabela] = useState(true);
    const[idoacao,setIdoacao] = useState([]);
    const[listaIdoacao, setListaIdoacao] = useState([]);
    const[erro,setErro] = useState(null);
    const[processado,setProcessado]=useState(false);
    const[modoEdicao,setModoEdicao]=useState(false);
    const[idoacaoEmEdicao,setIdoacaoEmEdicao]=useState(
        {
            codigo_idoacao:"",
            desc_idoacao:"",
            tipo_idoacao:""
        }
    );

    function prepararParaEdicao(idoacao){
        setModoEdicao(true);
        setIdoacaoEmEdicao(idoacao);
        setExibirtabela(false);
    }

    function buscarIdoacao(){
        fetch(urlBase+"/itensdoacao",{
            method:"GET"
        }).then((resposta)=>{
            if (resposta.ok){
                return resposta.json();
            }
        }).then ((dados)=>{
            setProcessado(true);
            setExibirtabela(dados);
        },(error)=>{
            setProcessado(true);
            setErro(error);
        });
    }

    function apagarIdoacao(idoacao){
        fetch(urlBase+"/itensdoacao",{
            method:"DELETE",
            headers:{"Content-type":"application/json"},
            body:JSON.stringify(idoacao)
        }).then ((resposta)=>{
            if(resposta){
            alert("Item de doação excluída com sucesso!")
        }
            window.location.reload();
        }).then((retorno)=>{
            if (retorno.resultado){
                buscarIdoacao();
            }
            else{
                alert("Não foi possível excluir o Item de Doação!");
            }
        });
    }

    useEffect(()=>{
        fetch(urlBase+"/itensdoacao",{
            method:"GET"
        }).then((resposta)=>{
            return resposta.json();
        }).then ((dados)=>{
            if (Array.isArray(dados)){
                setIdoacao(dados);
            }
            else{
                //erro
            }
        })
    },[]);

    return (
        <PaginaItensDoacao>
            {
                exibirTabela ?
                    <TabelaIdoacao listaIdoacao={idoacao}
                        setIdoacao={setIdoacao}
                        exibirTabela={setExibirtabela}
                        editarIdoacao={prepararParaEdicao}
                        excluirIdoacao={apagarIdoacao} />
                    :
                    <FormIdoacao listaIdoacao={idoacao}
                        setIdoacao={setIdoacao}
                        exibirTabela={setExibirtabela}
                        modoEdicao={modoEdicao}
                        setModoEdicao={setModoEdicao}
                        idoacao={idoacaoEmEdicao}/>
            }
        </PaginaItensDoacao>
    );

}