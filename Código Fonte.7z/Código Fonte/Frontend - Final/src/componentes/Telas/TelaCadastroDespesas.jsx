import { useState, useEffect } from 'react';
import { urlBackend } from '../../utilitarios/URL/Url';
import FormDespesas from '../Formularios/FormDespesa';
import TabelaDespesas from '../../tabelas/TabelaDespesas';
import PaginaDespesas from '../../Paginas/PaginaDespesas';

export default function TelaCadastroDespesas(propriedades){
    const [exibirTabela,setExibirTabela] = useState(true); // exibição da tabela
    const [despesas, setDespesas] = useState([]); // lista atual de colaboradores
    const [modoEdicao, setModoEdicao] = useState(false);
    const [despesasAtualizando, setDespesasAtualizando] = useState({
        codigo : "",
        dataLancamento: "",
        Codcategoria_despesa: '',
        dataVencimento: "",
        dataPagamento: "",
        formaPagamento: "",
        valor: "",
        vinculaAnimal: 0,
        codigo_animal: "",
        observacoes: ""
    })
    
    function EditarDespesa(despesa){ // preparar para edição
        setModoEdicao(true);
        setDespesasAtualizando(despesa);
        setExibirTabela(false);
        
    };

    function ApagarDespesa(despesa){
        console.log(JSON.stringify(despesa))
        fetch(urlBackend + '/despesas',{
            method:"DELETE",
            headers:{"Content-Type":'application/json'},
            body: JSON.stringify(despesa)
        }).then((resposta)=>{
           return resposta.json()
          
        }).then((retorno)=>{
            window.alert('Dados apagados com sucesso !!! ')
            window.location.reload()
            if(retorno.resultado){
                setExibirTabela(true)
            } else if (!retorno.resultado) {
                console.log('Não foi possível apagar os dados da adoção !!!');
            }
        }).catch((erro) => {
            console.error(erro);
            window.alert('Erro ao excluir a despesa.');
        });
    }



    useEffect(()=>{
        fetch(urlBackend + "/despesas", {
            method:'GET',
        }).then((resposta)=>{
            return resposta.json();

        }).then((dados)=>{
            if(Array.isArray(dados)){
             setDespesas(dados)
                               
            } else {

            }
        })
             },[]);

    
    return(
        <PaginaDespesas>
            {
            exibirTabela ? 
            <TabelaDespesas listaDespesas={despesas} 
                            setDespesas={setDespesas} 
                            exibirTabela={setExibirTabela} 
                            EditarDespesa={EditarDespesa} 
                            ApagarDespesa={ApagarDespesa}/> 
            :
            <FormDespesas exibirTabela={setExibirTabela} 
                          modoEdicao={modoEdicao} 
                          setModoEdicao={setModoEdicao} 
                          despesa={despesasAtualizando}/> 
            }
        </PaginaDespesas>
    )
}