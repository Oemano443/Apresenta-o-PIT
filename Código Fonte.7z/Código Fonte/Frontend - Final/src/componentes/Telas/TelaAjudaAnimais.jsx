import PaginaAjudaAnimais from "../../Paginas/PaginaAjudaAnimais";
import { Button } from "react-bootstrap";
import { Link } from 'react-router-dom';
import {Table, Form} from "react-bootstrap"

export default function TelaAjudaAnimais(propriedades){
    return(
        <PaginaAjudaAnimais>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/animais">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                <Table striped bordered hover>
<thead>
    <tr>
        <th>Componente</th>
        <th>Informações</th>
    </tr>
</thead>
<tbody>
    
    <tr>
        <td>Tabela</td>
        <td>A Tabela apresenta registros de animais cadastrados.</td>
    </tr>
    <tr>
        <td>Botão - Edição</td>
        <td>Possibilita a alteração das informações cadastradas para determinado animal.</td>
    </tr>
    <tr>
        <td>Botão - Exclusão</td>
        <td>Possibilita a exclusão de determinado animal cadastrado.</td>
    </tr>

</tbody>
</Table>
<br/>
<Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Campo</th>
        <th>Instruções de Preenchimento</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Código</td>
        <td>O Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
    </tr>
    <tr>
        <td>Nome</td>
        <td>Nesse campo é inserido o nome do animal.</td>
    </tr>
    <tr>
        <td>Porte</td>
        <td>Nesse campo é inserido o porte do animal.</td>
    </tr>
    <tr>
        <td>Cor</td>
        <td>Nesse campo é inserida a cor do animal.</td>
    </tr>
    <tr>
        <td>Idade</td>
        <td>Nesse campo é inserida a idade do animal.</td>
    </tr>
    <tr>
        <td>Raça</td>
        <td>Nesse campo é inserida a raça do animal.</td>
    </tr>
    <tr>
        <td>Temperamento</td>
        <td>Nesse campo é inserido o temperamento do animal.</td>
    </tr>
    <tr>
        <td>Data de Entrada</td>
        <td>Nesse campo é inserida a data de entrada do registro que está sendo efetuado.</td>
    </tr>
    <tr>
        <td>Vacinação</td>
        <td>Nesse campo é inserida informações referente a vacinação do animal se está pendente ou não.</td>
    </tr>
    <tr>
        <td>Local Encontrado</td>
        <td>Nesse campo é inserido o local onde o animal foi encontrado.</td>
    </tr>
    <tr>
        <td>Localização Atual</td>
        <td>Nesse campo é inserida a localização atual do animal.</td>
    </tr>
    <tr>
        <td>Necessidades Especiais</td>
        <td>Nesse campo é inserido as necessidades especiais do animal se possui ou não possui.</td>
    </tr>
    <tr>
        <td>Disponível</td>
        <td>Nesse campo é selecionado a disponibilidade do animal se <b>Sim</b> ou <b>Não</b>.</td>
    </tr>
    <tr>
        <td>Data da Adoção</td>
        <td>Nesse campo é preenchido a data de adoção do animal <b>Caso tenha sido doado</b>.</td>
    </tr>
    
</tbody>

</Table>
<br/>
<Form.Label>Informações das funcionalidades dos Botões</Form.Label>
<Table striped bordered hover>
<thead>
    <tr>
        <th>Botão</th>
        <th>Função</th>
    </tr>
</thead>
<tbody>
    <tr>
        <td>Cadastrar</td>
        <td>Confirma o cadastramento de animais.</td>
    </tr>
    <tr>
        <td>Voltar</td>
        <td>Retorna para a Tela que mostra os animais já cadastrados.</td>
    </tr>
    <tr>
        <td>Ajuda</td>
        <td>Apresenta orientações de preenchimento e demais funções do Cadastro de Animais.</td>
    </tr>
</tbody>
</Table>
                
</div>
    </PaginaAjudaAnimais>
    );
}



