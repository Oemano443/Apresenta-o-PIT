import PaginaAjudaDespesas from "../../Paginas/PaginaAjudaDespesas";
import { Button, Form } from "react-bootstrap";
import {Table} from "react-bootstrap";
import { Link } from 'react-router-dom';


export default function TelaAjudaDespesas(propriedades){
    return(
        <PaginaAjudaDespesas>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/despesas">
                    <Button variant="light" style={{ color: 'black' }}>Retornar</Button>
                </Link>
            </div>
            <div>
                <h1>Orientações a respeito do Cadastro</h1><br/>
                
                <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Componente</th>
                        <th>Informações</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        <td>Tabela</td>
                        <td>A Tabela apresenta registros das despesas cadastradas.</td>
                    </tr>
                    <tr>
                        <td>Botão - Edição</td>
                        <td>Possibilita a alteração das informações cadastradas para determinada despesa.</td>
                    </tr>
                    <tr>
                        <td>Botão - Exclusão</td>
                        <td>Possibilita a exclusão de determinada despesa cadastrada.</td>
                    </tr>

                </tbody>
            </Table>
            <br/>
            <Form.Label> Informações para preenchimento dos Campos do Cadastro</Form.Label>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Campo</th>
                        <th>Instruções de Preenchimento</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Código de Controle</td>
                        <td>O Campo "Código" é de numeração sequencial e automática. Não é necessário o preenchimento.</td>
                    </tr>
                    <tr>
                        <td>Categoria da Despesa</td>
                        <td>Nesse campo é selecionado os tipos de despesas já cadastrados.</td>
                    </tr>
                    <tr>
                        <td>Data de Lançamento</td>
                        <td>Nesse campo é inserida a data em que o registro da despesa está sendo efetuado.</td>
                    </tr>
                    <tr>
                        <td>Data de Vencimento</td>
                        <td>Nesse campo é inserida a data de vencimento da despesa.</td>
                    </tr>
                    <tr>
                        <td>Data de Pagamento</td>
                        <td>Nesse campo é inserida a data em que o pagamento da despesa será ou já tenha sido efetuado.</td>
                    </tr>
                    <tr>
                        <td>Descrição da Despesa</td>
                        <td>Nesse campo é inserida automáticamente a descrição da despesa selecionada no campo "Categoria da Despesa".</td>
                    </tr>
                    <tr>
                        <td>Valor</td>
                        <td>Nesse campo é inserido o valor em dinheiro da despesa.</td>
                    </tr>
                    <tr>
                        <td>Forma de Pagamento</td>
                        <td>Nesse campo é selecionado a forma do pagamento que será efetuado.</td>
                    </tr>
                    
                </tbody>

                <br/><br/>
                <Form.Label>Vincular um animal a Despesa</Form.Label>
                <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Campo</th>
                        <th>Instruções de Preenchimento</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Vincular Animal</td>
                        <td>Nesse campo são selecionadas as opções de vincular um animal a uma despesa "Sim", ou não vincular nenhum animal a despesa "Não".</td>
                    </tr>
                    <tr>
                        <td>Código do Animal</td>
                        <td>Caso um animal tenha sido vinculado a uma despesa é mostrado o código do mesmo.</td>
                    </tr>
                    <tr>
                        <td>Nome do Animal</td>
                        <td>Nesse campo é selecionado o animal que deseja vincular a despesa por meio de seu nome.</td>
                    </tr>
                    <tr>
                        <td>Observações</td>
                        <td>Nesse campo podem ser inseridas informações a respeito do animal que esteja sendo vinculado a despesa.</td>
                    </tr>
                </tbody>
            </Table>






            </Table>
            <br/>
            <Form.Label>Informações das funcionalidades dos Botões</Form.Label>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Botão</th>
                        <th>Função</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Cadastrar</td>
                        <td>Confirma o cadastramento da despesa.</td>
                    </tr>
                    <tr>
                        <td>Voltar</td>
                        <td>Retorna para a Tela que mostra as despesas já cadastradas.</td>
                    </tr>
                    <tr>
                        <td>Ajuda</td>
                        <td>Apresenta orientações de preenchimento e demais funções do Cadastro para Despesas.</td>
                    </tr>
                </tbody>
            </Table>

            </div>

            </PaginaAjudaDespesas>
    );
}