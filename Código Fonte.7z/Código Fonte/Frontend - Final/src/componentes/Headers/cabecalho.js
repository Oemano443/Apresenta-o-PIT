import styles from './cabecalho.module.css'; // ajustes de cabeçalho


export default function Header(propriedade){
    return(
        <>
        <h1 className={`${styles.cabecalho} ${styles.esconderNaImpressao}`}>{propriedade.texto}</h1>
        </>      


 );
}
// <h1 className={styles.cabecalho}>{propriedade.texto}</h1>