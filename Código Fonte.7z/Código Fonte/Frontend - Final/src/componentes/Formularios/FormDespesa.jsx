import CaixaDeSelecao from "../CaixaSelecao/CaixaDeSelecao";
import { useState } from "react";
import { Button, Form, Row, Col, FormGroup, FormLabel, FormControl } from "react-bootstrap";
import { urlBackend } from "../../utilitarios/URL/Url";
import { Link } from "react-router-dom";

export default function FormDespesas(propriedades){
    const [tipoDespesas,setTipoDespesaSelecionada] = useState({})
    const [animalSelecionado, setAnimalSelecionado] = useState({})
    const [despesa,setDespesa] = useState(propriedades.despesa)
    const [validado, setValidado] = useState(false);
    
   function vincular(item){
    let permissao = true    
    if(item === "não"){
        permissao = true

        } else {
            permissao = false
        }
        return permissao
   }

   vincular(despesa.vinculaAnimal)

    function TratarSubmissao(evento) {
        const form = evento.currentTarget;
        if (form.checkValidity()) {
            if (propriedades.modoEdicao){
                
                fetch(urlBackend +'/despesas',{
                    method:"PUT",
                    headers:{
                        "Content-type":"application/json"
                    }, 
                    body:JSON.stringify(despesa)
                })
                .then((resposta)=>{
                    window.alert("Despesa atualizada com sucesso!");
                    window.location.reload();
                    return resposta.json();
                    
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição: "+erro.message);
                })
            }
            else{//significa que está aberto em modo de cadastro
                fetch(urlBackend + "/despesas",{
                    method:"POST",
                    headers:{
                        "Content-type":"application/json" 
                    },
                    body:JSON.stringify(despesa)
                })
                .then((resposta)=>{
                    return resposta.json();
                })
                .then((dados)=>{
                    if (dados.status){
                        propriedades.setModoEdicao(false);
                        window.location.reload();
                    }
                    window.alert(dados.mensagem);
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição: "+erro.message);
                })
            }
            
            setValidado(false);
        }
        else {
            setValidado(true);
        }
        evento.preventDefault();
        evento.stopPropagation();
    }

    function tratarEstado(evento){
        const elementoFormulario = evento.currentTarget; 
        const id = elementoFormulario.id; 
        const valor = elementoFormulario.value; 
        setDespesa({...despesa, [id]:valor}); 
  
      };


      





    return(

   <Form style={{width: '900px', marginLeft: '10%'}} onSubmit={TratarSubmissao}>
     <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/ajudadespesas">
                    <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                </Link>
            </div>
    <Row>
        <Col>
        <FormGroup className="mb-3" >
            <Form.Label>Código de Controle</Form.Label>
            <Form.Control 
            value={despesa.codigo}
            id="codigo"
             type="text"
             disabled
            />

        </FormGroup>
        </Col>

        <Col>
        <Form.Group>
            <Form.Label>Data de Lançamento</Form.Label>
            <Form.Control 
             type="date"
             value={despesa.dataLancamento}
             onChange={tratarEstado}
             id="dataLancamento"
            />
        <Form.Control.Feedback type="invalid">
        "Por favor, insira a Data de Lançamento !!!"
        </Form.Control.Feedback>
        </Form.Group>
        </Col>
    </Row>
    <hr/>
    
    <Row>
        <Col>
        <Form.Group >
            <Form.Label>Categoria da Despesa</Form.Label>
            <CaixaDeSelecao url="http://localhost:5000/tiposdespesas"
                                campoExibicao="descricao"
                                funcaoSelecao={setTipoDespesaSelecionada}
                                campoChave="codigo" 
                                id="Codcategoria_despesa"
                                value = {despesa.Codcategoria_despesa = tipoDespesas.codigo}
                                />
        </Form.Group>
        
        <Form.Group className="mb-3">
        <Form.Label>Descrição da Despesa</Form.Label>
        <Form.Control
        value={tipoDespesas.descricao}
        type="text"
        id="descricao"
        disabled
        />
        </Form.Group >
    
    <Form.Group>
        <Form.Label>Valor</Form.Label>
        <Form.Control
        type="float"
        id="valor"
        placeholder="R$"
        value={despesa.valor}
        onChange={tratarEstado}
        />
        <Form.Control.Feedback type="invalid">Por favor, digite o valor da despesa !!!</Form.Control.Feedback>
        </Form.Group>

        </Col>

        <Col>
        <Form.Group className="mb-3" >
        <Form.Label>Data de Vencimento</Form.Label>
        <Form.Control
        type="date"
        id="dataVencimento"
        value={despesa.dataVencimento}
        onChange={tratarEstado}
        />
        </Form.Group>
    
        <Form.Group className="mb-3" >
        <Form.Label>Data de Pagamento</Form.Label>
                <Form.Control
                type="date"
                id="dataPagamento"
                value={despesa.dataPagamento}
                onChange={tratarEstado}
                />
        </Form.Group>

        <Form.Group className="mb-3">
        <Form.Label>Selecione a forma de pagamento</Form.Label>
        <Form.Select 
         value={despesa.formaPagamento}
         onChange={tratarEstado}
         id='formaPagamento' 
         required > 
           <option value="dinheiro">Dinheiro</option>
           <option value="pix">PIX</option>
           <option value="cartao">Cartão</option>
           <option value="outro">Outra Forma de Pagamento</option>
            </Form.Select>
            <Form.Control.Feedback type="invalid">Por favor, selecione a forma de pagamento !!!</Form.Control.Feedback>
            </Form.Group>

   </Col>


<Col style={{borderLeft: '1px solid silver' }}>
    <Form.Group className="mb-3">
   <Form.Label>Vincular Animal</Form.Label>
        <Form.Select 
         value={despesa.vinculaAnimal}
         id='vinculaAnimal' 
         onChange={tratarEstado}
         required > 
           <option value = "sim">Sim</option>
           <option value = "não">Não</option>
         </Form.Select>
    </Form.Group >
   
    <Form.Group className="mb-3">
    <Form.Label>Código do Animal</Form.Label>
            <Form.Control
            type="number"
            value={despesa.codigo_animal = animalSelecionado.codigo_animal}
            disabled
            />
   </Form.Group >

   <Form.Group className="mb-3">
   <Form.Label>Nome do Animal</Form.Label>
        <CaixaDeSelecao url= "http://localhost:5000/animais"
                                campoExibicao="nome_animal"
                                funcaoSelecao={setAnimalSelecionado}
                                campoChave="codigo_animal"                                 
                                />
    </Form.Group >

    <Form.Group className="mb-3">
    <Form.Label>Observações</Form.Label>
        <Form.Control as="textarea" rows={3}
        id="observacoes" 
        placeholder="Observações a respeito do animal selecionado"
        value={despesa.observacoes}
        disabled={vincular(despesa.vinculaAnimal)}
        onChange={tratarEstado}
        
        
        />
    </Form.Group >
   </Col>
  
   </Row>

<Row>
        <Col>
        <Button variant="success" type="submit">{propriedades.modoEdicao ? "Atualizar" : "Cadastrar"}</Button>
        </Col>
        <Col>
        <Button variant="dark" onClick={()=>{
            propriedades.exibirTabela(true);
            }}>Voltar</Button>
        </Col>
</Row>
    
 </Form>


    )
}