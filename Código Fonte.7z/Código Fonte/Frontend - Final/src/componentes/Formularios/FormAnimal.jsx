import { useState,useRef, useEffect } from "react";
import { Button, Form, Row, Col} from "react-bootstrap";
import { urlAnimais, urlBackend } from "../../utilitarios/URL/Url";
import { ApenasLetras } from "./validadores";
import CaixaDeSelecao from "../CaixaSelecao/CaixaDeSelecao";
import { Link } from "react-router-dom";

export default function FormAnimal(props) {
    const [validado, setValidado] = useState(false);
    const [animal, setAnimal] = useState(props.animal);
    const [raca, setRaca] = useState({})
    
    const [racaSelecionada,setRacaSelecionada] = useState(animal.raca_animal)
    const race = useRef({})
    
    


    //manipula o evento onChange
    function manipulaMudanca(e){
        const elemForm = e.currentTarget; //captura o elemento que disparou a mudança
        const id = elemForm.id; //extrair o identificador
        const valor = elemForm.value; //extrair o valor que está armazenando
        setAnimal({...animal,[id]:valor}); //pega todos os atributos, exceto o id informado, alterando este id para o novo valor
    }

    function manipulaSubmissao(evento) {
        const form = evento.currentTarget;
        if (form.checkValidity()) {
            // dados válidos
            //proceder o cadastro
            //let animais = props.listaAnimal;
            //animais.push(animal);
            //props.setAnimal(animais);
            if (props.modoEdicao){
                //requisição do tipo PUT para o backend atualizar os dados de um animal
                fetch(urlAnimais+'/animais',{
                    method:"PUT",
                    headers:{
                        "Content-type":"application/json"
                    }, 
                    body:JSON.stringify(animal)
                })
                .then((resposta)=>{
                    window.alert("Animal atualizado com sucesso!");
                    window.location.reload();
                    return resposta.json();
                    
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição: "+erro.message);
                })
            }
            else{//significa que está aberto em modo de cadastro
                fetch(urlAnimais+"/animais",{
                    method:"POST",
                    headers:{
                        "Content-type":"application/json" 
                    },
                    body:JSON.stringify(animal)
                })
                .then((resposta)=>{
                    return resposta.json();
                })
                .then((dados)=>{
                    if (dados.status){
                        props.setModoEdicao(false);
                        /*let novaLista = props.listaAnimal;
                        novaLista.push(animal);
                        props.setAnimal(novaLista);
                        //voltando a exibir a tabela
                        props.exibirTabela(true);*/
                        window.location.reload();
                    }
                    window.alert(dados.mensagem);
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição: "+erro.message);
                })
            }
            
            setValidado(false);
        }
        else {
            setValidado(true);
        }
        evento.preventDefault();
        evento.stopPropagation();
    }

    return (
        <>
        <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/ajudaanimais">
                    <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                </Link>
            </div>
            <Form noValidate validated={validado} onSubmit={manipulaSubmissao}>
                <Row>
                    <Col className="col-md-2">
                        <Form.Group className="mb-3" controlId="codigo_animal">
                            <Form.Label>Código:</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="" 
                                value={animal.codigo_animal} 
                                id="codigo_animal"
                                //onChange={manipulaMudanca}
                                disabled
                                required />
                        </Form.Group>
                        


                    </Col>
                    <Col className="col-md-10">
                        <Form.Group className="mb-3" controlId="nome_animal">
                            <Form.Label>Nome:</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Digite o Nome do Animal" 
                                value={animal.nome_animal} 
                                id="nome_animal"
                                onChange={manipulaMudanca}
                                onKeyPress={(evento) => {
                                    ApenasLetras(evento);
                                  }}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe o Nome do Animal!
                        </Form.Control.Feedback>
                    </Col>
                </Row>
             
                <Row>
                    

                    <Col className="col-md-3">
                        <Form.Group className="mb-3" controlId="porte_animal">
                            <Form.Label>Porte:</Form.Label>
                            <Form.Select 
                                aria-label="Default select example"
                                value={animal.porte_animal}
                                id="porte_animal"
                                onChange={manipulaMudanca}>
                                <option value="Selecione">Selecione</option>
                                <option value="Pequeno" selected>Pequeno</option>
                                <option value="Médio">Médio</option>
                                <option value="Grande">Grande</option>
                            </Form.Select>
                        </Form.Group>
                    </Col>
                    <Col className="col-md-3">
                        <Form.Group className="mb-3" controlId="cor_animal">
                            <Form.Label>Cor:</Form.Label>
                            <Form.Select 
                                aria-label="Default select example"
                                value={animal.cor_animal}
                                id="cor_animal"
                                onChange={manipulaMudanca}>
                                <option value="Selecione">Selecione</option>
                                <option value="Branco" selected>Branco</option>
                                <option value="Caramelo">Caramelo</option>
                                <option value="Cinza">Cinza</option>
                                <option value="Malhado">Malhado</option>
                                <option value="Marrom">Marrom</option>
                                <option value="Preto">Preto</option>
                            </Form.Select>
                        </Form.Group>
                    </Col>
                    <Col className="col-md-3">
                        <Form.Group className="mb-3" controlId="idade_animal">
                            <Form.Label>Idade:</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Digite a Idade do Animal" 
                                value={animal.idade_animal}
                                id="idade_animal"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Idade do Animal!
                        </Form.Control.Feedback>
                    </Col>

                    <Col className="col-md-3">
                    <Form.Group className="mb-3" controlId="raca_animal">
                    <Form.Label>Raça:</Form.Label>
                    <CaixaDeSelecao url={urlBackend + '/racas'} 
                            campoChave={"codigo"}
                            campoExibicao={"descricao"}
                            funcaoSelecao={setRaca}
                            value={animal.raca_animal = raca.descricao}
                            onChange={(e)=>{
                            setRaca(e.currentTarget.value)
                            setRacaSelecionada(animal.raca_animal)
                          //  setRacaSelecionada(e.currentTarget.value)
                       
                            }}/>
                          
                    </Form.Group>     
                    </Col>
                    
                    
                    
                  
                </Row>
                <Row>
                    <Col className="col-md-3">
                        <Form.Group className="mb-3" controlId="temperamento_animal">
                            <Form.Label>Temperamento:</Form.Label>
                            <Form.Select 
                                aria-label="Default select example"
                                value={animal.temperamento_animal}
                                id="temperamento_animal"
                                onChange={manipulaMudanca}>
                                <option value="Selecione">Selecione</option>
                                <option value="Agressivo" selected>Agressivo</option>
                                <option value="Independente">Independente</option>
                                <option value="Passivo-Agressivo">Passivo-Agressivo</option>
                                <option value="Sociável">Sociável</option>
                                <option value="Tímido">Tímido</option>
                            </Form.Select>
                        </Form.Group>
                    </Col>
                    <Col className="col-md-3">
                        <Form.Group className="mb-3" controlId="dataentrada_animal">
                            <Form.Label>Data de Entrada:</Form.Label>
                            <Form.Control 
                                type="date" 
                                placeholder="" 
                                value={animal.dataentrada_animal}
                                id="dataentrada_animal"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Data de Entrada do Animal!
                        </Form.Control.Feedback>
                    </Col>
                    <Col className="col-md-6">
                        <Form.Group className="mb-3" controlId="vacinacao_animal">
                            <Form.Label>Vacinação:</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="" 
                                value={animal.vacinacao_animal}
                                id="vacinacao_animal"
                                onChange={manipulaMudanca}
                                onKeyPress={(evento) => {
                                    ApenasLetras(evento);
                                  }}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Vacinação do Animal!
                        </Form.Control.Feedback>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-md-6">
                        <Form.Group className="mb-3" controlId="localencontrado_animal">
                            <Form.Label>Local Encontrado:</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="" 
                                value={animal.localencontrado_animal}
                                id="localencontrado_animal"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe o Local em que o Animal foi encontrado!
                        </Form.Control.Feedback>
                    </Col>
                    <Col className="col-md-6">
                        <Form.Group className="mb-3" controlId="localizacao_animal">
                            <Form.Label>Localização Atual:</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="" 
                                value={animal.localizacao_animal}
                                id="localizacao_animal"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Localização Atual do Animal!
                        </Form.Control.Feedback>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-md-6">
                        <Form.Group className="mb-3" controlId="necessidades_animal">
                            <Form.Label>Necessidades Especiais:</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="" 
                                value={animal.necessidades_animal}
                                id="necessidades_animal"
                                onChange={manipulaMudanca}
                                onKeyPress={(evento) => {
                                    ApenasLetras(evento);
                                  }}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe se o Animal possui Necessidades Especiais!
                        </Form.Control.Feedback>
                    </Col>
                    <Col className="col-md-3">
                        <Form.Group className="mb-3" controlId="disponibilidade_animal">
                            <Form.Label>Disponivel:</Form.Label>
                            <Form.Select 
                                aria-label="Default select example"
                                value={animal.disponibilidade_animal}
                                id="disponibilidade_animal"
                                onChange={manipulaMudanca}>
                                <option value="Selecione">Selecione</option>
                                <option value="Sim" selected>Sim</option>
                                <option value="Não">Não</option>
                           </Form.Select>
                        </Form.Group>
                    </Col>
                    <Col className="col-md-3,">
                        <Form.Group className="mb-3" controlId="dataadocao_animal">
                            <Form.Label>Data da Adoção:</Form.Label>
                            <Form.Control 
                                type="date" 
                                placeholder=""
                                value={animal.dataadocao_animal}
                                id="dataadocao_animal"
                                disabled
                                onChange={manipulaMudanca}/>
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Data de Entrada do Animal!
                        </Form.Control.Feedback>
                    </Col>
                </Row>

                <Row className="text-center">
                    <Col>
                        <Button type="submit" variant="success">
                        {props.modoEdicao ? 'Atualizar' : 'Salvar'}
                            </Button>
                    </Col>
                    <Col>
                        <Button type="button" variant="secondary" onClick={()=>{
                            props.exibirTabela(true);
                        }}>Voltar</Button>
                    </Col>
                </Row>
            </Form>

            
        </>
    );
  
}