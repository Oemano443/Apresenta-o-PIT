import { useState } from "react";
import { Button, Form, Row, Col, FormGroup, FormLabel, FormControl } from "react-bootstrap";
import { urlAnimais } from "../../utilitarios/URL/Url";
import { ApenasLetras } from "./validadores";
import CaixaDeSelecao from "../CaixaSelecao/CaixaDeSelecao";
import { LinkContainer } from "react-router-bootstrap";


export default function FormDoacao(props) {
    /*const [adocao, setAdocao] = useState(props.adocao || {});*/
    const [colaboradorSelecionado, setColaboradorSelecionado] = useState({});
    const [itemSelecionado, setItemSelecionado] = useState({});
    //const [doacao, setDoacao] = useState(props.doacao || {});
    const [doacao, setDoacao] = useState(props.doacao)


    /* const [adocao, setAdocao] = useState({
            cod_adocao: 0,
            data_adocao: "",
            animal: animalSelecionado,
            colaborador: colaboradorSelecionado
        }) */


    const [validado, setValidado] = useState(false);


    //manipula o evento onChange
    function manipulaMudanca(e) {
        const elemForm = e.currentTarget; //captura o elemento que disparou a mudança
        const id = elemForm.id; //extrair o identificador
        const valor = elemForm.value; //extrair o valor que está armazenando
        setDoacao({ ...doacao, [id]: valor }); //pega todos os atributos, exceto o id informado, alterando este id para o novo valor

    }

    function manipulaSubmissao(evento) {
        const form = evento.currentTarget;
        if (form.checkValidity()) {
            // dados válidos
            //proceder o cadastro

            if (props.modoEdicao) {
                //requisição do tipo PUT para o backend
                fetch(urlAnimais + '/doacoes', {
                    method: "PUT",
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(doacao)
                })
                    .then((resposta) => {
                        window.alert("Doação atualizada com sucesso!");
                        window.location.reload();
                        return resposta.json();

                    })
                    .catch((erro) => {
                        window.alert("Erro ao executar a requisição: " + erro.message);
                    })
            }
            else {//significa que está aberto em modo de cadastro
                fetch(urlAnimais + '/doacoes', {
                    method: "POST",
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(doacao)
                })
                    .then((resposta) => {
                        return resposta.json();
                    })
                    .then((dados) => {
                        if (dados.status) {
                            window.location.reload()
                            //props.setModoEdicao(false);

                            // window.location.reload();
                        }
                        window.alert(dados.mensagem);
                    })
                    .catch((erro) => {
                        window.alert("Erro ao executar a requisição: " + erro.message);
                    })
            }

            setValidado(false);
        }
        else {
            setValidado(true);
        }
        evento.preventDefault();
        evento.stopPropagation();
    }

    return (
        <>

            <Form noValidate validated={validado} onSubmit={manipulaSubmissao}>
                <div style={{ position: 'absolute', top: 10, right: 10 }}>
                    <LinkContainer to='/ajudadoacoes'>
                        <Button variant="light" style={{ color: 'black' }}>
                            Ajuda
                        </Button>
                    </LinkContainer>
                </div>
                <Row>
                    <Col className="col-md-2">
                        <Form.Group className="mb-3" controlId="codDoacao">
                            <Form.Label>Código:</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder=""
                                value={doacao.codDoacao}
                                id="codDoacao"
                                //onChange={manipulaMudanca}
                                disabled
                                required />
                        </Form.Group>
                    </Col>
                </Row>

                <Row>
                    <Col className="col-md-2">
                        <Form.Group className="mb-3" controlId="data">
                            <Form.Label>Data da Doação:</Form.Label>
                            <Form.Control
                                type="date"
                                placeholder=""
                                value={doacao.data}
                                id="data"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Data da Doação
                        </Form.Control.Feedback>
                    </Col>

                </Row>

                <Row>
                    <Col className="col-md-2">
                        <FormGroup className="mb-3" controlId="codDoador" >
                            <Form.Label>Código do Doador:</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder=""
                                value={doacao.codDoador = colaboradorSelecionado.codColaborador}
                                id="codDoador"
                                required
                                disabled />
                        </FormGroup>
                    </Col>

                    <Col className="col-md-10">
                        <FormGroup>
                            <FormLabel>Selecione um Doador:</FormLabel>
                            <CaixaDeSelecao url="http://localhost:5000/colaboradores"
                                campoExibicao="nome"
                                funcaoSelecao={setColaboradorSelecionado}
                                campoChave={"codColaborador"}
                                value={doacao.nomeDoador = colaboradorSelecionado.nome}

                            />
                        </FormGroup>
                    </Col>
                </Row>

                <Row>
                    <Col className="col-md-2">
                        <FormGroup className="mb-3" controlId="codItem">
                            <Form.Label>Código do Tipo de Item:</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder=""
                                value={doacao.codItem = itemSelecionado.codigo}
                                id="codItem"
                                required
                                disabled />
                        </FormGroup>
                    </Col>

                    <Col className="col-md-10">
                        <FormGroup>
                            <FormLabel>Selecione um Tipo de Item:</FormLabel>
                            <CaixaDeSelecao url="http://localhost:5000/itensdoacao"
                                campoExibicao="descricao"
                                funcaoSelecao={setItemSelecionado}
                                campoChave="codigo"
                                value={doacao.descItem = itemSelecionado.descricao}

                            />
                        </FormGroup>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-md-2">
                        <FormGroup className="mb-3" controlId="qtd">
                            <FormLabel>Quantidade/Valor:</FormLabel>
                            <FormControl
                                type="text"
                                placeholder=""
                                value={doacao.qtd}
                                id="qtd"
                                onChange={manipulaMudanca}
                            />
                        </FormGroup>
                    </Col>
                    <Col className="col-md-9">
                        <FormGroup className="mb-3" controlId="observacoes">
                            <FormLabel>Observação:</FormLabel>
                            <FormControl
                                type="text"
                                placeholder=""
                                value={doacao.observacoes}
                                id="observacoes"
                                onChange={manipulaMudanca}
                            />
                        </FormGroup>
                    </Col>

                </Row>

                <Row className="text-center">
                    <Col>
                        <Button type="submit" variant="success">
                            {props.modoEdicao ? 'Atualizar' : 'Salvar'}</Button>
                    </Col>
                    <Col>
                        <Button type="button" variant="secondary" onClick={() => {
                            props.exibirTabela(true);
                        }}>Voltar</Button>
                    </Col>
                    {/*<Col className="col-md-3">
                        <LinkContainer to='/helpdoacao'><Button variant='dark'>Ajuda</Button></LinkContainer>

                    </Col>*/}
                </Row>
                <br />

            </Form>
        </>
    );
}