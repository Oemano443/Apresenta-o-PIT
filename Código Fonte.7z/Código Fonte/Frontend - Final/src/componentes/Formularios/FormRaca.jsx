import { useState } from "react";
import {Button, Form, Row, Col, Container} from "react-bootstrap"
import { urlRaca } from "../../utilitarios/URL/Url";
import { Link } from "react-router-dom";

export default function FormRaca(props){
    const [validado, setValidado] = useState(false);
    const [raca, setRaca] = useState(props.raca);

    function manipulaMudanca(e){
        const elemForm = e.currentTarget;
        const id = elemForm.id;
        const valor = elemForm.value;
        setRaca({...raca,[id]:valor});
    }

    function manipulaSubmissao(evento){
        const form = evento.currentTarget;
        if (form.checkValidity()) {
            if (props.modoEdicao){
                fetch(urlRaca +'/racas',{
                    method:'PUT',
                    headers: {"Content-type":"application/json"},
                    body: JSON.stringify(raca)
                })
                .then((resposta)=>{
                    window.alert("Raça atualizada com sucesso!");
                    window.location.reload();
                    return resposta.json();
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição: "+erro.message);
                })
            }
            else{
                fetch (urlRaca+"/racas",{
                    method:"POST",
                    headers:{"Content-type":"application/json"},
                    body: JSON.stringify(raca)
                })
                .then((resposta)=>{
                    return resposta.json();
                })
                .then((dados)=>{
                    if (dados.status){
                        props.setModoEdicao(false);
                        window.location.reload();
                    }
                    window.alert(dados.mensagem);
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição"+erro.message);
                })
            }
            setValidado(false);
        }
        else {
            setValidado(true);
        }
        evento.preventDefault();
        evento.stopPropagation();
    }

    return (
        <>
            <Form noValidate validated={validado} on onSubmit={manipulaSubmissao}>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                    <Link to="/ajudaracas">
                        <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                    </Link>
                </div>

                <Row>
                    <Col className="col-md-3 offset-md-3">
                        <Form.Group className="mb-3" controlId="codigo_raca">
                            <Form.Label>Código:</Form.Label>
                            <Form.Control 
                                type="text"
                                placeholder=""
                                value={raca.codigo}
                                id="codigo"
                                disabled
                                required/>
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-md-6 offset-md-3">
                        <Form.Group className="mb-3" controlId="nome_raca">
                            <Form.Label>Raça:</Form.Label>
                            <Form.Control 
                                type="text"
                                placeholder="Digite a Raça"
                                value={raca.descricao}
                                id="descricao"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Raça!
                        </Form.Control.Feedback>
                    </Col>
                </Row>
                <Row className="text-center">
                    <Col className="col-md-3 offset-md-3">
                        <Button type="submit" variant="success">{props.modoEdicao ? 'Atualizar' : 'Salvar'}</Button>
                    </Col>
                    <Col className="col-md-3">
                        <Button type="button" variant="secondary" onClick={()=>{
                            props.exibirTabela(true);
                        }}>Voltar</Button>
                    </Col>
                </Row>
            </Form>

        </>
    );

}