import { useState } from "react";
import { Button, Form, Row, Col, FormGroup, FormLabel, FormControl } from "react-bootstrap";
import { urlAnimais } from "../../utilitarios/URL/Url";
import { ApenasLetras } from "./validadores";
import CaixaDeSelecao from "../CaixaSelecao/CaixaDeSelecao";
import { Link } from "react-router-dom";


export default function FormAdocao(props) {
    /*const [adocao, setAdocao] = useState(props.adocao || {});*/
    const [colaboradorSelecionado, setColaboradorSelecionado] = useState({});
    const [animalSelecionado, setAnimalSelecionado] = useState({});
    const [adocao, setAdocao] = useState(props.adocao)
    


/* const [adocao, setAdocao] = useState({
        cod_adocao: 0,
        data_adocao: "",
        animal: animalSelecionado,
        colaborador: colaboradorSelecionado
    }) */


    const [validado, setValidado] = useState(false);



    //manipula o evento onChange
    function manipulaMudanca(e) {
        const elemForm = e.currentTarget; //captura o elemento que disparou a mudança
        const id = elemForm.id; //extrair o identificador
        const valor = elemForm.value; //extrair o valor que está armazenando
        setAdocao({ ...adocao ,[id]: valor }); //pega todos os atributos, exceto o id informado, alterando este id para o novo valor
        
    }
    
    function manipulaSubmissao(evento) {
        const form = evento.currentTarget;
        if (form.checkValidity()) {
            // dados válidos
            //proceder o cadastro

            if (props.modoEdicao) {
                //requisição do tipo PUT para o backend
                fetch(urlAnimais + '/adocoes', {
                    method: "PUT",
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(adocao)
                })
                    .then((resposta) => {
                        window.alert("Adoção atualizada com sucesso!");
                        window.location.reload();
                        return resposta.json();

                    })
                    .catch((erro) => {
                        window.alert("Erro ao executar a requisição: " + erro.message);
                    })
            }
            else {//significa que está aberto em modo de cadastro
                fetch(urlAnimais + "/adocoes", {
                    method: "POST",
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(adocao)
                })
                    .then((resposta) => {
                        return resposta.json();
                    })
                    .then((dados) => {
                        if (dados.status) {
                            window.location.reload()
                            //props.setModoEdicao(false);

                           // window.location.reload();
                        }
                        window.alert(dados.mensagem);
                    })
                    .catch((erro) => {
                        window.alert("Erro ao executar a requisição: " + erro.message);
                    })
            }

            setValidado(false);
        }
        else {
            setValidado(true);
        }
        evento.preventDefault();
        evento.stopPropagation();
    }
 
    return (
        <>

        
        

            <Form noValidate validated={validado} onSubmit={manipulaSubmissao}>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/ajudaadocoes">
                    <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                </Link>
            </div>
                <Row>
                    <Col className="col-md-2">
                        <Form.Group className="mb-3" controlId="codigo">
                            <Form.Label>Código:</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder=""
                                value={adocao.codigo}
                                id="codigo"
                                //onChange={manipulaMudanca}
                                disabled
                                required />
                        </Form.Group>
                    </Col>
                </Row>

                <Row>
                    <Col className="col-md-2">
                        <Form.Group className="mb-3" controlId="data">
                            <Form.Label>Data da Adoção:</Form.Label>
                            <Form.Control
                                type="date"
                                placeholder=""
                                value={adocao.data}
                                id="data"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Data da Adoção
                        </Form.Control.Feedback>
                    </Col>

                </Row>

                <Row>
                    <Col className="col-md-2">
                        <FormGroup className="mb-3" controlId="codAdotante" >
                            <Form.Label>Código do Adotante:</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder=""
                                value={adocao.codAdotante = colaboradorSelecionado.codColaborador}
                                id="codAdotante"
                                required
                                disabled />
                        </FormGroup>
                    </Col>
                    
                    <Col className="col-md-10">
                        <FormGroup>
                            <FormLabel>Selecione um Adotante:</FormLabel>
                            <CaixaDeSelecao url="http://localhost:5000/colaboradores"
                                campoChave={"codColaborador"}
                                campoExibicao="nome"
                                funcaoSelecao={setColaboradorSelecionado}
                                value= {adocao.nomeAdotante = colaboradorSelecionado.nome}
                            />
                        </FormGroup>
                    </Col>
                </Row>

                <Row>
                    <Col className="col-md-2">
                        <FormGroup className="mb-3" controlId="codigo_animal">
                            <Form.Label>Código do Animal:</Form.Label>
                            <Form.Control
                                type="number"
                                placeholder=""
                                value={adocao.codAnimal = animalSelecionado.codigo_animal}
                                id="codAnimal"
                                required
                                disabled />
                        </FormGroup>
                    </Col>
                    <Col className="col-md-10">
                        <FormGroup>
                            <FormLabel>Selecione um Animal:</FormLabel>
                            <CaixaDeSelecao url="http://localhost:5000/animais"
                                campoExibicao="nome_animal"
                                funcaoSelecao={setAnimalSelecionado}
                                campoChave="codigo_animal" 
                                value = {adocao.nomeAnimal = animalSelecionado.nome_animal}
                                />
                        </FormGroup>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-md-11">
                        <FormGroup className="mb-3" controlId="observacoes">
                            <FormLabel>Observação:</FormLabel>
                            <FormControl
                                type="text"
                                placeholder=""
                                value={adocao.observacoes}
                                id="observacoes" 
                                onChange={manipulaMudanca}
                                />
                        </FormGroup>
                    </Col>
                    
                </Row>

                <Row className="text-center">
                    <Col>
                        <Button type="submit" variant="success">
                            {props.modoEdicao ? 'Atualizar' : 'Salvar'}</Button>
                    </Col>
                    <Col>
                        <Button type="button" variant="secondary" onClick={() => {
                            props.exibirTabela(true);
                        }}>Voltar</Button>
                    </Col>
                </Row>
                
            </Form>
        </>
    );
}