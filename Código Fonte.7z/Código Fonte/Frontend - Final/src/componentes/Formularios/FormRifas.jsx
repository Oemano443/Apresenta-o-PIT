import { useState, useEffect } from 'react';
import { Button, Form, Row, Col } from 'react-bootstrap';
import { urlBase } from '../../utilitarios/URL/Url';
import { Link } from 'react-router-dom';

export default function FormRifas(props) {
    const [validado, setValidado] = useState(false);
    const [rifa, setRifa] = useState(props.rifa);

    useEffect(() => {
        if (!props.modoEdicao) {
            // Gera um número aleatório para o valor inicial do "codigo"
            const codigo = gerarCodigoDisponivel();
            setRifa({ ...rifa, codigo });
        }
    }, []);

    function manipulaMudanca(e) {
        const elemForm = e.currentTarget;
        const id = elemForm.id;
        const valor = elemForm.value;
        setRifa({ ...rifa, [id]: valor });
    }

    function manipulaSubmissao(e) {
        e.preventDefault();
        const form = e.currentTarget;

        if (form.checkValidity()) {
            if (validarCampos()) {
                if (props.modoEdicao) {
                    // Código para atualizar a rifa
                    fetch(urlBase + "/rifa", {
                        method: "PUT",
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(rifa)
                    })
                        .then((resposta) => resposta.json())
                        .then((dados) => {
                            if (dados.status) {
                                const listaAtualizada = props.listaRifas.map((item) => {
                                    if (item.codigo === rifa.codigo) {
                                        return rifa;
                                    } else {
                                        return item;
                                    }
                                });
                                props.setRifas(listaAtualizada);
                                props.exibirTabela(true);
                                if (typeof props.setModoEdicao === 'function') {
                                    props.setModoEdicao(false);
                                }
                                window.alert("Rifa atualizada com sucesso!");
                            } else {
                                window.alert(dados.mensagem);
                            }
                        })
                        .catch((erro) => {
                            window.alert("Erro ao executar a requisição: " + erro.message);
                        });
                } else {
                    // Gera um valor único para o "codigo" antes de enviar o formulário
                    const codigo = gerarCodigoDisponivel();
                    if (codigo) {
                        setRifa({ ...rifa, codigo });
                        fetch(urlBase + "/rifa", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(rifa)
                        })
                            .then((resposta) => resposta.json())
                            .then((dados) => {
                                if (dados.status) {
                                    let novaLista = [...props.listaRifas, rifa];
                                    props.setRifas(novaLista);
                                    props.exibirTabela(true);
                                    window.alert(dados.mensagem);
                                }
                            })
                            .catch((erro) => {
                                window.alert("Erro ao executar a requisição: " + erro.message);
                            });
                    } else {
                        window.alert("Não foi possível gerar um código único.");
                    }
                }

                setValidado(false);
            }
        } else {
            setValidado(true);
        }
    }

    function gerarCodigoDisponivel() {
        const codigosExistentes = props.listaRifas.map((item) => item.codigo);
        let codigo = Math.max(...codigosExistentes) + 1;

        return codigo;
    }


    function manipulaExclusao() {
        if (window.confirm("Deseja realmente excluir esta rifa?")) {
            fetch(urlBase + "/rifa", {
                method: "DELETE"
            })
                .then((resposta) => resposta.json())
                .then((dados) => {
                    if (dados.status) {
                        const listaAtualizada = props.listaRifas.filter((item) => item.codigo !== rifa.codigo);
                        props.setRifas(listaAtualizada);
                        props.exibirTabela(true);
                        if (typeof props.setModoEdicao === 'function') {
                            props.setModoEdicao(false);
                        }
                        window.alert("Rifa excluída com sucesso!");
                    } else {
                        window.alert(dados.mensagem);
                    }
                })
                .catch((erro) => {
                    window.alert("Erro ao executar a requisição: " + erro.message);
                });
        }
    }

    function validarCampos() {
        const camposObrigatorios = ['descricao', 'premiacao', 'dataInic', 'dataSort'];
        let camposValidos = true;

        for (const campo of camposObrigatorios) {
            if (!rifa[campo]) {
                camposValidos = false;
                setValidado(true);
                break;
            }
        }

        return camposValidos;
    }


    return (
        <>
            <Form noValidate validated={validado} onSubmit={manipulaSubmissao}>
                <div style={{ position: 'absolute', top: 10, right: 10 }}>
                    <Link to="/ajudarifas">
                        <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                    </Link>
                </div>
                <Row>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Código:</Form.Label>
                            <Form.Control type="text" readOnly value="*" disabled />

                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Descrição:</Form.Label>
                            <Form.Control type="text" placeholder="Informe aqui a descrição da rifa" value={rifa.descricao} id='descricao' onChange={manipulaMudanca} required />
                            <Form.Control.Feedback type='invalid'>
                                Por favor, informe a descrição.
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Tipo:</Form.Label>
                            <Form.Select aria-label="Default select example" value={rifa.tipo} id='tipo' onChange={manipulaMudanca}>
                                <option value="Impressa">Impressa</option>
                                <option value="Automatica">Automatica</option>
                            </Form.Select>
                        </Form.Group>
                    </Col>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Premiação:</Form.Label>
                            <Form.Control type="text" placeholder="Informe qual é a premiação da rifa" value={rifa.premiacao} id='premiacao' onChange={manipulaMudanca} required />
                            <Form.Control.Feedback type='invalid'>
                                Por favor, informe a premiação.
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Data de Início:</Form.Label>
                            <Form.Control type="date" value={rifa.dataInic} id='dataInic' onChange={manipulaMudanca} required />
                            <Form.Control.Feedback type='invalid'>
                                Por favor, informe a data de início.
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Data do Sorteio:</Form.Label>
                            <Form.Control type="date" value={rifa.dataSort} id='dataSort' onChange={manipulaMudanca} required />
                            <Form.Control.Feedback type='invalid'>
                                Por favor, informe a data do sorteio.
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Button variant="success" type="submit">{props.modoEdicao ? 'Atualizar' : 'Salvar'}</Button>{' '}
                      <Button variant="secondary" onClick={() => props.exibirTabela(true)}>Voltar</Button>
                    </Col>
                </Row>
            </Form>
            
        </>
    );
}