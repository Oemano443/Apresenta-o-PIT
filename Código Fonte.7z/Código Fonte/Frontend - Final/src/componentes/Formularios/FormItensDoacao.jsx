





export default function FormItensDoacao(propriedades){

    return(
<Form validated={validado} onSubmit={submissao}>

<Row>
    <Col>
    <Form.Label>Código</Form.Label>
        <Form.Control
        type="number"
        id = "codigo"
        value={item.codigo}
        onChange={tratarEstado}
        disabled
        required
        />

    <Form.Label>Descrição</Form.Label>
        <Form.Control
        type="text"
        id = "descricao"
        value={item.descricao}
        onChange={tratarEstado}
        required
        />


    <Form.Label>Tipo</Form.Label>
    <Form.Select value={item.tipo} id='classificacao' onChange={tratarEstado} required>  
    <option value="valores">Valores | Dinheiro</option>
    <option value="demais" >Demais | Itens</option>
    </Form.Select>
    </Col>

</Row>

<Row className="text-center" >
    <Col >
      <Button type="submit" variant='success'>Cadastrar</Button>{' '}
      </Col>
      <Col>
      <Button type='button' variant='secondary' onClick={function(){
        propriedades.exibirTabela(true);
      }
      }>Voltar</Button>
    </Col>
  </Row>      

</Form>


    );

}