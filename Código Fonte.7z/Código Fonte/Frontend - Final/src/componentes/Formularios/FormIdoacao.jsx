import { useState } from "react";
import {Button, Form, Row, Col, Container} from "react-bootstrap"
import { urlBase } from "../../utilitarios/URL/Url";
import { Link } from "react-router-dom";

export default function FormIdoacao(props){
    const [validado, setValidado] = useState(false);
    const [idoacao, setIdoacao] = useState(props.idoacao);

    function manipulaMudanca(e){
        const elemForm = e.currentTarget;
        const id = elemForm.id;
        const valor = elemForm.value;
        setIdoacao({...idoacao,[id]:valor});
    }

    function manipulaSubmissao(evento){
        const form = evento.currentTarget;
        if (form.checkValidity()) {
            if (props.modoEdicao){
                fetch(urlBase+'/itensdoacao',{
                    method:'PUT',
                    headers: {"Content-type":"application/json"},
                    body: JSON.stringify(idoacao)
                })
                .then((resposta)=>{
                    window.alert("Item para doação atualizado com sucesso!");
                    window.location.reload();
                    return resposta.json();
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição: "+erro.message);
                })
            }
            else{
                fetch (urlBase+"/itensdoacao",{
                    method:"POST",
                    headers:{"Content-type":"application/json"},
                    body: JSON.stringify(idoacao)
                })
                .then((resposta)=>{
                    return resposta.json();
                })
                .then((dados)=>{
                    if (dados.status){
                        props.setModoEdicao(false);
                        window.location.reload();
                    }
                    window.alert(dados.mensagem);
                })
                .catch((erro)=>{
                    window.alert("Erro ao executar a requisição"+erro.message);
                })
            }
            setValidado(false);
        }
        else {
            setValidado(true);
        }
        evento.preventDefault();
        evento.stopPropagation();
    }

    return (
        <>
            <Form noValidate validated={validado} on onSubmit={manipulaSubmissao}>
                <div style={{ position: 'absolute', top: 10, right: 10 }}>
                    <Link to="/ajuda2">
                        <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                    </Link>
                </div>
                <Row>
                    <Col className="col-md-3 offset-md-3">
                        <Form.Group className="mb-3" controlId="codigo">
                            <Form.Label>Código:</Form.Label>
                            <Form.Control 
                                type="text"
                                placeholder=""
                                value={idoacao.codigo}
                                id="codigo"
                                disabled
                                required/>
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-md-6 offset-md-3">
                        <Form.Group className="mb-3" controlId="descricao">
                            <Form.Label>Descrição:</Form.Label>
                            <Form.Control 
                                type="text"
                                placeholder="Digite a Descrição do Item"
                                value={idoacao.descricao}
                                id="descricao"
                                onChange={manipulaMudanca}
                                required />
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Descrição do Item para Doação!
                        </Form.Control.Feedback>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-md-6 offset-md-3">
                        <Form.Group className="mb-3" controlId="tipo">
                            <Form.Label>Tipo:</Form.Label>
                            <Form.Select 
                                aria-label="Default select example"
                                value={idoacao.tipo}
                                id="tipo"
                                onChange={manipulaMudanca}>
                                <option value="Selecione">Selecione</option>
                                <option value="Valores">Valores</option>
                                <option value="Demais">Demais</option>
                            </Form.Select>
                        </Form.Group>
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a Descrição do Item para Doação!
                        </Form.Control.Feedback>
                    </Col>
                </Row>
                <Row className="text-center">
                    <Col className="col-md-3 offset-md-3">
                        <Button type="submit" variant="success">Confirmar</Button>
                    </Col>
                    <Col className="col-md-3">
                        <Button type="button" variant="secondary" onClick={()=>{
                            props.exibirTabela(true);
                        }}>Voltar</Button>
                    </Col>
                </Row>
            </Form>

        </>
    );

}