import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import { IMaskInput } from 'react-imask'; // biblioteca utilizada para aplicação de máscaras em alguns inputs
import { urlBackend } from '../../utilitarios/URL/Url';
import { Link } from 'react-router-dom';

// Validação dos inputs
import Testacpf from './validadores'; // validar CPF
import { ApenasLetras } from './validadores'; // permitir apenas letras


export default function FormularioColaboradores(propriedades){
    const [validado, setValidado] = useState(false);
    const [colaborador, setColaborador] = useState(propriedades.colaborador); // estrutura ao implementar: colaborador.nomequedeseja

     function tratarEstado(evento){
      const elementoFormulario = evento.currentTarget; // o currentTarget está fazendo referência ao item que está executando o evento
      const id = elementoFormulario.id; // o ".id" é usado para referênciar o id do item que está executando o evento
      const valor = elementoFormulario.value; // o "value" pega o valor do item que está executando o evento
      setColaborador({...colaborador, [id]:valor}); // os ids precisam estar iguais aos atributos do backend fazendo referência ao colaborador, id que é o nome do atributo e o valor ex: colaborador[codColaborador]:xxx

    };


// submissão do formulário
function submissao(evento) {
  const form = evento.currentTarget;
        if (form.checkValidity()) {
           
            if (!propriedades.modoEdicao){

            if(!Testacpf(colaborador.cpf)){ // testa se o cpf do colaborador é válido
              window.alert(`${colaborador.cpf} é inválido`)
              evento.preventDefault()
              evento.stopPropagation()
              return
            }
                             
              fetch(urlBackend + '/colaboradores',{
                method:"POST",
                headers:{"Content-Type":'application/json'},
                body: JSON.stringify(colaborador)
              
              }).then((resposta)=>{
                return resposta.json();
              }).then((dados)=>{
                
               window.alert(dados.mensagem)  
              let listaNova = propriedades.listaColaboradores;              
               listaNova.push(colaborador)
               propriedades.setColaboradores(listaNova)
              // propriedades.listaColaboradores = [];
               propriedades.exibirTabela(true);
          
              }).catch((erro)=>{
                window.alert("Erro " + erro.message);
              })

           } else {
            fetch(urlBackend + '/colaboradores',{
              method: "PUT",
              headers:{"Content-Type":'application/json'},
              body: JSON.stringify(colaborador)            
            }).then((resposta)=>{
                return resposta.json();
                
           })         
           window.alert('Dados atualizados com sucesso !!!');
            }

          
          let colaboradores = propriedades.listaColaboradores;
            colaboradores.push(colaborador);
            propriedades.setColaboradores(colaboradores);
            propriedades.listaColaboradores = [] // limpar tabela para evitar dados de versões anteriores
            propriedades.exibirTabela(true);            
            setValidado(true);                                         
            
          }
       else {
            setValidado(true);
        }

        evento.preventDefault();
        evento.stopPropagation();
  };


  return(
     <>      
      <Form noValidate validated={validado} onSubmit={submissao}>
      <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/ajudacolaboradores">
                    <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                </Link>
            </div>
        <Row>
          <Col>
          <Form.Group className="mb-2">
            <Form.Label>Código</Form.Label>
            <Form.Control 
            type="number" 
            id='codColaborador'
            value={colaborador.codColaborador}  // verificar na linha 16 a estrutura para melhor entendimento.
            onChange={tratarEstado}
            disabled 
            required
            />
          <Form.Control.Feedback type='invalid' >
              Por favor, insira o código do colaborador !!!
          </Form.Control.Feedback>
          </Form.Group>
          </Col>

          <Col>
          <Form.Group className="mb-2">
            <Form.Label>CPF</Form.Label> 
            <IMaskInput className="form-control"
            mask='000.000.000-00'
            type='text'
            id='cpf'
            value={colaborador.cpf}
            onChange={tratarEstado}  
            disabled={propriedades.modoEdicao} // desabilitar campo cpf quando o código estiver com o modoEdicao true               
            required
            />                  
          <Form.Control.Feedback type='invalid' >
              Por favor, insira o CPF do colaborador !!!
          </Form.Control.Feedback>          
          </Form.Group>
          </Col>

          <Col>
          <Form.Label>Categoria do Colaborador</Form.Label>
         <Form.Select 
         value={colaborador.categoria}
         id='categoria' 
         onChange={tratarEstado}
         required > 
           <option value="voluntario">Voluntário</option>
           <option value="doador">Doador</option>
           <option value="adotante">Adotante</option>
            </Form.Select>
           </Col>
        </Row>  

        <Row>
        <Col>   
            <Form.Group className="mb-2">
            <Form.Label>Nome do Colaborador</Form.Label>
            <IMaskInput className="form-control"
            type="text"
            id='nome'
            value={colaborador.nome}    
            onChange={tratarEstado}   
            required
            onKeyPress={(evento) => {
              ApenasLetras(evento);
            }}
        />
          <Form.Control.Feedback type='invalid' >
              Por favor, insira o nome do colaborador !!!
          </Form.Control.Feedback>
          </Form.Group>
          </Col>
        </Row>

      <Row>
       <Col>
            <Form.Group className="mb-2">
            <Form.Label>Data de Nascimento</Form.Label>
            <Form.Control 
            type="date" 
            id='dataNasc'
            value={colaborador.dataNasc}
            onChange={tratarEstado}
            required/>
            <Form.Control.Feedback type='invalid' >
              Por favor, insira a data de nascimento do colaborador !!!
            </Form.Control.Feedback>
          </Form.Group>
       </Col>

       <Col>
       <Form.Group className="mb-2">
            <Form.Label>Telefone</Form.Label>
            <IMaskInput className="form-control"
              mask='(00) 00000-0000'
              type="text" 
              id='telefone'
              value={colaborador.telefone}
              onChange={tratarEstado}
              required
            />
            <Form.Control.Feedback type='invalid' >
              Por favor, insira o telefone do colaborador !!!
          </Form.Control.Feedback>
          </Form.Group>
          </Col>

          <Col>
       <Form.Group className="mb-2">
            <Form.Label>E-mail</Form.Label>
            <Form.Control 
            type="email"
            id='email'
            value={colaborador.email}
            onChange={tratarEstado}
            required/>
            <Form.Control.Feedback type='invalid' >
              Por favor, preencha o campo corretamente !!!
          </Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>

      <Row>
       <Col>
       <Form.Group className="mb-2">
            <Form.Label>CEP</Form.Label>
            <IMaskInput className="form-control"
              mask='00000-000'
              type="text" 
              id='cep'
              value={colaborador.cep}
              onChange={tratarEstado}
              required              
              />
            <Form.Control.Feedback type='invalid' >
              Por favor, insira o CEP !!!
          </Form.Control.Feedback>
          </Form.Group>
        </Col>

        <Col>
       <Form.Group className="mb-2">
            <Form.Label>Logradouro</Form.Label>
            <Form.Control 
            type="text" 
            id='logradouro'
            value={colaborador.logradouro}
            onChange={tratarEstado}
            required/>

            <Form.Control.Feedback type='invalid' >
              Por favor, insira o logradouro !!!
          </Form.Control.Feedback>
          </Form.Group>
        </Col>

        <Col>
       <Form.Group className="mb-2">
            <Form.Label>Número</Form.Label>
            <IMaskInput className="form-control"
            type="number"
            id='numero'
            value={colaborador.numero}
            onChange={tratarEstado}
            required/>

            <Form.Control.Feedback type='invalid' >
              Por favor, insira o número do logradouro !!!
          </Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>

    <Row>
    <Col>
       <Form.Group className="mb-2" >
            <Form.Label>Complemento</Form.Label>
            <Form.Control 
            type="text"
            id='complemento'
            value={colaborador.complemento}
            onChange={tratarEstado}
            required/>

            <Form.Control.Feedback type='invalid' >
              Por favor, insira um complemento para o logradouro !!!
          </Form.Control.Feedback>
          </Form.Group>
        </Col>

        <Col>
       <Form.Group className="mb-2" >
            <Form.Label>Bairro</Form.Label>
            <Form.Control
             type="text" 
             id='bairro'
             value={colaborador.bairro}
             onChange={tratarEstado}
             onKeyPress={(evento) => {
              ApenasLetras(evento);
            }}
             required/>

            <Form.Control.Feedback type='invalid' >
              Por favor, insira o bairro !!!
          </Form.Control.Feedback>
          </Form.Group>
        </Col>

        <Col>
       <Form.Group className="mb-2">
            <Form.Label>Cidade</Form.Label>
            <Form.Control 
            type="text" 
            id='cidade'
            value={colaborador.cidade}
            onChange={tratarEstado}
            onKeyPress={(evento) => {
              ApenasLetras(evento);
            }}
            required/>

            <Form.Control.Feedback type='invalid' >
              Por favor, insira a cidade !!!
          </Form.Control.Feedback>
          </Form.Group>
        </Col>

        <Col>
          <Form.Label>Estado</Form.Label>
          <Form.Select value={colaborador.uf} id='uf' onChange={tratarEstado}>
              <option value="CE">Ceará</option>
              <option value="DF">Distrito Federal</option>
              <option value="ES">Espírito Santo</option>
              <option value="GO">Goiás</option>
              <option value="MT">Mato Grosso</option>
              <option value="MS">Mato Grosso do Sul</option>
              <option value="MG">Minas Gerais</option>
              <option value="PR">Paraná</option>
              <option value="RJ">Rio de Janeiro</option>
              <option value="RS">Rio Grande do Sul</option>
              <option value="SC">Santa Catarina</option>
              <option value="SP">São Paulo</option>
              <option value="EX">Estrangeiro</option>
          </Form.Select>
          </Col>  
      </Row>      
        <br />
      <Row className="text-center" >
        <Col >
          <Button type="submit" variant='success'>
          {propriedades.modoEdicao ? 'Atualizar' : 'Salvar'}
            </Button>{' '}
          </Col>
          <Col>
          <Button type='button' variant='secondary' onClick={function(){
            propriedades.exibirTabela(true);
          }
          }>Voltar</Button>
        </Col>
      </Row>      
      </Form>
    </>      
)};