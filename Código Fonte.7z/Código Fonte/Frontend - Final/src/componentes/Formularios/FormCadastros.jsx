import React, { useState } from 'react';
import { Button, Form, Row, Col } from 'react-bootstrap';
import { urlBase } from '../../utilitarios/URL/Url';
import { Link } from 'react-router-dom';

export default function FormCadastros(props) {
    const [cadastro, setCadastros] = useState(props.cadastro);

    function manipulaMudanca(e) {
        const { id, value } = e.target;
        setCadastros({ ...cadastro, [id]: value });
    }

    async function manipulaSubmissao(e) {
        e.preventDefault();

        if (validarCampos()) {
            const metodo = props.modoEdicao ? 'PUT' : 'POST';
            const endpoint = props.modoEdicao ? `/cadastro` : '/cadastro';

            try {
                const resposta = await fetch(urlBase + endpoint, {
                    method: metodo,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(cadastro),
                });

                const dados = await resposta.json();

                if (dados.status) {
                    if (!props.modoEdicao) {
                        const novoCadastro = { ...cadastro, codigo: dados.codigo };
                        props.setCadastros([...props.listaCadastros, novoCadastro]);
                        window.alert('Cadastro salvo com sucesso!');
                    } else {
                        const listaAtualizada = props.listaCadastros.map((item) =>
                            item.codigo === cadastro.codigo ? cadastro : item
                        );
                        props.setCadastros(listaAtualizada);
                        window.alert('Cadastro atualizado com sucesso!');
                    }

                    props.exibirTabela(true);
                    
                } else {
                    window.alert(dados.mensagem);
                }
            } catch (erro) {
                window.alert('Erro ao executar a requisição: ' + erro.message);
            }
        }
    }

    function validarCampos() {
        const camposObrigatorios = ['usuario', 'senha', 'nivel'];
        for (const campo of camposObrigatorios) {
            if (!cadastro[campo]) {
                window.alert(`O campo "${campo}" é obrigatório.`);
                return false;
            }
        }
        return true;
    }

    return (
        <Form onSubmit={manipulaSubmissao}>
            <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/ajuda3">
                    <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                </Link>
            </div>
            <Row>
                <Col>
                    <Form.Group className="mb-3">
                        <Form.Label>Código{!props.modoEdicao && ''}:</Form.Label>
                        <Form.Control type="text" placeholder="*" readOnly value={cadastro.codigo} />
                    </Form.Group>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Form.Group className="mb-3">
                        <Form.Label>Usuário:</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Nome de usuário"
                            value={cadastro.usuario}
                            id='usuario'
                            onChange={manipulaMudanca}
                            required
                        />
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe o usuário.
                        </Form.Control.Feedback>
                    </Form.Group>
                </Col>
                <Col>
                    <Form.Group className="mb-3">
                        <Form.Label>Senha:</Form.Label>
                        <Form.Control
                            type="password"
                            placeholder="Cadastre uma senha"
                            value={cadastro.senha}
                            id='senha'
                            onChange={manipulaMudanca}
                            required
                        />
                        <Form.Control.Feedback type='invalid'>
                            Por favor, informe a senha.
                        </Form.Control.Feedback>
                    </Form.Group>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Form.Group className="mb-3">
                        <Form.Label>Nível de Acesso:</Form.Label>
                        <Form.Select
                            aria-label="Default select example"
                            value={cadastro.nivel}
                            id='nivel'
                            onChange={manipulaMudanca}
                        >
                            <option value="basico">Básico</option>
                            <option value="intermediario">Intermediário</option>
                            <option value="avancado">Avançado</option>
                        </Form.Select>
                    </Form.Group>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Button variant="success" type="submit">
                        {props.modoEdicao ? 'Atualizar' : 'Salvar'}
                    </Button>{' '}
                    {!props.modoEdicao && (
                        <Button variant="secondary" onClick={() => props.exibirTabela(true)}>
                            Voltar
                        </Button>
                    )}
                </Col>
            </Row>
        </Form>
    );
}
