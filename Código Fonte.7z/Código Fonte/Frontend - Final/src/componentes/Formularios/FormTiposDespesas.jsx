import { useState } from "react";
import { Button, Form, Row, Col} from "react-bootstrap";
import { ApenasLetras } from "./validadores";
import { urlBackend } from "../../utilitarios/URL/Url";
import { Link } from 'react-router-dom';

export default function FormTiposDespesas(propriedades){
    const [validado, setValidado] = useState(false);
    const [despesa,setDespesa] = useState(propriedades.despesa)



    function submissao(evento){
        const form = evento.currentTarget;
        if(form.checkValidity()){

            if(!propriedades.modoEdicao){
                fetch(urlBackend+'/tiposdespesas',{
                    method: 'POST',
                    headers: {"Content-Type":"application/json"},
                    body: JSON.stringify(despesa)
                }).then((resposta)=>{
                    return resposta.json();
                }).then((dados)=>{
                    window.alert(dados.mensagem)
                    let listaNova = propriedades.listaDespesas
                    listaNova.push(despesa)
                    propriedades.setDespesas(listaNova)
                    propriedades.exibirTabela(true)
                }).catch((error)=>{
                    window.alert("Erro:" + error.message + "!!!")
                })


            } else{
                fetch(urlBackend + '/tiposdespesas',{
                    method: "PUT",
                    headers:{"Content-Type":'application/json'},
                    body: JSON.stringify(despesa)            
                  }).then((resposta)=>{
                      return resposta.json();
                      
                 })         
                 window.alert('Dados atualizados com sucesso !!!');
            }


        }
    }



    function tratarEstado(evento){ // explicação melhor sobre essa função está no código de formulário de colaboradores
        const elementoFormulario = evento.currentTarget;
        const id = elementoFormulario.id;
        const valor = elementoFormulario.value;
        setDespesa({...despesa,[id]:valor});

    }
    return(
    <Form validated={validado} onSubmit={submissao} style={{width: "500px", marginLeft: '310px'}}>
    <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <Link to="/ajudatipodespesas">
                    <Button variant="light" style={{ color: 'black' }}>Ajuda</Button>
                </Link>
            </div>
    <Row>
        <Col>
        <Form.Label>Código</Form.Label>
            <Form.Control
            type="number"
            id = "codigo"
            value={despesa.codigo}
            onChange={tratarEstado}
            disabled
            required
            />
<br/>
        <Form.Label>Descrição</Form.Label>
            <Form.Control
            type="text"
            id = "descricao"
            value={despesa.descricao}
            onChange={tratarEstado}
            required
            />

<br/>
        <Form.Label>Classificação</Form.Label>
        <Form.Select value={despesa.classificacao} id='classificacao' onChange={tratarEstado} required>  
        <option value="administrativa mensal">Despesa Administrativa | Mensal</option>
        <option value="administrativa esporadica">Despesa Administrativa | Esporádica</option>
        <option value="animal servicos">Despesa Animal | Serviços</option>
        <option value="animal produtos">Despesa Animal | Materiais e Produtos</option>
        <option value="outro" selected >Outro</option>
        </Form.Select>
        </Col>

    </Row>
        <br/>
    <Row className="text-center" >
        <Col >
          <Button type="submit" variant='success'>{propriedades.modoEdicao ? 'Atualizar' : 'Salvar'}</Button>{' '}
          </Col>
          <Col>
          <Button type='button' variant='secondary' onClick={function(){
            propriedades.exibirTabela(true);
          }
          }>Voltar</Button>
        </Col>
      </Row>      

    </Form>
    )


}