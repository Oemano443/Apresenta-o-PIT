import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { LinkContainer } from 'react-router-bootstrap';


/*
 Cada propriedade:
 
 url = link da imagem ou caminho da mesma
 titulo = titulo do card
 texto = texto que estará no card
 rota = rota definida 
 botao = nome do botao
*/

function Cards(props) {
  return (
    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src={props.url} />
      <Card.Body>
        <Card.Title>{props.titulo}</Card.Title>
        <Card.Text>
          {props.texto}
        </Card.Text>
        <LinkContainer to={props.rota}><Button variant="dark" >{props.botao}</Button></LinkContainer> 
        
      </Card.Body>
    </Card>
  );
}

export default Cards;