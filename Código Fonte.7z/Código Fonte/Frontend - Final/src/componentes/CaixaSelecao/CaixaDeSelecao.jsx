import { useEffect, useState } from "react"
import { Spinner, Container } from "react-bootstrap"
import {Row,Col,Form} from "react-bootstrap"




// url: url do backend
// campoChave: chave primária
// campoExibicao: item que será exibido
// funcaoSelecao: função que receberá o objeto selecionado pelo usuário
export default function CaixaDeSelecao({url,campoChave,campoExibicao,funcaoSelecao}){
    const [valor,setValor] = useState({
        [campoChave]: 0,
        [campoExibicao]: "Não foi possível obter os dados"

    }) // valor selecionado (estado do componente)
    const [carregandoDados,SetcarregandoDados] = useState(false) // indicar se os dados estão carregando
    const [dados,setDados] = useState([]) // dados da caixa de seleção


    useEffect(()=>{
        try {
            SetcarregandoDados(true)
        fetch(url,{method: "GET"}).then((resposta)=>{
            if(resposta.ok){
                return resposta.json()
            } else {
            return ([{
                [campoChave]: 0,
                [campoExibicao]: "Não foi possível obter os dados"
            }])
            }
        }).then((ListaDados)=>{
            SetcarregandoDados(false)
            setDados(ListaDados)
            if(ListaDados.length > 0){
                setValor(ListaDados[0])
                funcaoSelecao(ListaDados[0])
            }
        })
    } catch(error) {
        SetcarregandoDados(false)
        setDados([{
           [campoChave]: 0,
            [campoExibicao]: "Não foi possível obter os dados" + error.message
        }])

    }
},[])


    return(
         <Container>
            <Row>
                <Col md={11}>
                    <Form.Select   onChange={(e)=>{
                            const itemSelecionado = e.currentTarget.value;
                            // lista de identificadores
                            const posicao = dados.map((item) => item[campoChave].toString()).indexOf(itemSelecionado)
                            setValor(dados[posicao])
                            funcaoSelecao(dados[posicao])
                    }} >
                                {dados.map((item) => {
                                    return <option key={item[campoChave]} value={item[campoChave]}>
                                        {item[campoExibicao]}
                                        </option>
                                })

                                }
                    </Form.Select>
                </Col>

                <Col md={1}>
                    <Spinner className={carregandoDados?"visible":"invisible"}>

                    </Spinner>
                </Col>
            </Row>

         </Container>
    )
}