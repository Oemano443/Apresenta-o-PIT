import { useState } from "react"
import { useRef } from "react";
import { Form, Container, Button,   } from "react-bootstrap"
import styles from './BarradeBusca.module.css'

export default function BarradeBusca({placeholder, dados, campoChave, campoBusca, funcaoSelecao, valores}){

    const inputBusca = useRef(); 
    // estados do ciclo de vida 
    const [termo,setTermo] = useState(valores? valores : ''); // termo de busca
    const [dadosLista, setDadosLista] = useState(dados); // dados que serão recebidos para exibir no resultado
    const [itemSelecionado, setItemSelecionado] = useState(false); // o componente precisa saber quando um item do resultado está selecionado

    function FiltrarItem(){ // filtrar os resultados
        setDadosLista(dados.filter((item)=>{
           return termo.length > 1 ? item[campoBusca].toLowerCase().includes(termo.toLowerCase()) : false
        }));

        let listaResultado = document.querySelector("[data-resultado]"); // componente que executará o resultado
        if(dadosLista.length > 0){
            listaResultado.style.display= 'block';
        } else {
            listaResultado.style.display= 'none';
        }
    }


    return(
        <Container>
 <div className={styles.barraDeBusca}>
   

        <Button disabled>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-search" viewBox="0 0 16 16">
        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
        </svg>
        </Button>

            <Form.Control 
            type="text"
            ref={inputBusca}
            placeholder={placeholder}
            value={termo}
            required
            onChange={(evento)=>{
            setTermo(evento.currentTarget.value.toLocaleLowerCase());
            FiltrarItem();
           if(!itemSelecionado){
                evento.target.setAttribute('aria-invalid',true);
                evento.target.setCustomValidity("erro");
            } else{
                evento.target.removeAttribute('aria-invalid');
                evento.target.setCustomValidity("");
            }
            }}
            />


            <Button variant="danger">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-x-square-fill" viewBox="0 0 16 16">
            <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm3.354 4.646L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 1 1 .708-.708z"/>
             onClick={()=>{

           
                 setTermo('');
                FiltrarItem();
                setItemSelecionado(false);
                funcaoSelecao({});

                
                inputBusca.current.setAttribute('aria-invalid',true);
                inputBusca.current.setCustomValidity("erro");
                

             }}
            </svg>
            </Button>
            <div className={styles.resultado}>
                <ul data-resultado>
                    {dadosLista.map((item) => {
                        return <li key={item[campoChave]}
                        onClick={()=>{
                            
                        setTermo(item[campoBusca]); // alterar o valor para o item que foi clicado
                        funcaoSelecao(item);
                       
                        setItemSelecionado(true); // indica que um item foi selecionado
                        inputBusca.current.setCustomValidity("") // só permite a validação se estiver vazia
                       
                        let listaResultado = document.querySelector("[data-resultado]");  // mostrar resultado  
                        listaResultado.style.display = 'none'; // esconde resultado
                         }}
                    >
                        
                        {item[campoChave] + '-' + item[campoBusca]}
                            
                            </li>
                    })}
                </ul>
            </div>


    
 </div>
 </Container>
    )

}