import { Container,Navbar,Nav } from "react-bootstrap";
import Dropdown from 'react-bootstrap/Dropdown';
import { LinkContainer } from "react-router-bootstrap";
import { useContext } from "react";
import {AuthContext} from "../../contexts/AuthProvider/auth";
import { useNavigate } from 'react-router-dom';
export default function Menu(propriedades){


  const navigate = useNavigate();
  const { logout } = useContext(AuthContext)
 
    return(
        <>
      <Navbar bg="dark" variant="dark" id="menu">
        <Container>
          <Navbar.Brand>{propriedades.texto}</Navbar.Brand>
          <Nav className="me-auto">
          <Dropdown>
            <Dropdown.Toggle variant="dark" id="dropdown-basic">
              Cadastros
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <LinkContainer to='/menu'><Dropdown.Item>Menu Principal</Dropdown.Item></LinkContainer>
              <LinkContainer to='/colaboradores'><Dropdown.Item >Cadastro de Colaboradores</Dropdown.Item></LinkContainer>
              <LinkContainer to='/animais'><Dropdown.Item >Cadastro de Animais</Dropdown.Item></LinkContainer>
              <LinkContainer to='/rifa'><Dropdown.Item >Cadastro de Rifas</Dropdown.Item></LinkContainer>
              <LinkContainer to='/raca'><Dropdown.Item >Cadastro de Raças</Dropdown.Item></LinkContainer>
              <LinkContainer to='/tipodespesas'><Dropdown.Item >Cadastro de Tipos De Despesas</Dropdown.Item></LinkContainer>
              <LinkContainer to='/itensdoacao'><Dropdown.Item >Cadastro para Itens de Doação</Dropdown.Item></LinkContainer> 
              <LinkContainer to='/cadastrousuarios'><Dropdown.Item >Cadastro de Usuários</Dropdown.Item></LinkContainer> 
             { /*<LinkContainer to='/adocoes'><Dropdown.Item >Realizar Adoção</Dropdown.Item></LinkContainer>*/ }
            </Dropdown.Menu>
          </Dropdown>

           
            <Nav.Link href="#" onClick={()=>logout(navigate)} >Sair</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
        </>

    );
}