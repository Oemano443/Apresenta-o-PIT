import { useState } from "react";
import { Button, Container, Form, Col, Row, Table } from "react-bootstrap";
import { urlAnimais } from "../utilitarios/URL/Url";
import { LinkContainer } from "react-router-bootstrap";

//<Table striped bordered hover> Borda estilizada com listras, bordas e quando mouse
//estiver sob a linha, sombreia como se estivesse selecionado

export default function TabelaAnimal(props) {

  //const [animais, setAnimal] = useState(props.listaAnimal);

  function excluirAnimal(codigo) {
    const listaAtualizada = props.listaAnimal.filter((animal) => animal.codigo_animal !== codigo);
    props.setAnimal(listaAtualizada);

  }

  function filtrarAnimais(e) {
    const termoBusca = e.currentTarget.value;
    //o filtro deverá ser feito na lista original
    //animal é uma cópia da lista original que está sendo utilizada para ser exibida em forma de tabela
    fetch(urlAnimais + "/animais", { method: "GET" })
      .then((resposta) => {
        return resposta.json()
      })
      .then((listaAnimal) => {
        if (Array.isArray(listaAnimal)) {
          const resultadoBusca = listaAnimal.filter((animais) => animais.nome_animal.toLowerCase().includes(termoBusca.toLowerCase()));
          props.setAnimal(resultadoBusca);
        }
      })

  }

  function imprimir(){
    window.print();
  }

  
function formatarData(data) {
  const dataFormatada = new Date(data);
  const dia = dataFormatada.getDate();
  const mes = dataFormatada.getMonth() + 1; // Adicione +1 porque o mês começa em 0
  const ano = dataFormatada.getFullYear();

  return `${dia < 10 ? '0' : ''}${dia}/${mes < 10 ? '0' : ''}${mes}/${ano}`;
}

  return (
    <Container>
      {/*<Row>
        <Col>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <LinkContainer to='/helpanimal'>
              <Button variant="outlined">
                Ajuda
              </Button>
            </LinkContainer>
          </div>
        </Col>
  </Row>*/}
      {/*<Container className="mb-3">*/}
        <Row>
          <Form.Label id="pesquisa">Pesquisa:</Form.Label>
          <Col className="col-md-6">
            <Form.Control type="text"
              id="termoBusca"
              placeholder="Digite o Nome do Animal"
              onChange={filtrarAnimais}
              //style={{ marginLeft: '-102px' }}
            />
          </Col>
        </Row>
        <br/>
      {/*</Container>*/}

      <Table striped bordered hover style={{ marginLeft: '-75px' }}>
        <thead>
          <tr>
            <th>Código</th>
            <th>Nome</th>
            <th>Raça</th>
            <th>Porte</th>
            <th>Cor</th>
            <th>Idade</th>
            <th>Temperamento</th>
            <th>Data Entrada</th>
            <th>Vacinação</th>
            <th>Local Encontrado</th>
            <th>Neces. Especiais</th>
            <th>Disponível</th>
            <th>Data Adoção</th>
            <th id="esconder">Ações</th>
          </tr>
        </thead>
        <tbody>
          {
            props.listaAnimal?.map((animal) => {
              //identificar cada uma das linhas tr (table row) usando a propriedade key
              //key auxilia React na renderização dos componentes no DOM virtual
              return <tr key={animal.codigo_animal}>
                <td>{animal.codigo_animal}</td>
                <td>{animal.nome_animal}</td>
                <td>{animal.raca_animal}</td>
                <td>{animal.porte_animal}</td>
                <td>{animal.cor_animal}</td>
                <td>{animal.idade_animal}</td>
                <td>{animal.temperamento_animal}</td>
                <td>{formatarData(animal.dataentrada_animal)}</td>
                <td>{animal.vacinacao_animal}</td>
                <td>{animal.localencontrado_animal}</td>

                <td>{animal.necessidades_animal}</td>
                <td>{animal.disponibilidade_animal}</td>
                <td>{animal.dataadocao_animal}</td>
                <td id="esconder" style={{ flexDirection: 'column' }}>
                  <Button id='btnAltera' variant='warning' onClick={() => { props.editarAnimal(animal) }} style={{ marginBottom: '3px' }}>
                    <svg xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-pencil"
                      viewBox="0 0 16 16">
                      <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z" />
                    </svg>
                  </Button>{' '}
                  <Button id='btnExclui' variant='danger' onClick={() => {
                    if (window.confirm("Confirmar a exclusão deste animal ?"))
                      props.excluirAnimal(animal)
                    //if (window.confirm("Deseja realmente excluir?")) {
                    //excluirAnimal(animal.codigo_animal);
                  }
                  }>
                    <svg xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash"
                      viewBox="0 0 16 16">
                      <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z" />
                      <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118ZM2.5 3h11V2h-11v1Z" />
                    </svg>
                  </Button>
                </td>
              </tr>
            })
          }
        </tbody>
      </Table>
      <Button id="btnCadastrar" variant='success' className="m-3" onClick={() => {
        props.exibirTabela(false);
      }}>
        Cadastrar
      </Button>
      <Button id="btnImprimir" onClick={imprimir} className="btn btn-primary">Imprimir</Button>

    </Container>
  );
}